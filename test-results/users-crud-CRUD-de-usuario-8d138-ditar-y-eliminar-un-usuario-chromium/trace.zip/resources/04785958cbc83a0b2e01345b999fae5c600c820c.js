import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/chunk-BZDT2WVB.js");import {
  SessionCleanupService
} from "/chunk-F4B37XH6.js";
import {
  PermissionService
} from "/chunk-KIW7SE4H.js";
import {
  AuthService
} from "/chunk-HUEL4CRJ.js";
import "/chunk-WOIO7PCB.js";
import "/chunk-P37EOHI7.js";
import "/chunk-VUJOFXKG.js";

// src/app/layout/admin-layout/admin-layout.ts
import { Component as Component3, signal } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { RouterOutlet } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_router.js?v=b9a49161";

// src/app/layout/sidebar/sidebar.ts
import { Component, computed, output, inject } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { RouterLink, RouterLinkActive } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_router.js?v=b9a49161";
import * as i0 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
var _forTrack0 = ($index, $item) => $item.route;
function Sidebar_For_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "a", 6);
    i0.\u0275\u0275listener("click", function Sidebar_For_9_Template_a_click_0_listener() {
      i0.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.navigate.emit());
    });
    i0.\u0275\u0275element(1, "i", 7);
    i0.\u0275\u0275elementStart(2, "span");
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const item_r3 = ctx.$implicit;
    i0.\u0275\u0275property("routerLink", item_r3.route);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275classMap(item_r3.icon);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(item_r3.label);
  }
}
var Sidebar = class _Sidebar {
  navigate = output();
  permissions = inject(PermissionService);
  menuItems = [
    {
      label: "Dashboard",
      icon: "pi pi-home",
      route: "/dashboard",
      permission: "dashboard.view"
    },
    {
      label: "Usuarios",
      icon: "pi pi-users",
      route: "/users",
      permission: "users.view"
    },
    {
      label: "Configuraci\xF3n",
      icon: "pi pi-cog",
      route: "/settings",
      permission: "settings.view"
    }
  ];
  visibleMenuItems = computed(() => this.menuItems.filter((item) => !item.permission || this.permissions.has(item.permission)), ...ngDevMode ? [{ debugName: "visibleMenuItems" }] : (
    /* istanbul ignore next */
    []
  ));
  static \u0275fac = function Sidebar_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Sidebar)();
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _Sidebar, selectors: [["app-sidebar"]], outputs: { navigate: "navigate" }, decls: 10, vars: 0, consts: [[1, "sidebar"], [1, "brand"], ["aria-hidden", "true", 1, "pi", "pi-chart-bar"], ["aria-label", "Navegaci\xF3n principal"], [1, "menu-title"], ["routerLinkActive", "active", 3, "routerLink"], ["routerLinkActive", "active", 3, "click", "routerLink"], ["aria-hidden", "true"]], template: function Sidebar_Template(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275elementStart(0, "aside", 0)(1, "div", 1);
      i0.\u0275\u0275element(2, "i", 2);
      i0.\u0275\u0275elementStart(3, "span");
      i0.\u0275\u0275text(4, "AdminPanel");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(5, "nav", 3)(6, "p", 4);
      i0.\u0275\u0275text(7, "MEN\xDA PRINCIPAL");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275repeaterCreate(8, Sidebar_For_9_Template, 4, 4, "a", 5, _forTrack0);
      i0.\u0275\u0275elementEnd()();
    }
    if (rf & 2) {
      i0.\u0275\u0275advance(8);
      i0.\u0275\u0275repeater(ctx.visibleMenuItems());
    }
  }, dependencies: [RouterLink, RouterLinkActive], styles: ["\n[_nghost-%COMP%] {\n  display: block;\n  background: #111827;\n  color: #fff;\n  min-height: 100vh;\n}\n.sidebar[_ngcontent-%COMP%] {\n  padding: 28px 16px;\n}\n.brand[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 0 12px 42px;\n  font-size: 22px;\n  font-weight: 700;\n}\n.brand[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  color: #a5b4fc;\n  font-size: 26px;\n}\n.menu-title[_ngcontent-%COMP%] {\n  padding: 0 12px;\n  color: #94a3b8;\n  font-size: 11px;\n  letter-spacing: 1px;\n}\nnav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 14px;\n  padding: 14px 16px;\n  margin: 6px 0;\n  border-radius: 10px;\n  color: #cbd5e1;\n  transition: background 0.2s;\n}\nnav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background: #1f2937;\n}\nnav[_ngcontent-%COMP%]   a.active[_ngcontent-%COMP%] {\n  background: #4f46e5;\n  color: white;\n}\n/*# sourceMappingURL=sidebar.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(Sidebar, [{
    type: Component,
    args: [{ selector: "app-sidebar", standalone: true, imports: [RouterLink, RouterLinkActive], template: '<aside class="sidebar">\n    <div class="brand">\n        <i class="pi pi-chart-bar" aria-hidden="true"></i>\n        <span>AdminPanel</span>\n    </div>\n    <nav aria-label="Navegaci\xF3n principal">\n        <p class="menu-title">MEN\xDA PRINCIPAL</p>\n        @for (item of visibleMenuItems(); track item.route) {\n        <a [routerLink]="item.route" routerLinkActive="active" (click)="navigate.emit()">\n            <i [class]="item.icon" aria-hidden="true"></i>\n            <span>{{ item.label }}</span>\n        </a>\n        }\n    </nav>\n</aside>\n', styles: ["/* src/app/layout/sidebar/sidebar.scss */\n:host {\n  display: block;\n  background: #111827;\n  color: #fff;\n  min-height: 100vh;\n}\n.sidebar {\n  padding: 28px 16px;\n}\n.brand {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 0 12px 42px;\n  font-size: 22px;\n  font-weight: 700;\n}\n.brand i {\n  color: #a5b4fc;\n  font-size: 26px;\n}\n.menu-title {\n  padding: 0 12px;\n  color: #94a3b8;\n  font-size: 11px;\n  letter-spacing: 1px;\n}\nnav a {\n  display: flex;\n  align-items: center;\n  gap: 14px;\n  padding: 14px 16px;\n  margin: 6px 0;\n  border-radius: 10px;\n  color: #cbd5e1;\n  transition: background 0.2s;\n}\nnav a:hover {\n  background: #1f2937;\n}\nnav a.active {\n  background: #4f46e5;\n  color: white;\n}\n/*# sourceMappingURL=sidebar.css.map */\n"] }]
  }], null, { navigate: [{ type: i0.Output, args: ["navigate"] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(Sidebar, { className: "Sidebar", filePath: "app/layout/sidebar/sidebar.ts", lineNumber: 20 });
})();
(() => {
  const id = "app%2Flayout%2Fsidebar%2Fsidebar.ts%40Sidebar";
  function Sidebar_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i0.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i0.\u0275\u0275replaceMetadata(Sidebar, m.default, [i0], [RouterLink, RouterLinkActive, Component], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Sidebar_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Sidebar_HmrLoad(d.timestamp)));
})();

// src/app/layout/header/header.ts
import { Component as Component2, output as output2 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { ButtonModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_button.js?v=b9a49161";
import { AvatarModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_avatar.js?v=b9a49161";
import { inject as inject2 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { Router } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_router.js?v=b9a49161";
import * as i02 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import * as i1 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_button.js?v=b9a49161";
import * as i2 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_api.js?v=b9a49161";
import * as i3 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_avatar.js?v=b9a49161";
var Header2 = class _Header {
  menuClick = output2();
  authService = inject2(AuthService);
  router = inject2(Router);
  cleanup = inject2(SessionCleanupService);
  logout() {
    this.authService.logout().subscribe({
      next: () => {
        this.cleanup.clear();
        void this.router.navigate(["/login"]);
      },
      error: () => {
        console.error("No se pudo cerrar la sesi\xF3n.");
      }
    });
  }
  static \u0275fac = function Header_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Header)();
  };
  static \u0275cmp = /* @__PURE__ */ i02.\u0275\u0275defineComponent({ type: _Header, selectors: [["app-header"]], outputs: { menuClick: "menuClick" }, decls: 19, vars: 1, consts: [[1, "header"], [1, "header-left"], ["icon", "pi pi-bars", "severity", "secondary", "ariaLabel", "Abrir men\xFA", "styleClass", "mobile-menu", 3, "onClick", "text"], [1, "header-right"], ["label", "AD", "shape", "circle", "size", "large"], [1, "user-info"], ["type", "button", "aria-label", "Cerrar sesi\xF3n", 1, "logout-button", 3, "click"], ["aria-hidden", "true", 1, "pi", "pi-sign-out"]], template: function Header_Template(rf, ctx) {
    if (rf & 1) {
      i02.\u0275\u0275elementStart(0, "header", 0)(1, "div", 1)(2, "p-button", 2);
      i02.\u0275\u0275listener("onClick", function Header_Template_p_button_onClick_2_listener() {
        return ctx.menuClick.emit();
      });
      i02.\u0275\u0275elementEnd();
      i02.\u0275\u0275elementStart(3, "div")(4, "h2");
      i02.\u0275\u0275text(5, "Panel administrativo");
      i02.\u0275\u0275elementEnd();
      i02.\u0275\u0275elementStart(6, "span");
      i02.\u0275\u0275text(7, "Bienvenido a tu espacio de trabajo");
      i02.\u0275\u0275elementEnd()()();
      i02.\u0275\u0275elementStart(8, "div", 3);
      i02.\u0275\u0275element(9, "p-avatar", 4);
      i02.\u0275\u0275elementStart(10, "div", 5)(11, "strong");
      i02.\u0275\u0275text(12, "Administrador");
      i02.\u0275\u0275elementEnd();
      i02.\u0275\u0275elementStart(13, "span");
      i02.\u0275\u0275text(14, "Admin");
      i02.\u0275\u0275elementEnd()();
      i02.\u0275\u0275elementStart(15, "button", 6);
      i02.\u0275\u0275listener("click", function Header_Template_button_click_15_listener() {
        return ctx.logout();
      });
      i02.\u0275\u0275element(16, "i", 7);
      i02.\u0275\u0275elementStart(17, "span");
      i02.\u0275\u0275text(18, "Cerrar sesi\xF3n");
      i02.\u0275\u0275elementEnd()()()();
    }
    if (rf & 2) {
      i02.\u0275\u0275advance(2);
      i02.\u0275\u0275property("text", true);
    }
  }, dependencies: [ButtonModule, i1.ButtonDirective, i1.Button, i1.ButtonLabel, i1.ButtonIcon, i2.Header, i2.Footer, i2.PrimeTemplate, AvatarModule, i3.Avatar], styles: ["\n.header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n  padding: 18px 28px;\n  background: #fff;\n  border-bottom: 1px solid #e2e8f0;\n}\n.header-left[_ngcontent-%COMP%], \n.header-right[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 16px;\n}\nh2[_ngcontent-%COMP%] {\n  font-size: 18px;\n  margin: 0 0 4px;\n}\nspan[_ngcontent-%COMP%] {\n  color: #64748b;\n  font-size: 13px;\n}\n.user-info[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n[_nghost-%COMP%]     .mobile-menu {\n  display: none;\n}\n@media (max-width: 768px) {\n  .header[_ngcontent-%COMP%] {\n    padding: 14px 16px;\n  }\n  [_nghost-%COMP%]     .mobile-menu {\n    display: inline-flex;\n  }\n  .user-info[_ngcontent-%COMP%], \n   .header-left[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n    display: none;\n  }\n}\n.logout-button[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  padding: 10px 14px;\n  border: 1px solid #e2e8f0;\n  border-radius: 10px;\n  background: #ffffff;\n  color: #334155;\n  cursor: pointer;\n  transition: background-color 0.2s ease;\n}\n.logout-button[_ngcontent-%COMP%]:hover {\n  background: #f1f5f9;\n}\n.logout-button[_ngcontent-%COMP%]:focus-visible {\n  outline: 3px solid #818cf8;\n  outline-offset: 2px;\n}\n/*# sourceMappingURL=header.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassMetadata(Header2, [{
    type: Component2,
    args: [{ selector: "app-header", imports: [ButtonModule, AvatarModule], template: '<header class="header">\n  <div class="header-left">\n    <p-button\n      icon="pi pi-bars"\n      [text]="true"\n      severity="secondary"\n      ariaLabel="Abrir men\xFA"\n      styleClass="mobile-menu"\n      (onClick)="menuClick.emit()"\n    />\n    <div>\n      <h2>Panel administrativo</h2>\n      <span>Bienvenido a tu espacio de trabajo</span>\n    </div>\n  </div>\n\n  <div class="header-right">\n    <p-avatar label="AD" shape="circle" size="large" />\n    <div class="user-info">\n      <strong>Administrador</strong>\n      <span>Admin</span>\n    </div>\n    <button type="button" class="logout-button" (click)="logout()" aria-label="Cerrar sesi\xF3n">\n      <i class="pi pi-sign-out" aria-hidden="true"></i>\n      <span>Cerrar sesi\xF3n</span>\n    </button>\n  </div>\n</header>\n', styles: ["/* src/app/layout/header/header.scss */\n.header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n  padding: 18px 28px;\n  background: #fff;\n  border-bottom: 1px solid #e2e8f0;\n}\n.header-left,\n.header-right {\n  display: flex;\n  align-items: center;\n  gap: 16px;\n}\nh2 {\n  font-size: 18px;\n  margin: 0 0 4px;\n}\nspan {\n  color: #64748b;\n  font-size: 13px;\n}\n.user-info {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n:host ::ng-deep .mobile-menu {\n  display: none;\n}\n@media (max-width: 768px) {\n  .header {\n    padding: 14px 16px;\n  }\n  :host ::ng-deep .mobile-menu {\n    display: inline-flex;\n  }\n  .user-info,\n  .header-left span {\n    display: none;\n  }\n}\n.logout-button {\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  padding: 10px 14px;\n  border: 1px solid #e2e8f0;\n  border-radius: 10px;\n  background: #ffffff;\n  color: #334155;\n  cursor: pointer;\n  transition: background-color 0.2s ease;\n}\n.logout-button:hover {\n  background: #f1f5f9;\n}\n.logout-button:focus-visible {\n  outline: 3px solid #818cf8;\n  outline-offset: 2px;\n}\n/*# sourceMappingURL=header.css.map */\n"] }]
  }], null, { menuClick: [{ type: i02.Output, args: ["menuClick"] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(Header2, { className: "Header", filePath: "app/layout/header/header.ts", lineNumber: 18 });
})();
(() => {
  const id = "app%2Flayout%2Fheader%2Fheader.ts%40Header";
  function Header_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i02.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i02.\u0275\u0275replaceMetadata(Header2, m.default, [i02, i1, i2, i3], [ButtonModule, AvatarModule, Component2], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Header_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Header_HmrLoad(d.timestamp)));
})();

// src/app/layout/admin-layout/admin-layout.ts
import * as i03 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
function AdminLayout_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275elementStart(0, "button", 6);
    i03.\u0275\u0275listener("click", function AdminLayout_Conditional_1_Template_button_click_0_listener() {
      i03.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r1.closeSidebar());
    });
    i03.\u0275\u0275elementEnd();
  }
}
var AdminLayout = class _AdminLayout {
  sidebarOpen = signal(false, ...ngDevMode ? [{ debugName: "sidebarOpen" }] : (
    /* istanbul ignore next */
    []
  ));
  toggleSidebar() {
    this.sidebarOpen.update((value) => !value);
  }
  closeSidebar() {
    this.sidebarOpen.set(false);
  }
  static \u0275fac = function AdminLayout_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AdminLayout)();
  };
  static \u0275cmp = /* @__PURE__ */ i03.\u0275\u0275defineComponent({ type: _AdminLayout, selectors: [["app-admin-layout"]], decls: 7, vars: 3, consts: [[1, "admin-layout"], ["type", "button", "aria-label", "Cerrar men\xFA", 1, "sidebar-backdrop"], [3, "navigate"], [1, "main-wrapper"], [3, "menuClick"], ["id", "main-content", 1, "main-content"], ["type", "button", "aria-label", "Cerrar men\xFA", 1, "sidebar-backdrop", 3, "click"]], template: function AdminLayout_Template(rf, ctx) {
    if (rf & 1) {
      i03.\u0275\u0275elementStart(0, "div", 0);
      i03.\u0275\u0275conditionalCreate(1, AdminLayout_Conditional_1_Template, 1, 0, "button", 1);
      i03.\u0275\u0275elementStart(2, "app-sidebar", 2);
      i03.\u0275\u0275listener("navigate", function AdminLayout_Template_app_sidebar_navigate_2_listener() {
        return ctx.closeSidebar();
      });
      i03.\u0275\u0275elementEnd();
      i03.\u0275\u0275elementStart(3, "div", 3)(4, "app-header", 4);
      i03.\u0275\u0275listener("menuClick", function AdminLayout_Template_app_header_menuClick_4_listener() {
        return ctx.toggleSidebar();
      });
      i03.\u0275\u0275elementEnd();
      i03.\u0275\u0275elementStart(5, "main", 5);
      i03.\u0275\u0275element(6, "router-outlet");
      i03.\u0275\u0275elementEnd()()();
    }
    if (rf & 2) {
      i03.\u0275\u0275advance();
      i03.\u0275\u0275conditional(ctx.sidebarOpen() ? 1 : -1);
      i03.\u0275\u0275advance();
      i03.\u0275\u0275classProp("is-open", ctx.sidebarOpen());
    }
  }, dependencies: [RouterOutlet, Sidebar, Header2], styles: ["\n.admin-layout[_ngcontent-%COMP%] {\n  display: flex;\n  min-height: 100vh;\n}\napp-sidebar[_ngcontent-%COMP%] {\n  width: 260px;\n  flex-shrink: 0;\n}\n.main-wrapper[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n}\n.main-content[_ngcontent-%COMP%] {\n  padding: 28px;\n}\n.sidebar-backdrop[_ngcontent-%COMP%] {\n  display: none;\n}\n@media (max-width: 768px) {\n  app-sidebar[_ngcontent-%COMP%] {\n    position: fixed;\n    z-index: 1001;\n    top: 0;\n    bottom: 0;\n    left: 0;\n    transform: translateX(-100%);\n    transition: transform 0.25s ease;\n  }\n  app-sidebar.is-open[_ngcontent-%COMP%] {\n    transform: translateX(0);\n  }\n  .sidebar-backdrop[_ngcontent-%COMP%] {\n    display: block;\n    position: fixed;\n    inset: 0;\n    z-index: 1000;\n    background: rgba(15, 23, 42, 0.5);\n    border: 0;\n    width: 100%;\n  }\n  .main-content[_ngcontent-%COMP%] {\n    padding: 16px;\n  }\n}\n/*# sourceMappingURL=admin-layout.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassMetadata(AdminLayout, [{
    type: Component3,
    args: [{ selector: "app-admin-layout", imports: [RouterOutlet, Sidebar, Header2], template: '<div class="admin-layout">\n  @if (sidebarOpen()) {\n    <button\n      class="sidebar-backdrop"\n      type="button"\n      aria-label="Cerrar men\xFA"\n      (click)="closeSidebar()"\n    ></button>\n  }\n  <app-sidebar [class.is-open]="sidebarOpen()" (navigate)="closeSidebar()" />\n  <div class="main-wrapper">\n    <app-header (menuClick)="toggleSidebar()" />\n    <main class="main-content" id="main-content">\n      <router-outlet />\n    </main>\n  </div>\n</div>\n', styles: ["/* src/app/layout/admin-layout/admin-layout.scss */\n.admin-layout {\n  display: flex;\n  min-height: 100vh;\n}\napp-sidebar {\n  width: 260px;\n  flex-shrink: 0;\n}\n.main-wrapper {\n  flex: 1;\n  min-width: 0;\n}\n.main-content {\n  padding: 28px;\n}\n.sidebar-backdrop {\n  display: none;\n}\n@media (max-width: 768px) {\n  app-sidebar {\n    position: fixed;\n    z-index: 1001;\n    top: 0;\n    bottom: 0;\n    left: 0;\n    transform: translateX(-100%);\n    transition: transform 0.25s ease;\n  }\n  app-sidebar.is-open {\n    transform: translateX(0);\n  }\n  .sidebar-backdrop {\n    display: block;\n    position: fixed;\n    inset: 0;\n    z-index: 1000;\n    background: rgba(15, 23, 42, 0.5);\n    border: 0;\n    width: 100%;\n  }\n  .main-content {\n    padding: 16px;\n  }\n}\n/*# sourceMappingURL=admin-layout.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(AdminLayout, { className: "AdminLayout", filePath: "app/layout/admin-layout/admin-layout.ts", lineNumber: 13 });
})();
(() => {
  const id = "app%2Flayout%2Fadmin-layout%2Fadmin-layout.ts%40AdminLayout";
  function AdminLayout_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i03.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i03.\u0275\u0275replaceMetadata(AdminLayout, m.default, [i03], [RouterOutlet, Sidebar, Header2, Component3], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && AdminLayout_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && AdminLayout_HmrLoad(d.timestamp)));
})();
export {
  AdminLayout
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbGF5b3V0L2FkbWluLWxheW91dC9hZG1pbi1sYXlvdXQudHMiLCJzcmMvYXBwL2xheW91dC9hZG1pbi1sYXlvdXQvYWRtaW4tbGF5b3V0Lmh0bWwiLCJzcmMvYXBwL2xheW91dC9zaWRlYmFyL3NpZGViYXIudHMiLCJzcmMvYXBwL2xheW91dC9zaWRlYmFyL3NpZGViYXIuaHRtbCIsInNyYy9hcHAvbGF5b3V0L2hlYWRlci9oZWFkZXIudHMiLCJzcmMvYXBwL2xheW91dC9oZWFkZXIvaGVhZGVyLmh0bWwiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBzaWduYWwgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJvdXRlck91dGxldCB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBTaWRlYmFyIH0gZnJvbSAnLi4vc2lkZWJhci9zaWRlYmFyJztcbmltcG9ydCB7IEhlYWRlciB9IGZyb20gJy4uL2hlYWRlci9oZWFkZXInO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAtYWRtaW4tbGF5b3V0JyxcbiAgaW1wb3J0czogW1JvdXRlck91dGxldCwgU2lkZWJhciwgSGVhZGVyXSxcbiAgdGVtcGxhdGVVcmw6ICcuL2FkbWluLWxheW91dC5odG1sJyxcbiAgc3R5bGVVcmw6ICcuL2FkbWluLWxheW91dC5zY3NzJyxcbn0pXG5cbmV4cG9ydCBjbGFzcyBBZG1pbkxheW91dCB7XG4gIHNpZGViYXJPcGVuID0gc2lnbmFsKGZhbHNlKTtcbiAgdG9nZ2xlU2lkZWJhcigpIHtcbiAgICB0aGlzLnNpZGViYXJPcGVuLnVwZGF0ZSgodmFsdWUpID0+ICF2YWx1ZSk7XG4gIH1cbiAgY2xvc2VTaWRlYmFyKCkge1xuICAgIHRoaXMuc2lkZWJhck9wZW4uc2V0KGZhbHNlKTtcbiAgfVxufVxuIiwiPGRpdiBjbGFzcz1cImFkbWluLWxheW91dFwiPlxuICBAaWYgKHNpZGViYXJPcGVuKCkpIHtcbiAgICA8YnV0dG9uXG4gICAgICBjbGFzcz1cInNpZGViYXItYmFja2Ryb3BcIlxuICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICBhcmlhLWxhYmVsPVwiQ2VycmFyIG1lbsO6XCJcbiAgICAgIChjbGljayk9XCJjbG9zZVNpZGViYXIoKVwiXG4gICAgPjwvYnV0dG9uPlxuICB9XG4gIDxhcHAtc2lkZWJhciBbY2xhc3MuaXMtb3Blbl09XCJzaWRlYmFyT3BlbigpXCIgKG5hdmlnYXRlKT1cImNsb3NlU2lkZWJhcigpXCIgLz5cbiAgPGRpdiBjbGFzcz1cIm1haW4td3JhcHBlclwiPlxuICAgIDxhcHAtaGVhZGVyIChtZW51Q2xpY2spPVwidG9nZ2xlU2lkZWJhcigpXCIgLz5cbiAgICA8bWFpbiBjbGFzcz1cIm1haW4tY29udGVudFwiIGlkPVwibWFpbi1jb250ZW50XCI+XG4gICAgICA8cm91dGVyLW91dGxldCAvPlxuICAgIDwvbWFpbj5cbiAgPC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgY29tcHV0ZWQsIG91dHB1dCwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBSb3V0ZXJMaW5rLCBSb3V0ZXJMaW5rQWN0aXZlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IFBlcm1pc3Npb25TZXJ2aWNlIH0gZnJvbSAnLi4vLi4vY29yZS9zZXJ2aWNlcy9wZXJtaXNzaW9uJztcbmltcG9ydCB7IFBlcm1pc3Npb24gfSBmcm9tICcuLi8uLi9jb3JlL21vZGVscy9wZXJtaXNzaW9uLm1vZGVsJztcblxuaW50ZXJmYWNlIE1lbnVJdGVtIHtcbiAgbGFiZWw6IHN0cmluZztcbiAgaWNvbjogc3RyaW5nO1xuICByb3V0ZTogc3RyaW5nO1xuICBwZXJtaXNzaW9uPzogUGVybWlzc2lvbjtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYXBwLXNpZGViYXInLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbUm91dGVyTGluaywgUm91dGVyTGlua0FjdGl2ZV0sXG4gIHRlbXBsYXRlVXJsOiAnLi9zaWRlYmFyLmh0bWwnLFxuICBzdHlsZVVybDogJy4vc2lkZWJhci5zY3NzJyxcbn0pXG5leHBvcnQgY2xhc3MgU2lkZWJhciB7XG4gIHJlYWRvbmx5IG5hdmlnYXRlID0gb3V0cHV0PHZvaWQ+KCk7XG4gIHJlYWRvbmx5IHBlcm1pc3Npb25zID0gaW5qZWN0KFBlcm1pc3Npb25TZXJ2aWNlKTtcbiAgcmVhZG9ubHkgbWVudUl0ZW1zOiByZWFkb25seSBNZW51SXRlbVtdID0gW1xuICAgIHtcbiAgICAgIGxhYmVsOiAnRGFzaGJvYXJkJyxcbiAgICAgIGljb246ICdwaSBwaS1ob21lJyxcbiAgICAgIHJvdXRlOiAnL2Rhc2hib2FyZCcsXG4gICAgICBwZXJtaXNzaW9uOiAnZGFzaGJvYXJkLnZpZXcnLFxuICAgIH0sXG4gICAge1xuICAgICAgbGFiZWw6ICdVc3VhcmlvcycsXG4gICAgICBpY29uOiAncGkgcGktdXNlcnMnLFxuICAgICAgcm91dGU6ICcvdXNlcnMnLFxuICAgICAgcGVybWlzc2lvbjogJ3VzZXJzLnZpZXcnLFxuICAgIH0sXG4gICAge1xuICAgICAgbGFiZWw6ICdDb25maWd1cmFjacOzbicsXG4gICAgICBpY29uOiAncGkgcGktY29nJyxcbiAgICAgIHJvdXRlOiAnL3NldHRpbmdzJyxcbiAgICAgIHBlcm1pc3Npb246ICdzZXR0aW5ncy52aWV3JyxcbiAgICB9LFxuICBdO1xuXG4gIHJlYWRvbmx5IHZpc2libGVNZW51SXRlbXMgPSBjb21wdXRlZCgoKSA9PlxuICAgIHRoaXMubWVudUl0ZW1zLmZpbHRlcigoaXRlbSkgPT4gIWl0ZW0ucGVybWlzc2lvbiB8fCB0aGlzLnBlcm1pc3Npb25zLmhhcyhpdGVtLnBlcm1pc3Npb24pKSxcbiAgKTtcbn1cbiIsIjxhc2lkZSBjbGFzcz1cInNpZGViYXJcIj5cbiAgICA8ZGl2IGNsYXNzPVwiYnJhbmRcIj5cbiAgICAgICAgPGkgY2xhc3M9XCJwaSBwaS1jaGFydC1iYXJcIiBhcmlhLWhpZGRlbj1cInRydWVcIj48L2k+XG4gICAgICAgIDxzcGFuPkFkbWluUGFuZWw8L3NwYW4+XG4gICAgPC9kaXY+XG4gICAgPG5hdiBhcmlhLWxhYmVsPVwiTmF2ZWdhY2nDs24gcHJpbmNpcGFsXCI+XG4gICAgICAgIDxwIGNsYXNzPVwibWVudS10aXRsZVwiPk1FTsOaIFBSSU5DSVBBTDwvcD5cbiAgICAgICAgQGZvciAoaXRlbSBvZiB2aXNpYmxlTWVudUl0ZW1zKCk7IHRyYWNrIGl0ZW0ucm91dGUpIHtcbiAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiaXRlbS5yb3V0ZVwiIHJvdXRlckxpbmtBY3RpdmU9XCJhY3RpdmVcIiAoY2xpY2spPVwibmF2aWdhdGUuZW1pdCgpXCI+XG4gICAgICAgICAgICA8aSBbY2xhc3NdPVwiaXRlbS5pY29uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9pPlxuICAgICAgICAgICAgPHNwYW4+e3sgaXRlbS5sYWJlbCB9fTwvc3Bhbj5cbiAgICAgICAgPC9hPlxuICAgICAgICB9XG4gICAgPC9uYXY+XG48L2FzaWRlPlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBvdXRwdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEJ1dHRvbk1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvYnV0dG9uJztcbmltcG9ydCB7IEF2YXRhck1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvYXZhdGFyJztcblxuaW1wb3J0IHsgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgQXV0aFNlcnZpY2UgfSBmcm9tICcuLi8uLi9jb3JlL3NlcnZpY2VzL2F1dGgnO1xuXG5pbXBvcnQgeyBTZXNzaW9uQ2xlYW51cFNlcnZpY2UgfSBmcm9tICcuLi8uLi9jb3JlL3NlcnZpY2VzL3Nlc3Npb24tY2xlYW51cCc7XG5cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYXBwLWhlYWRlcicsXG4gIGltcG9ydHM6IFtCdXR0b25Nb2R1bGUsIEF2YXRhck1vZHVsZV0sXG4gIHRlbXBsYXRlVXJsOiAnLi9oZWFkZXIuaHRtbCcsXG4gIHN0eWxlVXJsOiAnLi9oZWFkZXIuc2NzcycsXG59KVxuZXhwb3J0IGNsYXNzIEhlYWRlciB7XG4gIG1lbnVDbGljayA9IG91dHB1dDx2b2lkPigpO1xuXG4gIHJlYWRvbmx5IGF1dGhTZXJ2aWNlID0gaW5qZWN0KEF1dGhTZXJ2aWNlKTtcbiAgcHJpdmF0ZSByZWFkb25seSByb3V0ZXIgPSBpbmplY3QoUm91dGVyKTtcbiAgcHJpdmF0ZSByZWFkb25seSBjbGVhbnVwID0gaW5qZWN0KFNlc3Npb25DbGVhbnVwU2VydmljZSk7XG5cbiAgbG9nb3V0KCk6IHZvaWQge1xuICAgIHRoaXMuYXV0aFNlcnZpY2UubG9nb3V0KCkuc3Vic2NyaWJlKHtcbiAgICAgIG5leHQ6ICgpID0+IHtcbiAgICAgICAgdGhpcy5jbGVhbnVwLmNsZWFyKCk7XG4gICAgICAgIHZvaWQgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvbG9naW4nXSk7XG4gICAgICB9LFxuICAgICAgZXJyb3I6ICgpID0+IHtcbiAgICAgICAgLy8gTGEgc2VzacOzbiByZW1vdGEgcG9kcsOtYSBzZWd1aXIgdmlnZW50ZS5cbiAgICAgICAgLy8gTm8gYWZpcm1hbW9zIHF1ZSBzZSBoYXlhIGNlcnJhZG8gY29ycmVjdGFtZW50ZS5cbiAgICAgICAgY29uc29sZS5lcnJvcignTm8gc2UgcHVkbyBjZXJyYXIgbGEgc2VzacOzbi4nKTtcblxuICAgICAgICAvLyBBcXXDrSBwdWVkZXMgbW9zdHJhciB1biBUb2FzdCBkZSBlcnJvclxuICAgICAgICAvLyB5IHBlcm1pdGlyIHF1ZSBlbCB1c3VhcmlvIHZ1ZWx2YSBhIGludGVudGFybG8uXG4gICAgICB9LFxuICAgIH0pO1xuICB9XG59XG4iLCI8aGVhZGVyIGNsYXNzPVwiaGVhZGVyXCI+XG4gIDxkaXYgY2xhc3M9XCJoZWFkZXItbGVmdFwiPlxuICAgIDxwLWJ1dHRvblxuICAgICAgaWNvbj1cInBpIHBpLWJhcnNcIlxuICAgICAgW3RleHRdPVwidHJ1ZVwiXG4gICAgICBzZXZlcml0eT1cInNlY29uZGFyeVwiXG4gICAgICBhcmlhTGFiZWw9XCJBYnJpciBtZW7DulwiXG4gICAgICBzdHlsZUNsYXNzPVwibW9iaWxlLW1lbnVcIlxuICAgICAgKG9uQ2xpY2spPVwibWVudUNsaWNrLmVtaXQoKVwiXG4gICAgLz5cbiAgICA8ZGl2PlxuICAgICAgPGgyPlBhbmVsIGFkbWluaXN0cmF0aXZvPC9oMj5cbiAgICAgIDxzcGFuPkJpZW52ZW5pZG8gYSB0dSBlc3BhY2lvIGRlIHRyYWJham88L3NwYW4+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuXG4gIDxkaXYgY2xhc3M9XCJoZWFkZXItcmlnaHRcIj5cbiAgICA8cC1hdmF0YXIgbGFiZWw9XCJBRFwiIHNoYXBlPVwiY2lyY2xlXCIgc2l6ZT1cImxhcmdlXCIgLz5cbiAgICA8ZGl2IGNsYXNzPVwidXNlci1pbmZvXCI+XG4gICAgICA8c3Ryb25nPkFkbWluaXN0cmFkb3I8L3N0cm9uZz5cbiAgICAgIDxzcGFuPkFkbWluPC9zcGFuPlxuICAgIDwvZGl2PlxuICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwibG9nb3V0LWJ1dHRvblwiIChjbGljayk9XCJsb2dvdXQoKVwiIGFyaWEtbGFiZWw9XCJDZXJyYXIgc2VzacOzblwiPlxuICAgICAgPGkgY2xhc3M9XCJwaSBwaS1zaWduLW91dFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvaT5cbiAgICAgIDxzcGFuPkNlcnJhciBzZXNpw7NuPC9zcGFuPlxuICAgIDwvYnV0dG9uPlxuICA8L2Rpdj5cbjwvaGVhZGVyPlxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsYUFBQUEsWUFBVyxjQUFjO0FBQ2xDLFNBQVMsb0JBQW9COzs7QUVEN0IsU0FBUyxXQUFXLFVBQVUsUUFBUSxjQUFjO0FBQ3BELFNBQVMsWUFBWSx3QkFBd0I7Ozs7OztBQ09yQyxJQUFBLDRCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQXVELElBQUEsd0JBQUEsU0FBQSxTQUFBLDRDQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFNBQUEsS0FBQSxDQUFlO0lBQUEsQ0FBQTtBQUMzRSxJQUFBLHVCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLENBQUE7QUFBZ0IsSUFBQSwwQkFBQSxFQUFPOzs7O0FBRjlCLElBQUEsd0JBQUEsY0FBQSxRQUFBLEtBQUE7QUFDSSxJQUFBLHVCQUFBO0FBQUEsSUFBQSx3QkFBQSxRQUFBLElBQUE7QUFDRyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFFBQUEsS0FBQTs7O0FEU1osSUFBTyxVQUFQLE1BQU8sU0FBTztFQUNULFdBQVcsT0FBTTtFQUNqQixjQUFjLE9BQU8saUJBQWlCO0VBQ3RDLFlBQWlDO0lBQ3hDO01BQ0UsT0FBTztNQUNQLE1BQU07TUFDTixPQUFPO01BQ1AsWUFBWTs7SUFFZDtNQUNFLE9BQU87TUFDUCxNQUFNO01BQ04sT0FBTztNQUNQLFlBQVk7O0lBRWQ7TUFDRSxPQUFPO01BQ1AsTUFBTTtNQUNOLE9BQU87TUFDUCxZQUFZOzs7RUFJUCxtQkFBbUIsU0FBUyxNQUNuQyxLQUFLLFVBQVUsT0FBTyxDQUFDLFNBQVMsQ0FBQyxLQUFLLGNBQWMsS0FBSyxZQUFZLElBQUksS0FBSyxVQUFVLENBQUMsR0FBQyxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsbUJBQUEsQ0FBQTs7SUFBQSxDQUFBO0dBQUE7O3FDQXpCakYsVUFBTztFQUFBOzRFQUFQLFVBQU8sV0FBQSxDQUFBLENBQUEsYUFBQSxDQUFBLEdBQUEsU0FBQSxFQUFBLFVBQUEsV0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGVBQUEsUUFBQSxHQUFBLE1BQUEsY0FBQSxHQUFBLENBQUEsY0FBQSx5QkFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxvQkFBQSxVQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsb0JBQUEsVUFBQSxHQUFBLFNBQUEsWUFBQSxHQUFBLENBQUEsZUFBQSxNQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsaUJBQUEsSUFBQSxLQUFBO0FBQUEsUUFBQSxLQUFBLEdBQUE7QUNuQnBCLE1BQUEsNEJBQUEsR0FBQSxTQUFBLENBQUEsRUFBdUIsR0FBQSxPQUFBLENBQUE7QUFFZixNQUFBLHVCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQ0EsTUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxNQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFVLE1BQUEsMEJBQUEsRUFBTztBQUUzQixNQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQXVDLEdBQUEsS0FBQSxDQUFBO0FBQ2IsTUFBQSxvQkFBQSxHQUFBLG1CQUFBO0FBQWMsTUFBQSwwQkFBQTtBQUNwQyxNQUFBLDhCQUFBLEdBQUEsd0JBQUEsR0FBQSxHQUFBLEtBQUEsR0FBQSxVQUFBO0FBTUosTUFBQSwwQkFBQSxFQUFNOzs7QUFORixNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLHdCQUFBLElBQUEsaUJBQUEsQ0FBa0I7O29CRFFkLFlBQVksZ0JBQWdCLEdBQUEsUUFBQSxDQUFBLGs5QkFBQSxFQUFBLENBQUE7OzsrRUFJM0IsU0FBTyxDQUFBO1VBUG5CO3VCQUNXLGVBQWEsWUFDWCxNQUFJLFNBQ1AsQ0FBQyxZQUFZLGdCQUFnQixHQUFDLFVBQUEsb2pCQUFBLFFBQUEsQ0FBQSx5eEJBQUEsRUFBQSxDQUFBOzs7O2dGQUk1QixTQUFPLEVBQUEsV0FBQSxXQUFBLFVBQUEsaUNBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7OzhEQUFQLFNBQU8sRUFBQSxTQUFBLENBQUEsRUFBQSxHQUFBLENBQUEsWUFBQSxrQkFBQSxTQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxnQkFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxnQkFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBRW5CcEIsU0FBUyxhQUFBQyxZQUFXLFVBQUFDLGVBQWM7QUFDbEMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxvQkFBb0I7QUFFN0IsU0FBUyxVQUFBQyxlQUFjO0FBQ3ZCLFNBQVMsY0FBYzs7Ozs7QUFZakIsSUFBT0MsVUFBUCxNQUFPLFFBQU07RUFDakIsWUFBWUMsUUFBTTtFQUVULGNBQWNDLFFBQU8sV0FBVztFQUN4QixTQUFTQSxRQUFPLE1BQU07RUFDdEIsVUFBVUEsUUFBTyxxQkFBcUI7RUFFdkQsU0FBTTtBQUNKLFNBQUssWUFBWSxPQUFNLEVBQUcsVUFBVTtNQUNsQyxNQUFNLE1BQUs7QUFDVCxhQUFLLFFBQVEsTUFBSztBQUNsQixhQUFLLEtBQUssT0FBTyxTQUFTLENBQUMsUUFBUSxDQUFDO01BQ3RDO01BQ0EsT0FBTyxNQUFLO0FBR1YsZ0JBQVEsTUFBTSxpQ0FBOEI7TUFJOUM7S0FDRDtFQUNIOztxQ0F0QlcsU0FBTTtFQUFBOzZFQUFOLFNBQU0sV0FBQSxDQUFBLENBQUEsWUFBQSxDQUFBLEdBQUEsU0FBQSxFQUFBLFdBQUEsWUFBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLFFBQUEsY0FBQSxZQUFBLGFBQUEsYUFBQSxpQkFBQSxjQUFBLGVBQUEsR0FBQSxXQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsU0FBQSxNQUFBLFNBQUEsVUFBQSxRQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLGNBQUEsb0JBQUEsR0FBQSxpQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGVBQUEsUUFBQSxHQUFBLE1BQUEsYUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGdCQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO0FDakJuQixNQUFBLDZCQUFBLEdBQUEsVUFBQSxDQUFBLEVBQXVCLEdBQUEsT0FBQSxDQUFBLEVBQ0ksR0FBQSxZQUFBLENBQUE7QUFPckIsTUFBQSx5QkFBQSxXQUFBLFNBQUEsOENBQUE7QUFBQSxlQUFXLElBQUEsVUFBQSxLQUFBO01BQWdCLENBQUE7QUFON0IsTUFBQSwyQkFBQTtBQVFBLE1BQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUssR0FBQSxJQUFBO0FBQ0MsTUFBQSxxQkFBQSxHQUFBLHNCQUFBO0FBQW9CLE1BQUEsMkJBQUE7QUFDeEIsTUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxNQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBa0MsTUFBQSwyQkFBQSxFQUFPLEVBQzNDO0FBR1IsTUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNFLE1BQUEsd0JBQUEsR0FBQSxZQUFBLENBQUE7QUFDQSxNQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXVCLElBQUEsUUFBQTtBQUNiLE1BQUEscUJBQUEsSUFBQSxlQUFBO0FBQWEsTUFBQSwyQkFBQTtBQUNyQixNQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLE1BQUEscUJBQUEsSUFBQSxPQUFBO0FBQUssTUFBQSwyQkFBQSxFQUFPO0FBRXBCLE1BQUEsNkJBQUEsSUFBQSxVQUFBLENBQUE7QUFBNEMsTUFBQSx5QkFBQSxTQUFBLFNBQUEsMkNBQUE7QUFBQSxlQUFTLElBQUEsT0FBQTtNQUFRLENBQUE7QUFDM0QsTUFBQSx3QkFBQSxJQUFBLEtBQUEsQ0FBQTtBQUNBLE1BQUEsNkJBQUEsSUFBQSxNQUFBO0FBQU0sTUFBQSxxQkFBQSxJQUFBLGtCQUFBO0FBQWEsTUFBQSwyQkFBQSxFQUFPLEVBQ25CLEVBQ0w7OztBQXRCRixNQUFBLHdCQUFBLENBQUE7QUFBQSxNQUFBLHlCQUFBLFFBQUEsSUFBQTs7b0JEU00sY0FBWSxvQkFBQSxXQUFBLGdCQUFBLGVBQUEsV0FBQSxXQUFBLGtCQUFFLGNBQVksU0FBQSxHQUFBLFFBQUEsQ0FBQSwyNENBQUEsRUFBQSxDQUFBOzs7Z0ZBSXpCRixTQUFNLENBQUE7VUFObEJHO3VCQUNXLGNBQVksU0FDYixDQUFDLGNBQWMsWUFBWSxHQUFDLFVBQUEsb3lCQUFBLFFBQUEsQ0FBQSw4cUNBQUEsRUFBQSxDQUFBOzs7O2lGQUkxQkgsU0FBTSxFQUFBLFdBQUEsVUFBQSxVQUFBLCtCQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OzsrREFBTkEsU0FBTSxFQUFBLFNBQUEsQ0FBQUksS0FBQSxJQUFBLElBQUEsRUFBQSxHQUFBLENBQUEsY0FBQSxjQUFBRCxVQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxlQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLGVBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7O0FIZmYsSUFBQSw2QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUlFLElBQUEseUJBQUEsU0FBQSxTQUFBLDZEQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBQSwwQkFBUyxPQUFBLGFBQUEsQ0FBYztJQUFBLENBQUE7QUFDeEIsSUFBQSwyQkFBQTs7O0FES0MsSUFBTyxjQUFQLE1BQU8sYUFBVztFQUN0QixjQUFjLE9BQU8sT0FBSyxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsY0FBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUMxQixnQkFBYTtBQUNYLFNBQUssWUFBWSxPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUs7RUFDM0M7RUFDQSxlQUFZO0FBQ1YsU0FBSyxZQUFZLElBQUksS0FBSztFQUM1Qjs7cUNBUFcsY0FBVztFQUFBOzZFQUFYLGNBQVcsV0FBQSxDQUFBLENBQUEsa0JBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsY0FBQSxrQkFBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxNQUFBLGdCQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLGNBQUEsa0JBQUEsR0FBQSxvQkFBQSxHQUFBLE9BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxxQkFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ1p4QixNQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0UsTUFBQSxrQ0FBQSxHQUFBLG9DQUFBLEdBQUEsR0FBQSxVQUFBLENBQUE7QUFRQSxNQUFBLDZCQUFBLEdBQUEsZUFBQSxDQUFBO0FBQTZDLE1BQUEseUJBQUEsWUFBQSxTQUFBLHVEQUFBO0FBQUEsZUFBWSxJQUFBLGFBQUE7TUFBYyxDQUFBO0FBQXZFLE1BQUEsMkJBQUE7QUFDQSxNQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQTBCLEdBQUEsY0FBQSxDQUFBO0FBQ1osTUFBQSx5QkFBQSxhQUFBLFNBQUEsdURBQUE7QUFBQSxlQUFhLElBQUEsY0FBQTtNQUFlLENBQUE7QUFBeEMsTUFBQSwyQkFBQTtBQUNBLE1BQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFDRSxNQUFBLHdCQUFBLEdBQUEsZUFBQTtBQUNGLE1BQUEsMkJBQUEsRUFBTyxFQUNIOzs7QUFkTixNQUFBLHdCQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBLFlBQUEsSUFBQSxJQUFBLEVBQUE7QUFRYSxNQUFBLHdCQUFBO0FBQUEsTUFBQSwwQkFBQSxXQUFBLElBQUEsWUFBQSxDQUFBOztvQkRGSCxjQUFjLFNBQVNFLE9BQU0sR0FBQSxRQUFBLENBQUEsZzhCQUFBLEVBQUEsQ0FBQTs7O2dGQUs1QixhQUFXLENBQUE7VUFQdkJDO3VCQUNXLG9CQUFrQixTQUNuQixDQUFDLGNBQWMsU0FBU0QsT0FBTSxHQUFDLFVBQUEsNmRBQUEsUUFBQSxDQUFBLDAwQkFBQSxFQUFBLENBQUE7Ozs7aUZBSzdCLGFBQVcsRUFBQSxXQUFBLGVBQUEsVUFBQSwyQ0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7K0RBQVgsYUFBVyxFQUFBLFNBQUEsQ0FBQUUsR0FBQSxHQUFBLENBQUEsY0FBQSxTQUFBRixTQUFBQyxVQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxvQkFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxvQkFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7IiwibmFtZXMiOlsiQ29tcG9uZW50IiwiQ29tcG9uZW50Iiwib3V0cHV0IiwiaW5qZWN0IiwiSGVhZGVyIiwib3V0cHV0IiwiaW5qZWN0IiwiQ29tcG9uZW50IiwiaTAiLCJIZWFkZXIiLCJDb21wb25lbnQiLCJpMCJdfQ==