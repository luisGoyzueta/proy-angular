import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/chunk-E3YFFTZW.js");import {
  AuthService
} from "/chunk-HUEL4CRJ.js";
import "/chunk-P37EOHI7.js";
import "/chunk-VUJOFXKG.js";

// src/app/features/auth/login/login.ts
import { Component, inject, signal } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { FormBuilder, ReactiveFormsModule, Validators } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_forms.js?v=b9a49161";
import { Router, ActivatedRoute } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_router.js?v=b9a49161";
import { ButtonModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_button.js?v=b9a49161";
import { InputTextModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_inputtext.js?v=b9a49161";
import { PasswordModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_password.js?v=b9a49161";
import { MessageModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_message.js?v=b9a49161";
import { finalize } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/rxjs.js?v=b9a49161";
import * as i0 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import * as i1 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_forms.js?v=b9a49161";
import * as i2 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_button.js?v=b9a49161";
import * as i3 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_api.js?v=b9a49161";
import * as i4 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_inputtext.js?v=b9a49161";
import * as i5 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_password.js?v=b9a49161";
import * as i6 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_bind.js?v=b9a49161";
import * as i7 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_message.js?v=b9a49161";
function Login_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "small", 9);
    i0.\u0275\u0275text(1, " Ingresa un correo electr\xF3nico v\xE1lido. ");
    i0.\u0275\u0275elementEnd();
  }
}
function Login_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "small", 12);
    i0.\u0275\u0275text(1, " La contrase\xF1a es obligatoria. ");
    i0.\u0275\u0275elementEnd();
  }
}
function Login_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "p-message", 13);
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", ctx_r0.errorMessage(), " ");
  }
}
var Login = class _Login {
  fb = inject(FormBuilder);
  authService = inject(AuthService);
  router = inject(Router);
  route = inject(ActivatedRoute);
  loading = signal(false, ...ngDevMode ? [{ debugName: "loading" }] : (
    /* istanbul ignore next */
    []
  ));
  errorMessage = signal("", ...ngDevMode ? [{ debugName: "errorMessage" }] : (
    /* istanbul ignore next */
    []
  ));
  form = this.fb.nonNullable.group({
    email: ["", [Validators.required, Validators.email]],
    password: ["", [Validators.required]]
  });
  submit() {
    this.form.markAllAsTouched();
    if (this.form.invalid || this.loading()) {
      return;
    }
    this.loading.set(true);
    this.errorMessage.set("");
    const credentials = this.form.getRawValue();
    this.authService.login(credentials).pipe(finalize(() => this.loading.set(false))).subscribe({
      next: () => {
        const returnUrl = this.route.snapshot.queryParamMap.get("returnUrl");
        const destination = returnUrl?.startsWith("/") && !returnUrl.startsWith("//") && !returnUrl.startsWith("/\\") ? returnUrl : "/dashboard";
        void this.router.navigateByUrl(destination);
      },
      error: (error) => {
        if (error.status === 401) {
          this.errorMessage.set("Correo electr\xF3nico o contrase\xF1a incorrectos.");
        } else if (error.status === 429) {
          this.errorMessage.set("Demasiados intentos. Int\xE9ntalo m\xE1s tarde.");
        } else {
          this.errorMessage.set("No se pudo iniciar sesi\xF3n. Verifica la conexi\xF3n.");
        }
      }
    });
  }
  static \u0275fac = function Login_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Login)();
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _Login, selectors: [["app-login"]], decls: 22, vars: 11, consts: [[1, "login-page"], [1, "login-card"], [1, "login-brand"], [1, "brand-icon"], ["aria-hidden", "true", 1, "pi", "pi-shield"], [1, "login-form", 3, "ngSubmit", "formGroup"], [1, "form-field"], ["for", "email"], ["pInputText", "", "id", "email", "type", "email", "formControlName", "email", "autocomplete", "username", "placeholder", "admin@demo.com"], ["id", "email-error", 1, "field-error"], ["for", "password"], ["inputId", "password", "formControlName", "password", "autocomplete", "current-password", "placeholder", "Ingresa tu contrase\xF1a", 3, "feedback", "toggleMask", "fluid"], [1, "field-error"], ["severity", "error", "role", "alert"], ["type", "submit", "label", "Ingresar", "icon", "pi pi-sign-in", 3, "loading", "disabled", "fluid"]], template: function Login_Template(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275elementStart(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
      i0.\u0275\u0275element(4, "i", 4);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(5, "h1");
      i0.\u0275\u0275text(6, "Iniciar sesi\xF3n");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(7, "p");
      i0.\u0275\u0275text(8, "Ingresa tus credenciales para acceder al dashboard.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(9, "form", 5);
      i0.\u0275\u0275listener("ngSubmit", function Login_Template_form_ngSubmit_9_listener() {
        return ctx.submit();
      });
      i0.\u0275\u0275elementStart(10, "div", 6)(11, "label", 7);
      i0.\u0275\u0275text(12, "Correo electr\xF3nico");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275element(13, "input", 8);
      i0.\u0275\u0275conditionalCreate(14, Login_Conditional_14_Template, 2, 0, "small", 9);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(15, "div", 6)(16, "label", 10);
      i0.\u0275\u0275text(17, "Contrase\xF1a");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275element(18, "p-password", 11);
      i0.\u0275\u0275conditionalCreate(19, Login_Conditional_19_Template, 2, 0, "small", 12);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275conditionalCreate(20, Login_Conditional_20_Template, 2, 1, "p-message", 13);
      i0.\u0275\u0275element(21, "p-button", 14);
      i0.\u0275\u0275elementEnd()()();
    }
    if (rf & 2) {
      i0.\u0275\u0275advance(9);
      i0.\u0275\u0275property("formGroup", ctx.form);
      i0.\u0275\u0275advance(4);
      i0.\u0275\u0275attribute("aria-invalid", ctx.form.controls.email.invalid && ctx.form.controls.email.touched);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.form.controls.email.invalid && ctx.form.controls.email.touched ? 14 : -1);
      i0.\u0275\u0275advance(4);
      i0.\u0275\u0275property("feedback", false)("toggleMask", true)("fluid", true);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.form.controls.password.invalid && ctx.form.controls.password.touched ? 19 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.errorMessage() ? 20 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275property("loading", ctx.loading())("disabled", ctx.loading())("fluid", true);
    }
  }, dependencies: [ReactiveFormsModule, i1.\u0275NgNoValidate, i1.NgSelectOption, i1.\u0275NgSelectMultipleOption, i1.DefaultValueAccessor, i1.NumberValueAccessor, i1.RangeValueAccessor, i1.CheckboxControlValueAccessor, i1.SelectControlValueAccessor, i1.SelectMultipleControlValueAccessor, i1.RadioControlValueAccessor, i1.NgControlStatus, i1.NgControlStatusGroup, i1.RequiredValidator, i1.MinLengthValidator, i1.MaxLengthValidator, i1.PatternValidator, i1.CheckboxRequiredValidator, i1.EmailValidator, i1.MinValidator, i1.MaxValidator, i1.FormControlDirective, i1.FormGroupDirective, i1.FormArrayDirective, i1.FormControlName, i1.FormGroupName, i1.FormArrayName, ButtonModule, i2.ButtonDirective, i2.Button, i2.ButtonLabel, i2.ButtonIcon, i3.Header, i3.Footer, i3.PrimeTemplate, InputTextModule, i4.InputText, PasswordModule, i5.PasswordDirective, i5.Password, i6.Bind, MessageModule, i7.Message], styles: ["\n.login-page[_ngcontent-%COMP%] {\n  min-height: 100dvh;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 24px;\n  background:\n    radial-gradient(\n      circle at top left,\n      rgba(99, 102, 241, 0.14),\n      transparent 40%),\n    #f8fafc;\n}\n.login-card[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 430px;\n  padding: 36px;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 20px;\n  box-shadow: 0 20px 60px rgba(15, 23, 42, 0.08);\n}\n.login-brand[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 30px;\n}\n.login-brand[_ngcontent-%COMP%]   .brand-icon[_ngcontent-%COMP%] {\n  width: 56px;\n  height: 56px;\n  display: grid;\n  place-items: center;\n  margin: 0 auto 18px;\n  border-radius: 16px;\n  color: #ffffff;\n  background: #4f46e5;\n  font-size: 24px;\n}\n.login-brand[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  margin: 0 0 10px;\n  font-size: 26px;\n  color: #0f172a;\n}\n.login-brand[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  color: #64748b;\n  font-size: 14px;\n  line-height: 1.6;\n}\n.login-form[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 20px;\n}\n.form-field[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.form-field[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 600;\n  color: #334155;\n}\n.form-field[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: 100%;\n}\n.field-error[_ngcontent-%COMP%] {\n  color: #dc2626;\n  font-size: 12px;\n}\n.login-demo[_ngcontent-%COMP%] {\n  margin-top: 26px;\n  padding: 14px;\n  border-radius: 10px;\n  background: #f1f5f9;\n  text-align: center;\n}\n.login-demo[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #64748b;\n  font-size: 12px;\n}\n.login-demo[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 8px 0 0;\n  font-size: 13px;\n  font-weight: 600;\n  color: #334155;\n  overflow-wrap: anywhere;\n}\n@media (max-width: 480px) {\n  .login-card[_ngcontent-%COMP%] {\n    padding: 24px;\n  }\n}\n/*# sourceMappingURL=login.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(Login, [{
    type: Component,
    args: [{ selector: "app-login", standalone: true, imports: [ReactiveFormsModule, ButtonModule, InputTextModule, PasswordModule, MessageModule], template: '<div class="login-page">\n  <div class="login-card">\n    <div class="login-brand">\n      <div class="brand-icon">\n        <i class="pi pi-shield" aria-hidden="true"></i>\n      </div>\n\n      <h1>Iniciar sesi\xF3n</h1>\n      <p>Ingresa tus credenciales para acceder al dashboard.</p>\n    </div>\n\n    <form [formGroup]="form" (ngSubmit)="submit()" class="login-form">\n      <div class="form-field">\n        <label for="email">Correo electr\xF3nico</label>\n        <input\n          pInputText\n          id="email"\n          type="email"\n          formControlName="email"\n          autocomplete="username"\n          placeholder="admin@demo.com"\n          [attr.aria-invalid]="form.controls.email.invalid && form.controls.email.touched"\n        />\n\n        @if (form.controls.email.invalid && form.controls.email.touched) {\n          <small class="field-error" id="email-error">\n            Ingresa un correo electr\xF3nico v\xE1lido.\n          </small>\n        }\n      </div>\n\n      <div class="form-field">\n        <label for="password">Contrase\xF1a</label>\n        <p-password\n          inputId="password"\n          formControlName="password"\n          [feedback]="false"\n          [toggleMask]="true"\n          [fluid]="true"\n          autocomplete="current-password"\n          placeholder="Ingresa tu contrase\xF1a"\n        />\n\n        @if (form.controls.password.invalid && form.controls.password.touched) {\n          <small class="field-error"> La contrase\xF1a es obligatoria. </small>\n        }\n      </div>\n\n      @if (errorMessage()) {\n        <p-message severity="error" role="alert">\n          {{ errorMessage() }}\n        </p-message>\n      }\n\n      <p-button\n        type="submit"\n        label="Ingresar"\n        icon="pi pi-sign-in"\n        [loading]="loading()"\n        [disabled]="loading()"\n        [fluid]="true"\n      />\n    </form>\n  </div>\n</div>\n', styles: ["/* src/app/features/auth/login/login.scss */\n.login-page {\n  min-height: 100dvh;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 24px;\n  background:\n    radial-gradient(\n      circle at top left,\n      rgba(99, 102, 241, 0.14),\n      transparent 40%),\n    #f8fafc;\n}\n.login-card {\n  width: 100%;\n  max-width: 430px;\n  padding: 36px;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 20px;\n  box-shadow: 0 20px 60px rgba(15, 23, 42, 0.08);\n}\n.login-brand {\n  text-align: center;\n  margin-bottom: 30px;\n}\n.login-brand .brand-icon {\n  width: 56px;\n  height: 56px;\n  display: grid;\n  place-items: center;\n  margin: 0 auto 18px;\n  border-radius: 16px;\n  color: #ffffff;\n  background: #4f46e5;\n  font-size: 24px;\n}\n.login-brand h1 {\n  margin: 0 0 10px;\n  font-size: 26px;\n  color: #0f172a;\n}\n.login-brand p {\n  margin: 0;\n  color: #64748b;\n  font-size: 14px;\n  line-height: 1.6;\n}\n.login-form {\n  display: flex;\n  flex-direction: column;\n  gap: 20px;\n}\n.form-field {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.form-field label {\n  font-size: 14px;\n  font-weight: 600;\n  color: #334155;\n}\n.form-field input {\n  width: 100%;\n}\n.field-error {\n  color: #dc2626;\n  font-size: 12px;\n}\n.login-demo {\n  margin-top: 26px;\n  padding: 14px;\n  border-radius: 10px;\n  background: #f1f5f9;\n  text-align: center;\n}\n.login-demo span {\n  color: #64748b;\n  font-size: 12px;\n}\n.login-demo p {\n  margin: 8px 0 0;\n  font-size: 13px;\n  font-weight: 600;\n  color: #334155;\n  overflow-wrap: anywhere;\n}\n@media (max-width: 480px) {\n  .login-card {\n    padding: 24px;\n  }\n}\n/*# sourceMappingURL=login.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(Login, { className: "Login", filePath: "app/features/auth/login/login.ts", lineNumber: 21 });
})();
(() => {
  const id = "app%2Ffeatures%2Fauth%2Flogin%2Flogin.ts%40Login";
  function Login_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i0.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i0.\u0275\u0275replaceMetadata(Login, m.default, [i0, i1, i2, i3, i4, i5, i6, i7], [ReactiveFormsModule, ButtonModule, InputTextModule, PasswordModule, MessageModule, Component], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Login_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Login_HmrLoad(d.timestamp)));
})();
export {
  Login
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZmVhdHVyZXMvYXV0aC9sb2dpbi9sb2dpbi50cyIsInNyYy9hcHAvZmVhdHVyZXMvYXV0aC9sb2dpbi9sb2dpbi5odG1sIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgaW5qZWN0LCBzaWduYWwgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZvcm1CdWlsZGVyLCBSZWFjdGl2ZUZvcm1zTW9kdWxlLCBWYWxpZGF0b3JzIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgUm91dGVyLCBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBCdXR0b25Nb2R1bGUgfSBmcm9tICdwcmltZW5nL2J1dHRvbic7XG5pbXBvcnQgeyBJbnB1dFRleHRNb2R1bGUgfSBmcm9tICdwcmltZW5nL2lucHV0dGV4dCc7XG5pbXBvcnQgeyBQYXNzd29yZE1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvcGFzc3dvcmQnO1xuaW1wb3J0IHsgTWVzc2FnZU1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvbWVzc2FnZSc7XG5cbmltcG9ydCB7IEF1dGhTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vLi4vY29yZS9zZXJ2aWNlcy9hdXRoJztcbmltcG9ydCB7IEh0dHBFcnJvclJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgZmluYWxpemUgfSBmcm9tICdyeGpzJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYXBwLWxvZ2luJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW1JlYWN0aXZlRm9ybXNNb2R1bGUsIEJ1dHRvbk1vZHVsZSwgSW5wdXRUZXh0TW9kdWxlLCBQYXNzd29yZE1vZHVsZSwgTWVzc2FnZU1vZHVsZV0sXG4gIHRlbXBsYXRlVXJsOiAnLi9sb2dpbi5odG1sJyxcbiAgc3R5bGVVcmw6ICcuL2xvZ2luLnNjc3MnLFxufSlcblxuZXhwb3J0IGNsYXNzIExvZ2luIHtcbiAgcHJpdmF0ZSByZWFkb25seSBmYiA9IGluamVjdChGb3JtQnVpbGRlcik7XG4gIHByaXZhdGUgcmVhZG9ubHkgYXV0aFNlcnZpY2UgPSBpbmplY3QoQXV0aFNlcnZpY2UpO1xuICBwcml2YXRlIHJlYWRvbmx5IHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xuICBwcml2YXRlIHJlYWRvbmx5IHJvdXRlID0gaW5qZWN0KEFjdGl2YXRlZFJvdXRlKTtcblxuICByZWFkb25seSBsb2FkaW5nID0gc2lnbmFsKGZhbHNlKTtcbiAgcmVhZG9ubHkgZXJyb3JNZXNzYWdlID0gc2lnbmFsKCcnKTtcblxuICByZWFkb25seSBmb3JtID0gdGhpcy5mYi5ub25OdWxsYWJsZS5ncm91cCh7XG4gICAgZW1haWw6IFsnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRvcnMuZW1haWxdXSxcbiAgICBwYXNzd29yZDogWycnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZF1dLFxuICB9KTtcblxuICBzdWJtaXQoKTogdm9pZCB7XG4gICAgdGhpcy5mb3JtLm1hcmtBbGxBc1RvdWNoZWQoKTtcblxuICAgIGlmICh0aGlzLmZvcm0uaW52YWxpZCB8fCB0aGlzLmxvYWRpbmcoKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMubG9hZGluZy5zZXQodHJ1ZSk7XG4gICAgdGhpcy5lcnJvck1lc3NhZ2Uuc2V0KCcnKTtcblxuICAgIGNvbnN0IGNyZWRlbnRpYWxzID0gdGhpcy5mb3JtLmdldFJhd1ZhbHVlKCk7XG5cbiAgICB0aGlzLmF1dGhTZXJ2aWNlXG4gICAgICAubG9naW4oY3JlZGVudGlhbHMpXG4gICAgICAucGlwZShmaW5hbGl6ZSgoKSA9PiB0aGlzLmxvYWRpbmcuc2V0KGZhbHNlKSkpXG4gICAgICAuc3Vic2NyaWJlKHtcbiAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHJldHVyblVybCA9IHRoaXMucm91dGUuc25hcHNob3QucXVlcnlQYXJhbU1hcC5nZXQoJ3JldHVyblVybCcpO1xuXG4gICAgICAgICAgY29uc3QgZGVzdGluYXRpb24gPVxuICAgICAgICAgICAgcmV0dXJuVXJsPy5zdGFydHNXaXRoKCcvJykgJiZcbiAgICAgICAgICAgICFyZXR1cm5Vcmwuc3RhcnRzV2l0aCgnLy8nKSAmJlxuICAgICAgICAgICAgIXJldHVyblVybC5zdGFydHNXaXRoKCcvXFxcXCcpXG4gICAgICAgICAgICAgID8gcmV0dXJuVXJsXG4gICAgICAgICAgICAgIDogJy9kYXNoYm9hcmQnO1xuXG4gICAgICAgICAgdm9pZCB0aGlzLnJvdXRlci5uYXZpZ2F0ZUJ5VXJsKGRlc3RpbmF0aW9uKTtcbiAgICAgICAgfSxcbiAgICAgICAgZXJyb3I6IChlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MDEpIHtcbiAgICAgICAgICAgIHRoaXMuZXJyb3JNZXNzYWdlLnNldCgnQ29ycmVvIGVsZWN0csOzbmljbyBvIGNvbnRyYXNlw7FhIGluY29ycmVjdG9zLicpO1xuICAgICAgICAgIH0gZWxzZSBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MjkpIHtcbiAgICAgICAgICAgIHRoaXMuZXJyb3JNZXNzYWdlLnNldCgnRGVtYXNpYWRvcyBpbnRlbnRvcy4gSW50w6ludGFsbyBtw6FzIHRhcmRlLicpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmVycm9yTWVzc2FnZS5zZXQoJ05vIHNlIHB1ZG8gaW5pY2lhciBzZXNpw7NuLiBWZXJpZmljYSBsYSBjb25leGnDs24uJyk7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgfSk7XG4gIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJsb2dpbi1wYWdlXCI+XG4gIDxkaXYgY2xhc3M9XCJsb2dpbi1jYXJkXCI+XG4gICAgPGRpdiBjbGFzcz1cImxvZ2luLWJyYW5kXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiYnJhbmQtaWNvblwiPlxuICAgICAgICA8aSBjbGFzcz1cInBpIHBpLXNoaWVsZFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvaT5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8aDE+SW5pY2lhciBzZXNpw7NuPC9oMT5cbiAgICAgIDxwPkluZ3Jlc2EgdHVzIGNyZWRlbmNpYWxlcyBwYXJhIGFjY2VkZXIgYWwgZGFzaGJvYXJkLjwvcD5cbiAgICA8L2Rpdj5cblxuICAgIDxmb3JtIFtmb3JtR3JvdXBdPVwiZm9ybVwiIChuZ1N1Ym1pdCk9XCJzdWJtaXQoKVwiIGNsYXNzPVwibG9naW4tZm9ybVwiPlxuICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZmllbGRcIj5cbiAgICAgICAgPGxhYmVsIGZvcj1cImVtYWlsXCI+Q29ycmVvIGVsZWN0csOzbmljbzwvbGFiZWw+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHBJbnB1dFRleHRcbiAgICAgICAgICBpZD1cImVtYWlsXCJcbiAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgIGZvcm1Db250cm9sTmFtZT1cImVtYWlsXCJcbiAgICAgICAgICBhdXRvY29tcGxldGU9XCJ1c2VybmFtZVwiXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJhZG1pbkBkZW1vLmNvbVwiXG4gICAgICAgICAgW2F0dHIuYXJpYS1pbnZhbGlkXT1cImZvcm0uY29udHJvbHMuZW1haWwuaW52YWxpZCAmJiBmb3JtLmNvbnRyb2xzLmVtYWlsLnRvdWNoZWRcIlxuICAgICAgICAvPlxuXG4gICAgICAgIEBpZiAoZm9ybS5jb250cm9scy5lbWFpbC5pbnZhbGlkICYmIGZvcm0uY29udHJvbHMuZW1haWwudG91Y2hlZCkge1xuICAgICAgICAgIDxzbWFsbCBjbGFzcz1cImZpZWxkLWVycm9yXCIgaWQ9XCJlbWFpbC1lcnJvclwiPlxuICAgICAgICAgICAgSW5ncmVzYSB1biBjb3JyZW8gZWxlY3Ryw7NuaWNvIHbDoWxpZG8uXG4gICAgICAgICAgPC9zbWFsbD5cbiAgICAgICAgfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWZpZWxkXCI+XG4gICAgICAgIDxsYWJlbCBmb3I9XCJwYXNzd29yZFwiPkNvbnRyYXNlw7FhPC9sYWJlbD5cbiAgICAgICAgPHAtcGFzc3dvcmRcbiAgICAgICAgICBpbnB1dElkPVwicGFzc3dvcmRcIlxuICAgICAgICAgIGZvcm1Db250cm9sTmFtZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICBbZmVlZGJhY2tdPVwiZmFsc2VcIlxuICAgICAgICAgIFt0b2dnbGVNYXNrXT1cInRydWVcIlxuICAgICAgICAgIFtmbHVpZF09XCJ0cnVlXCJcbiAgICAgICAgICBhdXRvY29tcGxldGU9XCJjdXJyZW50LXBhc3N3b3JkXCJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIkluZ3Jlc2EgdHUgY29udHJhc2XDsWFcIlxuICAgICAgICAvPlxuXG4gICAgICAgIEBpZiAoZm9ybS5jb250cm9scy5wYXNzd29yZC5pbnZhbGlkICYmIGZvcm0uY29udHJvbHMucGFzc3dvcmQudG91Y2hlZCkge1xuICAgICAgICAgIDxzbWFsbCBjbGFzcz1cImZpZWxkLWVycm9yXCI+IExhIGNvbnRyYXNlw7FhIGVzIG9ibGlnYXRvcmlhLiA8L3NtYWxsPlxuICAgICAgICB9XG4gICAgICA8L2Rpdj5cblxuICAgICAgQGlmIChlcnJvck1lc3NhZ2UoKSkge1xuICAgICAgICA8cC1tZXNzYWdlIHNldmVyaXR5PVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICB7eyBlcnJvck1lc3NhZ2UoKSB9fVxuICAgICAgICA8L3AtbWVzc2FnZT5cbiAgICAgIH1cblxuICAgICAgPHAtYnV0dG9uXG4gICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICBsYWJlbD1cIkluZ3Jlc2FyXCJcbiAgICAgICAgaWNvbj1cInBpIHBpLXNpZ24taW5cIlxuICAgICAgICBbbG9hZGluZ109XCJsb2FkaW5nKClcIlxuICAgICAgICBbZGlzYWJsZWRdPVwibG9hZGluZygpXCJcbiAgICAgICAgW2ZsdWlkXT1cInRydWVcIlxuICAgICAgLz5cbiAgICA8L2Zvcm0+XG4gIDwvZGl2PlxuPC9kaXY+XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQSxTQUFTLFdBQVcsUUFBUSxjQUFjO0FBQzFDLFNBQVMsYUFBYSxxQkFBcUIsa0JBQWtCO0FBQzdELFNBQVMsUUFBUSxzQkFBc0I7QUFDdkMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxxQkFBcUI7QUFJOUIsU0FBUyxnQkFBZ0I7Ozs7Ozs7Ozs7O0FDZWYsSUFBQSw0QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQUNFLElBQUEsb0JBQUEsR0FBQSwrQ0FBQTtBQUNGLElBQUEsMEJBQUE7Ozs7O0FBaUJBLElBQUEsNEJBQUEsR0FBQSxTQUFBLEVBQUE7QUFBNEIsSUFBQSxvQkFBQSxHQUFBLG9DQUFBO0FBQThCLElBQUEsMEJBQUE7Ozs7O0FBSzVELElBQUEsNEJBQUEsR0FBQSxhQUFBLEVBQUE7QUFDRSxJQUFBLG9CQUFBLENBQUE7QUFDRixJQUFBLDBCQUFBOzs7O0FBREUsSUFBQSx1QkFBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxPQUFBLGFBQUEsR0FBQSxHQUFBOzs7QUQ5QkosSUFBTyxRQUFQLE1BQU8sT0FBSztFQUNDLEtBQUssT0FBTyxXQUFXO0VBQ3ZCLGNBQWMsT0FBTyxXQUFXO0VBQ2hDLFNBQVMsT0FBTyxNQUFNO0VBQ3RCLFFBQVEsT0FBTyxjQUFjO0VBRXJDLFVBQVUsT0FBTyxPQUFLLEdBQUEsWUFBQSxDQUFBLEVBQUEsV0FBQSxVQUFBLENBQUE7O0lBQUEsQ0FBQTtHQUFBO0VBQ3RCLGVBQWUsT0FBTyxJQUFFLEdBQUEsWUFBQSxDQUFBLEVBQUEsV0FBQSxlQUFBLENBQUE7O0lBQUEsQ0FBQTtHQUFBO0VBRXhCLE9BQU8sS0FBSyxHQUFHLFlBQVksTUFBTTtJQUN4QyxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsVUFBVSxXQUFXLEtBQUssQ0FBQztJQUNuRCxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsUUFBUSxDQUFDO0dBQ3JDO0VBRUQsU0FBTTtBQUNKLFNBQUssS0FBSyxpQkFBZ0I7QUFFMUIsUUFBSSxLQUFLLEtBQUssV0FBVyxLQUFLLFFBQU8sR0FBSTtBQUN2QztJQUNGO0FBRUEsU0FBSyxRQUFRLElBQUksSUFBSTtBQUNyQixTQUFLLGFBQWEsSUFBSSxFQUFFO0FBRXhCLFVBQU0sY0FBYyxLQUFLLEtBQUssWUFBVztBQUV6QyxTQUFLLFlBQ0YsTUFBTSxXQUFXLEVBQ2pCLEtBQUssU0FBUyxNQUFNLEtBQUssUUFBUSxJQUFJLEtBQUssQ0FBQyxDQUFDLEVBQzVDLFVBQVU7TUFDVCxNQUFNLE1BQUs7QUFDVCxjQUFNLFlBQVksS0FBSyxNQUFNLFNBQVMsY0FBYyxJQUFJLFdBQVc7QUFFbkUsY0FBTSxjQUNKLFdBQVcsV0FBVyxHQUFHLEtBQ3pCLENBQUMsVUFBVSxXQUFXLElBQUksS0FDMUIsQ0FBQyxVQUFVLFdBQVcsS0FBSyxJQUN2QixZQUNBO0FBRU4sYUFBSyxLQUFLLE9BQU8sY0FBYyxXQUFXO01BQzVDO01BQ0EsT0FBTyxDQUFDLFVBQTRCO0FBQ2xDLFlBQUksTUFBTSxXQUFXLEtBQUs7QUFDeEIsZUFBSyxhQUFhLElBQUksb0RBQThDO1FBQ3RFLFdBQVcsTUFBTSxXQUFXLEtBQUs7QUFDL0IsZUFBSyxhQUFhLElBQUksaURBQTJDO1FBQ25FLE9BQU87QUFDTCxlQUFLLGFBQWEsSUFBSSx3REFBa0Q7UUFDMUU7TUFDRjtLQUNEO0VBQ0w7O3FDQXBEVyxRQUFLO0VBQUE7NEVBQUwsUUFBSyxXQUFBLENBQUEsQ0FBQSxXQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsZUFBQSxRQUFBLEdBQUEsTUFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxZQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsT0FBQSxPQUFBLEdBQUEsQ0FBQSxjQUFBLElBQUEsTUFBQSxTQUFBLFFBQUEsU0FBQSxtQkFBQSxTQUFBLGdCQUFBLFlBQUEsZUFBQSxnQkFBQSxHQUFBLENBQUEsTUFBQSxlQUFBLEdBQUEsYUFBQSxHQUFBLENBQUEsT0FBQSxVQUFBLEdBQUEsQ0FBQSxXQUFBLFlBQUEsbUJBQUEsWUFBQSxnQkFBQSxvQkFBQSxlQUFBLDRCQUFBLEdBQUEsWUFBQSxjQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLENBQUEsWUFBQSxTQUFBLFFBQUEsT0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLFNBQUEsWUFBQSxRQUFBLGlCQUFBLEdBQUEsV0FBQSxZQUFBLE9BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxlQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO0FDcEJsQixNQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQXdCLEdBQUEsT0FBQSxDQUFBLEVBQ0UsR0FBQSxPQUFBLENBQUEsRUFDRyxHQUFBLE9BQUEsQ0FBQTtBQUVyQixNQUFBLHVCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQ0YsTUFBQSwwQkFBQTtBQUVBLE1BQUEsNEJBQUEsR0FBQSxJQUFBO0FBQUksTUFBQSxvQkFBQSxHQUFBLG1CQUFBO0FBQWMsTUFBQSwwQkFBQTtBQUNsQixNQUFBLDRCQUFBLEdBQUEsR0FBQTtBQUFHLE1BQUEsb0JBQUEsR0FBQSxxREFBQTtBQUFtRCxNQUFBLDBCQUFBLEVBQUk7QUFHNUQsTUFBQSw0QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUF5QixNQUFBLHdCQUFBLFlBQUEsU0FBQSwwQ0FBQTtBQUFBLGVBQVksSUFBQSxPQUFBO01BQVEsQ0FBQTtBQUMzQyxNQUFBLDRCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsU0FBQSxDQUFBO0FBQ0gsTUFBQSxvQkFBQSxJQUFBLHVCQUFBO0FBQWtCLE1BQUEsMEJBQUE7QUFDckMsTUFBQSx1QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQVVBLE1BQUEsaUNBQUEsSUFBQSwrQkFBQSxHQUFBLEdBQUEsU0FBQSxDQUFBO0FBS0YsTUFBQSwwQkFBQTtBQUVBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLENBQUEsRUFBd0IsSUFBQSxTQUFBLEVBQUE7QUFDQSxNQUFBLG9CQUFBLElBQUEsZUFBQTtBQUFVLE1BQUEsMEJBQUE7QUFDaEMsTUFBQSx1QkFBQSxJQUFBLGNBQUEsRUFBQTtBQVVBLE1BQUEsaUNBQUEsSUFBQSwrQkFBQSxHQUFBLEdBQUEsU0FBQSxFQUFBO0FBR0YsTUFBQSwwQkFBQTtBQUVBLE1BQUEsaUNBQUEsSUFBQSwrQkFBQSxHQUFBLEdBQUEsYUFBQSxFQUFBO0FBTUEsTUFBQSx1QkFBQSxJQUFBLFlBQUEsRUFBQTtBQVFGLE1BQUEsMEJBQUEsRUFBTyxFQUNIOzs7QUFwREUsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSx3QkFBQSxhQUFBLElBQUEsSUFBQTtBQVVBLE1BQUEsdUJBQUEsQ0FBQTs7QUFHRixNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLEtBQUEsU0FBQSxNQUFBLFdBQUEsSUFBQSxLQUFBLFNBQUEsTUFBQSxVQUFBLEtBQUEsRUFBQTtBQVlFLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsd0JBQUEsWUFBQSxLQUFBLEVBQWtCLGNBQUEsSUFBQSxFQUNDLFNBQUEsSUFBQTtBQU1yQixNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLEtBQUEsU0FBQSxTQUFBLFdBQUEsSUFBQSxLQUFBLFNBQUEsU0FBQSxVQUFBLEtBQUEsRUFBQTtBQUtGLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsYUFBQSxJQUFBLEtBQUEsRUFBQTtBQVVFLE1BQUEsdUJBQUE7QUFBQSxNQUFBLHdCQUFBLFdBQUEsSUFBQSxRQUFBLENBQUEsRUFBcUIsWUFBQSxJQUFBLFFBQUEsQ0FBQSxFQUNDLFNBQUEsSUFBQTs7b0JENUNsQixxQkFBbUIsdUJBQUEsbUJBQUEsaUNBQUEseUJBQUEsd0JBQUEsdUJBQUEsaUNBQUEsK0JBQUEsdUNBQUEsOEJBQUEsb0JBQUEseUJBQUEsc0JBQUEsdUJBQUEsdUJBQUEscUJBQUEsOEJBQUEsbUJBQUEsaUJBQUEsaUJBQUEseUJBQUEsdUJBQUEsdUJBQUEsb0JBQUEsa0JBQUEsa0JBQUUsY0FBWSxvQkFBQSxXQUFBLGdCQUFBLGVBQUEsV0FBQSxXQUFBLGtCQUFFLGlCQUFlLGNBQUUsZ0JBQWMsc0JBQUEsYUFBQSxTQUFFLGVBQWEsVUFBQSxHQUFBLFFBQUEsQ0FBQSwra0VBQUEsRUFBQSxDQUFBOzs7K0VBS2hGLE9BQUssQ0FBQTtVQVJqQjt1QkFDVyxhQUFXLFlBQ1QsTUFBSSxTQUNQLENBQUMscUJBQXFCLGNBQWMsaUJBQWlCLGdCQUFnQixhQUFhLEdBQUMsVUFBQSw4NERBQUEsUUFBQSxDQUFBLDZzREFBQSxFQUFBLENBQUE7Ozs7Z0ZBS2pGLE9BQUssRUFBQSxXQUFBLFNBQUEsVUFBQSxvQ0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7OERBQUwsT0FBSyxFQUFBLFNBQUEsQ0FBQSxJQUFBLElBQUEsSUFBQSxJQUFBLElBQUEsSUFBQSxJQUFBLEVBQUEsR0FBQSxDQUFBLHFCQUFBLGNBQUEsaUJBQUEsZ0JBQUEsZUFBQSxTQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxjQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLGNBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOyIsIm5hbWVzIjpbXX0=