import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/main.js");import {
  SessionCleanupService
} from "/chunk-F4B37XH6.js";
import {
  PermissionService
} from "/chunk-KIW7SE4H.js";
import {
  AuthService
} from "/chunk-HUEL4CRJ.js";
import "/chunk-WOIO7PCB.js";
import {
  environment
} from "/chunk-P37EOHI7.js";
import "/chunk-VUJOFXKG.js";

// src/main.ts
import { bootstrapApplication } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_platform-browser.js?v=b9a49161";

// src/app/app.config.ts
import { provideRouter } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_router.js?v=b9a49161";
import { provideHttpClient, withInterceptors } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_common_http.js?v=b9a49161";
import { providePrimeNG } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_config.js?v=b9a49161";
import Aura from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@primeuix_themes_aura.js?v=b9a49161";

// src/app/core/guards/auth-guard.ts
import { inject } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { Router } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_router.js?v=b9a49161";
import { map } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/rxjs.js?v=b9a49161";
var authGuard = (_route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  return authService.initialize().pipe(map((authenticated) => {
    if (authenticated) {
      return true;
    }
    return router.createUrlTree(["/login"], {
      queryParams: {
        returnUrl: state.url
      }
    });
  }));
};

// src/app/core/guards/guest.guard.ts
import { inject as inject2 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { Router as Router2 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_router.js?v=b9a49161";
import { map as map2 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/rxjs.js?v=b9a49161";
var guestGuard = () => {
  const authService = inject2(AuthService);
  const router = inject2(Router2);
  return authService.initialize().pipe(map2((authenticated) => authenticated ? router.createUrlTree(["/dashboard"]) : true));
};

// src/app/core/guards/permission-guard.ts
import { inject as inject3 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { Router as Router3 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_router.js?v=b9a49161";
import { map as map3 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/rxjs.js?v=b9a49161";
var permissionGuard = (route, state) => {
  const authService = inject3(AuthService);
  const permissionService = inject3(PermissionService);
  const router = inject3(Router3);
  const requiredPermission = route.data["permission"];
  return authService.initialize().pipe(map3((authenticated) => {
    if (!authenticated) {
      return router.createUrlTree(["/login"], {
        queryParams: {
          returnUrl: state.url
        }
      });
    }
    if (requiredPermission && permissionService.has(requiredPermission)) {
      return true;
    }
    return router.createUrlTree(["/forbidden"]);
  }));
};

// src/app/app.routes.ts
var routes = [
  {
    path: "login",
    canActivate: [guestGuard],
    loadComponent: () => import("/chunk-E3YFFTZW.js").then((m) => m.Login)
  },
  {
    path: "",
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    loadComponent: () => import("/chunk-BZDT2WVB.js").then((m) => m.AdminLayout),
    children: [
      {
        path: "",
        pathMatch: "full",
        redirectTo: "dashboard"
      },
      {
        path: "dashboard",
        canActivate: [permissionGuard],
        data: { permission: "dashboard.view" },
        loadComponent: () => import("/chunk-43GWQ3L2.js").then((m) => m.Dashboard)
      },
      {
        path: "users",
        canActivate: [permissionGuard],
        data: { permission: "users.view" },
        loadComponent: () => import("/chunk-2SHIL3UT.js").then((m) => m.Users)
      },
      {
        path: "settings",
        canActivate: [permissionGuard],
        data: { permission: "settings.view" },
        loadComponent: () => import("/chunk-HC4JLQNU.js").then((m) => m.Settings)
      },
      {
        path: "forbidden",
        loadComponent: () => import("/chunk-R2OYA43V.js").then((m) => m.Forbidden)
      }
    ]
  },
  {
    path: "**",
    redirectTo: "dashboard"
  }
];

// src/app/core/interceptors/api-error-interceptor.ts
import { catchError, throwError } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/rxjs.js?v=b9a49161";
var apiErrorInterceptor = (req, next) => {
  return next(req).pipe(catchError((error) => {
    let message = "Ocurri\xF3 un error inesperado.";
    if (error.status === 0) {
      message = "No se pudo conectar con el servidor.";
    } else if (error.status === 400) {
      message = "La solicitud contiene datos incorrectos.";
    } else if (error.status === 401) {
      message = "Debes iniciar sesi\xF3n.";
    } else if (error.status === 403) {
      message = "No tienes permisos para esta operaci\xF3n.";
    } else if (error.status === 404) {
      message = "El recurso solicitado no existe.";
    } else if (error.status === 409) {
      message = "Existe un conflicto con los datos enviados.";
    } else if (error.status >= 500) {
      message = "El servidor presenta un problema interno.";
    }
    console.error("[HTTP ERROR]", {
      url: req.url,
      method: req.method,
      status: error.status,
      message
    });
    return throwError(() => error);
  }));
};

// src/app/core/interceptors/credentials-interceptor.ts
var credentialsInterceptor = (req, next) => {
  const apiBase = new URL(environment.apiUrl);
  const requestUrl = new URL(req.url, apiBase);
  const belongsToApi = requestUrl.origin === apiBase.origin && requestUrl.pathname.startsWith(apiBase.pathname.replace(/\/$/, "") + "/");
  if (!belongsToApi) {
    return next(req);
  }
  return next(req.clone({
    withCredentials: true
  }));
};

// src/app/core/interceptors/session-interceptor.ts
import { inject as inject4 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { Router as Router4 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_router.js?v=b9a49161";
import { catchError as catchError2, throwError as throwError2 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/rxjs.js?v=b9a49161";
var sessionInterceptor = (req, next) => {
  const authService = inject4(AuthService);
  const cleanup = inject4(SessionCleanupService);
  const router = inject4(Router4);
  const apiUrl = environment.apiUrl.replace(/\/$/, "");
  const isApiRequest = req.url.startsWith(`${apiUrl}/`);
  const isLoginRequest = req.url === `${apiUrl}/auth/login`;
  const isSessionCheck = req.url === `${apiUrl}/auth/me`;
  return next(req).pipe(catchError2((error) => {
    if (isApiRequest && error.status === 401 && !isLoginRequest && !isSessionCheck) {
      authService.clearLocalSession();
      cleanup.clear();
      const returnUrl = router.url;
      void router.navigate(["/login"], {
        queryParams: {
          returnUrl: returnUrl.startsWith("/login") ? "/dashboard" : returnUrl
        }
      });
    }
    return throwError2(() => error);
  }));
};

// src/app/app.config.ts
var appConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptors([apiErrorInterceptor, credentialsInterceptor, sessionInterceptor])),
    providePrimeNG({
      theme: {
        preset: Aura,
        options: {
          darkModeSelector: false
        }
      },
      ripple: true
    })
  ]
};

// src/app/app.ts
import { Component } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { RouterOutlet } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_router.js?v=b9a49161";
import * as i0 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
var App = class _App {
  static \u0275fac = function App_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _App)();
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _App, selectors: [["app-root"]], decls: 1, vars: 0, template: function App_Template(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275element(0, "router-outlet");
    }
  }, dependencies: [RouterOutlet], encapsulation: 2 });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(App, [{
    type: Component,
    args: [{
      selector: "app-root",
      imports: [RouterOutlet],
      template: "<router-outlet />"
    }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(App, { className: "App", filePath: "app/app.ts", lineNumber: 10 });
})();
(() => {
  const id = "app%2Fapp.ts%40App";
  function App_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i0.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i0.\u0275\u0275replaceMetadata(App, m.default, [i0], [RouterOutlet, Component], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && App_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && App_HmrLoad(d.timestamp)));
})();

// src/main.ts
bootstrapApplication(App, appConfig).catch((err) => console.error(err));


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluLnRzIiwic3JjL2FwcC9hcHAuY29uZmlnLnRzIiwic3JjL2FwcC9jb3JlL2d1YXJkcy9hdXRoLWd1YXJkLnRzIiwic3JjL2FwcC9jb3JlL2d1YXJkcy9ndWVzdC5ndWFyZC50cyIsInNyYy9hcHAvY29yZS9ndWFyZHMvcGVybWlzc2lvbi1ndWFyZC50cyIsInNyYy9hcHAvYXBwLnJvdXRlcy50cyIsInNyYy9hcHAvY29yZS9pbnRlcmNlcHRvcnMvYXBpLWVycm9yLWludGVyY2VwdG9yLnRzIiwic3JjL2FwcC9jb3JlL2ludGVyY2VwdG9ycy9jcmVkZW50aWFscy1pbnRlcmNlcHRvci50cyIsInNyYy9hcHAvY29yZS9pbnRlcmNlcHRvcnMvc2Vzc2lvbi1pbnRlcmNlcHRvci50cyIsInNyYy9hcHAvYXBwLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGJvb3RzdHJhcEFwcGxpY2F0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlcic7XHJcbmltcG9ydCB7IGFwcENvbmZpZyB9IGZyb20gJy4vYXBwL2FwcC5jb25maWcnO1xyXG5pbXBvcnQgeyBBcHAgfSBmcm9tICcuL2FwcC9hcHAnO1xyXG5cclxuYm9vdHN0cmFwQXBwbGljYXRpb24oQXBwLCBhcHBDb25maWcpXHJcbiAgLmNhdGNoKChlcnIpID0+IGNvbnNvbGUuZXJyb3IoZXJyKSk7XHJcbiIsImltcG9ydCB7IEFwcGxpY2F0aW9uQ29uZmlnIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IHByb3ZpZGVSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBwcm92aWRlSHR0cENsaWVudCwgd2l0aEludGVyY2VwdG9ycyB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuXHJcbmltcG9ydCB7IHByb3ZpZGVQcmltZU5HIH0gZnJvbSAncHJpbWVuZy9jb25maWcnO1xyXG5pbXBvcnQgQXVyYSBmcm9tICdAcHJpbWV1aXgvdGhlbWVzL2F1cmEnO1xyXG5pbXBvcnQgeyByb3V0ZXMgfSBmcm9tICcuL2FwcC5yb3V0ZXMnO1xyXG5pbXBvcnQgeyBhcGlFcnJvckludGVyY2VwdG9yIH0gZnJvbSAnLi9jb3JlL2ludGVyY2VwdG9ycy9hcGktZXJyb3ItaW50ZXJjZXB0b3InO1xyXG5cclxuaW1wb3J0IHsgY3JlZGVudGlhbHNJbnRlcmNlcHRvciB9IGZyb20gJy4vY29yZS9pbnRlcmNlcHRvcnMvY3JlZGVudGlhbHMtaW50ZXJjZXB0b3InO1xyXG5pbXBvcnQgeyBzZXNzaW9uSW50ZXJjZXB0b3IgfSBmcm9tICcuL2NvcmUvaW50ZXJjZXB0b3JzL3Nlc3Npb24taW50ZXJjZXB0b3InO1xyXG5cclxuZXhwb3J0IGNvbnN0IGFwcENvbmZpZzogQXBwbGljYXRpb25Db25maWcgPSB7XHJcbiAgcHJvdmlkZXJzOiBbXHJcbiAgICBwcm92aWRlUm91dGVyKHJvdXRlcyksXHJcbiAgICBwcm92aWRlSHR0cENsaWVudChcclxuICAgICAgd2l0aEludGVyY2VwdG9ycyhbYXBpRXJyb3JJbnRlcmNlcHRvciwgY3JlZGVudGlhbHNJbnRlcmNlcHRvciwgc2Vzc2lvbkludGVyY2VwdG9yXSksXHJcbiAgICApLFxyXG4gICAgcHJvdmlkZVByaW1lTkcoe1xyXG4gICAgICB0aGVtZToge1xyXG4gICAgICAgIHByZXNldDogQXVyYSxcclxuICAgICAgICBvcHRpb25zOiB7XHJcbiAgICAgICAgICBkYXJrTW9kZVNlbGVjdG9yOiBmYWxzZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICByaXBwbGU6IHRydWUsXHJcbiAgICB9KSxcclxuICBdLFxyXG59O1xyXG4iLCJpbXBvcnQgeyBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENhbkFjdGl2YXRlRm4sIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBtYXAgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEF1dGhTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvYXV0aCc7XG5cbmV4cG9ydCBjb25zdCBhdXRoR3VhcmQ6IENhbkFjdGl2YXRlRm4gPSAoX3JvdXRlLCBzdGF0ZSkgPT4ge1xuICBjb25zdCBhdXRoU2VydmljZSA9IGluamVjdChBdXRoU2VydmljZSk7XG4gIGNvbnN0IHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xuXG4gIHJldHVybiBhdXRoU2VydmljZS5pbml0aWFsaXplKCkucGlwZShcbiAgICBtYXAoKGF1dGhlbnRpY2F0ZWQpID0+IHtcbiAgICAgIGlmIChhdXRoZW50aWNhdGVkKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcm91dGVyLmNyZWF0ZVVybFRyZWUoWycvbG9naW4nXSwge1xuICAgICAgICBxdWVyeVBhcmFtczoge1xuICAgICAgICAgIHJldHVyblVybDogc3RhdGUudXJsLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSksXG4gICk7XG59O1xuIiwiaW1wb3J0IHsgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENhbkFjdGl2YXRlRm4sIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IG1hcCB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBBdXRoU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL2F1dGgnO1xyXG5cclxuZXhwb3J0IGNvbnN0IGd1ZXN0R3VhcmQ6IENhbkFjdGl2YXRlRm4gPSAoKSA9PiB7XHJcbiAgY29uc3QgYXV0aFNlcnZpY2UgPSBpbmplY3QoQXV0aFNlcnZpY2UpO1xyXG4gIGNvbnN0IHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xyXG5cclxuICByZXR1cm4gYXV0aFNlcnZpY2VcclxuICAgIC5pbml0aWFsaXplKClcclxuICAgIC5waXBlKG1hcCgoYXV0aGVudGljYXRlZCkgPT4gKGF1dGhlbnRpY2F0ZWQgPyByb3V0ZXIuY3JlYXRlVXJsVHJlZShbJy9kYXNoYm9hcmQnXSkgOiB0cnVlKSkpO1xyXG59O1xyXG4iLCJpbXBvcnQgeyBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENhbkFjdGl2YXRlRm4sIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5cbmltcG9ydCB7IG1hcCB9IGZyb20gJ3J4anMnO1xuXG5pbXBvcnQgeyBBdXRoU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL2F1dGgnO1xuaW1wb3J0IHsgUGVybWlzc2lvblNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9wZXJtaXNzaW9uJztcbmltcG9ydCB7IFBlcm1pc3Npb24gfSBmcm9tICcuLi9tb2RlbHMvcGVybWlzc2lvbi5tb2RlbCc7XG5cbmV4cG9ydCBjb25zdCBwZXJtaXNzaW9uR3VhcmQ6IENhbkFjdGl2YXRlRm4gPSAocm91dGUsIHN0YXRlKSA9PiB7XG4gIGNvbnN0IGF1dGhTZXJ2aWNlID0gaW5qZWN0KEF1dGhTZXJ2aWNlKTtcbiAgY29uc3QgcGVybWlzc2lvblNlcnZpY2UgPSBpbmplY3QoUGVybWlzc2lvblNlcnZpY2UpO1xuICBjb25zdCByb3V0ZXIgPSBpbmplY3QoUm91dGVyKTtcblxuICBjb25zdCByZXF1aXJlZFBlcm1pc3Npb24gPSByb3V0ZS5kYXRhWydwZXJtaXNzaW9uJ10gYXMgUGVybWlzc2lvbiB8IHVuZGVmaW5lZDtcblxuICByZXR1cm4gYXV0aFNlcnZpY2UuaW5pdGlhbGl6ZSgpLnBpcGUoXG4gICAgbWFwKChhdXRoZW50aWNhdGVkKSA9PiB7XG4gICAgICBpZiAoIWF1dGhlbnRpY2F0ZWQpIHtcbiAgICAgICAgcmV0dXJuIHJvdXRlci5jcmVhdGVVcmxUcmVlKFsnL2xvZ2luJ10sIHtcbiAgICAgICAgICBxdWVyeVBhcmFtczoge1xuICAgICAgICAgICAgcmV0dXJuVXJsOiBzdGF0ZS51cmwsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGlmIChyZXF1aXJlZFBlcm1pc3Npb24gJiYgcGVybWlzc2lvblNlcnZpY2UuaGFzKHJlcXVpcmVkUGVybWlzc2lvbikpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByb3V0ZXIuY3JlYXRlVXJsVHJlZShbJy9mb3JiaWRkZW4nXSk7XG4gICAgfSksXG4gICk7XG59O1xuIiwiaW1wb3J0IHsgUm91dGVzIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuXHJcbmltcG9ydCB7IGF1dGhHdWFyZCB9IGZyb20gJy4vY29yZS9ndWFyZHMvYXV0aC1ndWFyZCc7XHJcbmltcG9ydCB7IGd1ZXN0R3VhcmQgfSBmcm9tICcuL2NvcmUvZ3VhcmRzL2d1ZXN0Lmd1YXJkJztcclxuaW1wb3J0IHsgcGVybWlzc2lvbkd1YXJkIH0gZnJvbSAnLi9jb3JlL2d1YXJkcy9wZXJtaXNzaW9uLWd1YXJkJztcclxuXHJcbmV4cG9ydCBjb25zdCByb3V0ZXM6IFJvdXRlcyA9IFtcclxuICB7XHJcbiAgICBwYXRoOiAnbG9naW4nLFxyXG4gICAgY2FuQWN0aXZhdGU6IFtndWVzdEd1YXJkXSxcclxuICAgIGxvYWRDb21wb25lbnQ6ICgpID0+IGltcG9ydCgnLi9mZWF0dXJlcy9hdXRoL2xvZ2luL2xvZ2luJykudGhlbigobSkgPT4gbS5Mb2dpbiksXHJcbiAgfSxcclxuICB7XHJcbiAgICBwYXRoOiAnJyxcclxuICAgIGNhbkFjdGl2YXRlOiBbYXV0aEd1YXJkXSxcclxuICAgIGNhbkFjdGl2YXRlQ2hpbGQ6IFthdXRoR3VhcmRdLFxyXG4gICAgbG9hZENvbXBvbmVudDogKCkgPT4gaW1wb3J0KCcuL2xheW91dC9hZG1pbi1sYXlvdXQvYWRtaW4tbGF5b3V0JykudGhlbigobSkgPT4gbS5BZG1pbkxheW91dCksXHJcbiAgICBjaGlsZHJlbjogW1xyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogJycsXHJcbiAgICAgICAgcGF0aE1hdGNoOiAnZnVsbCcsXHJcbiAgICAgICAgcmVkaXJlY3RUbzogJ2Rhc2hib2FyZCcsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiAnZGFzaGJvYXJkJyxcclxuICAgICAgICBjYW5BY3RpdmF0ZTogW3Blcm1pc3Npb25HdWFyZF0sXHJcbiAgICAgICAgZGF0YTogeyBwZXJtaXNzaW9uOiAnZGFzaGJvYXJkLnZpZXcnIH0sXHJcbiAgICAgICAgbG9hZENvbXBvbmVudDogKCkgPT4gaW1wb3J0KCcuL2ZlYXR1cmVzL2Rhc2hib2FyZC9kYXNoYm9hcmQnKS50aGVuKChtKSA9PiBtLkRhc2hib2FyZCksXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiAndXNlcnMnLFxyXG4gICAgICAgIGNhbkFjdGl2YXRlOiBbcGVybWlzc2lvbkd1YXJkXSxcclxuICAgICAgICBkYXRhOiB7IHBlcm1pc3Npb246ICd1c2Vycy52aWV3JyB9LFxyXG4gICAgICAgIGxvYWRDb21wb25lbnQ6ICgpID0+IGltcG9ydCgnLi9mZWF0dXJlcy91c2Vycy91c2VycycpLnRoZW4oKG0pID0+IG0uVXNlcnMpLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogJ3NldHRpbmdzJyxcclxuICAgICAgICBjYW5BY3RpdmF0ZTogW3Blcm1pc3Npb25HdWFyZF0sXHJcbiAgICAgICAgZGF0YTogeyBwZXJtaXNzaW9uOiAnc2V0dGluZ3MudmlldycgfSxcclxuICAgICAgICBsb2FkQ29tcG9uZW50OiAoKSA9PiBpbXBvcnQoJy4vZmVhdHVyZXMvc2V0dGluZ3Mvc2V0dGluZ3MnKS50aGVuKChtKSA9PiBtLlNldHRpbmdzKSxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIHBhdGg6ICdmb3JiaWRkZW4nLFxyXG4gICAgICAgIGxvYWRDb21wb25lbnQ6ICgpID0+IGltcG9ydCgnLi9mZWF0dXJlcy9mb3JiaWRkZW4vZm9yYmlkZGVuJykudGhlbigobSkgPT4gbS5Gb3JiaWRkZW4pLFxyXG4gICAgICB9LFxyXG4gICAgXSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6ICcqKicsXHJcbiAgICByZWRpcmVjdFRvOiAnZGFzaGJvYXJkJyxcclxuICB9LFxyXG5dO1xyXG4iLCJpbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSwgSHR0cEludGVyY2VwdG9yRm4gfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCB0aHJvd0Vycm9yIH0gZnJvbSAncnhqcyc7XG5cbmV4cG9ydCBjb25zdCBhcGlFcnJvckludGVyY2VwdG9yOiBIdHRwSW50ZXJjZXB0b3JGbiA9IChyZXEsIG5leHQpID0+IHtcbiAgcmV0dXJuIG5leHQocmVxKS5waXBlKFxuICAgIGNhdGNoRXJyb3IoKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4ge1xuICAgICAgbGV0IG1lc3NhZ2UgPSAnT2N1cnJpw7MgdW4gZXJyb3IgaW5lc3BlcmFkby4nO1xuXG4gICAgICBpZiAoZXJyb3Iuc3RhdHVzID09PSAwKSB7XG4gICAgICAgIG1lc3NhZ2UgPSAnTm8gc2UgcHVkbyBjb25lY3RhciBjb24gZWwgc2Vydmlkb3IuJztcbiAgICAgIH0gZWxzZSBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MDApIHtcbiAgICAgICAgbWVzc2FnZSA9ICdMYSBzb2xpY2l0dWQgY29udGllbmUgZGF0b3MgaW5jb3JyZWN0b3MuJztcbiAgICAgIH0gZWxzZSBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MDEpIHtcbiAgICAgICAgbWVzc2FnZSA9ICdEZWJlcyBpbmljaWFyIHNlc2nDs24uJztcbiAgICAgIH0gZWxzZSBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MDMpIHtcbiAgICAgICAgbWVzc2FnZSA9ICdObyB0aWVuZXMgcGVybWlzb3MgcGFyYSBlc3RhIG9wZXJhY2nDs24uJztcbiAgICAgIH0gZWxzZSBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MDQpIHtcbiAgICAgICAgbWVzc2FnZSA9ICdFbCByZWN1cnNvIHNvbGljaXRhZG8gbm8gZXhpc3RlLic7XG4gICAgICB9IGVsc2UgaWYgKGVycm9yLnN0YXR1cyA9PT0gNDA5KSB7XG4gICAgICAgIG1lc3NhZ2UgPSAnRXhpc3RlIHVuIGNvbmZsaWN0byBjb24gbG9zIGRhdG9zIGVudmlhZG9zLic7XG4gICAgICB9IGVsc2UgaWYgKGVycm9yLnN0YXR1cyA+PSA1MDApIHtcbiAgICAgICAgbWVzc2FnZSA9ICdFbCBzZXJ2aWRvciBwcmVzZW50YSB1biBwcm9ibGVtYSBpbnRlcm5vLic7XG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1tIVFRQIEVSUk9SXScsIHtcbiAgICAgICAgdXJsOiByZXEudXJsLFxuICAgICAgICBtZXRob2Q6IHJlcS5tZXRob2QsXG4gICAgICAgIHN0YXR1czogZXJyb3Iuc3RhdHVzLFxuICAgICAgICBtZXNzYWdlLFxuICAgICAgfSk7XG5cbiAgICAgIHJldHVybiB0aHJvd0Vycm9yKCgpID0+IGVycm9yKTtcbiAgICB9KSxcbiAgKTtcbn07XG4iLCJpbXBvcnQgeyBIdHRwSW50ZXJjZXB0b3JGbiB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcblxuaW1wb3J0IHsgZW52aXJvbm1lbnQgfSBmcm9tICcuLi8uLi8uLi9lbnZpcm9ubWVudHMvZW52aXJvbm1lbnQnO1xuXG5leHBvcnQgY29uc3QgY3JlZGVudGlhbHNJbnRlcmNlcHRvcjogSHR0cEludGVyY2VwdG9yRm4gPSAocmVxLCBuZXh0KSA9PiB7XG4gIC8vIFNvbG8gZW52aWFyIGNyZWRlbmNpYWxlcyBhIG51ZXN0cmEgcHJvcGlhIEFQSS5cbiAgY29uc3QgYXBpQmFzZSA9IG5ldyBVUkwoZW52aXJvbm1lbnQuYXBpVXJsKTtcbiAgY29uc3QgcmVxdWVzdFVybCA9IG5ldyBVUkwocmVxLnVybCwgYXBpQmFzZSk7XG5cbiAgY29uc3QgYmVsb25nc1RvQXBpID1cbiAgICByZXF1ZXN0VXJsLm9yaWdpbiA9PT0gYXBpQmFzZS5vcmlnaW4gJiZcbiAgICByZXF1ZXN0VXJsLnBhdGhuYW1lLnN0YXJ0c1dpdGgoYXBpQmFzZS5wYXRobmFtZS5yZXBsYWNlKC9cXC8kLywgJycpICsgJy8nKTtcblxuICBpZiAoIWJlbG9uZ3NUb0FwaSkge1xuICAgIHJldHVybiBuZXh0KHJlcSk7XG4gIH1cblxuICByZXR1cm4gbmV4dChcbiAgICByZXEuY2xvbmUoe1xuICAgICAgd2l0aENyZWRlbnRpYWxzOiB0cnVlLFxuICAgIH0pLFxuICApO1xufTtcbiIsImltcG9ydCB7IGluamVjdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UsIEh0dHBJbnRlcmNlcHRvckZuIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IGNhdGNoRXJyb3IsIHRocm93RXJyb3IgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEF1dGhTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvYXV0aCc7XG5pbXBvcnQgeyBTZXNzaW9uQ2xlYW51cFNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9zZXNzaW9uLWNsZWFudXAnO1xuaW1wb3J0IHsgZW52aXJvbm1lbnQgfSBmcm9tICcuLi8uLi8uLi9lbnZpcm9ubWVudHMvZW52aXJvbm1lbnQnO1xuXG5leHBvcnQgY29uc3Qgc2Vzc2lvbkludGVyY2VwdG9yOiBIdHRwSW50ZXJjZXB0b3JGbiA9IChyZXEsIG5leHQpID0+IHtcbiAgY29uc3QgYXV0aFNlcnZpY2UgPSBpbmplY3QoQXV0aFNlcnZpY2UpO1xuICBjb25zdCBjbGVhbnVwID0gaW5qZWN0KFNlc3Npb25DbGVhbnVwU2VydmljZSk7XG4gIGNvbnN0IHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xuXG4gIGNvbnN0IGFwaVVybCA9IGVudmlyb25tZW50LmFwaVVybC5yZXBsYWNlKC9cXC8kLywgJycpO1xuICBjb25zdCBpc0FwaVJlcXVlc3QgPSByZXEudXJsLnN0YXJ0c1dpdGgoYCR7YXBpVXJsfS9gKTtcbiAgY29uc3QgaXNMb2dpblJlcXVlc3QgPSByZXEudXJsID09PSBgJHthcGlVcmx9L2F1dGgvbG9naW5gO1xuICBjb25zdCBpc1Nlc3Npb25DaGVjayA9IHJlcS51cmwgPT09IGAke2FwaVVybH0vYXV0aC9tZWA7XG5cbiAgcmV0dXJuIG5leHQocmVxKS5waXBlKFxuICAgIGNhdGNoRXJyb3IoKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4ge1xuICAgICAgaWYgKGlzQXBpUmVxdWVzdCAmJiBlcnJvci5zdGF0dXMgPT09IDQwMSAmJiAhaXNMb2dpblJlcXVlc3QgJiYgIWlzU2Vzc2lvbkNoZWNrKSB7XG4gICAgICAgIGF1dGhTZXJ2aWNlLmNsZWFyTG9jYWxTZXNzaW9uKCk7XG4gICAgICAgIGNsZWFudXAuY2xlYXIoKTtcblxuICAgICAgICBjb25zdCByZXR1cm5VcmwgPSByb3V0ZXIudXJsO1xuXG4gICAgICAgIHZvaWQgcm91dGVyLm5hdmlnYXRlKFsnL2xvZ2luJ10sIHtcbiAgICAgICAgICBxdWVyeVBhcmFtczoge1xuICAgICAgICAgICAgcmV0dXJuVXJsOiByZXR1cm5Vcmwuc3RhcnRzV2l0aCgnL2xvZ2luJykgPyAnL2Rhc2hib2FyZCcgOiByZXR1cm5VcmwsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aHJvd0Vycm9yKCgpID0+IGVycm9yKTtcbiAgICB9KSxcbiAgKTtcbn07XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIHNpZ25hbCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBSb3V0ZXJPdXRsZXQgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtcm9vdCcsXHJcbiAgaW1wb3J0czogW1JvdXRlck91dGxldF0sXHJcbiAgdGVtcGxhdGU6ICc8cm91dGVyLW91dGxldCAvPidcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBBcHAge31cclxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsU0FBUyw0QkFBNEI7OztBQ0NyQyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLG1CQUFtQix3QkFBd0I7QUFFcEQsU0FBUyxzQkFBc0I7QUFDL0IsT0FBTyxVQUFVOzs7QUNMakIsU0FBUyxjQUFjO0FBQ3ZCLFNBQXdCLGNBQWM7QUFDdEMsU0FBUyxXQUFXO0FBR2IsSUFBTSxZQUEyQixDQUFDLFFBQVEsVUFBUztBQUN4RCxRQUFNLGNBQWMsT0FBTyxXQUFXO0FBQ3RDLFFBQU0sU0FBUyxPQUFPLE1BQU07QUFFNUIsU0FBTyxZQUFZLFdBQVUsRUFBRyxLQUM5QixJQUFJLENBQUMsa0JBQWlCO0FBQ3BCLFFBQUksZUFBZTtBQUNqQixhQUFPO0lBQ1Q7QUFFQSxXQUFPLE9BQU8sY0FBYyxDQUFDLFFBQVEsR0FBRztNQUN0QyxhQUFhO1FBQ1gsV0FBVyxNQUFNOztLQUVwQjtFQUNILENBQUMsQ0FBQztBQUVOOzs7QUN0QkEsU0FBUyxVQUFBQSxlQUFjO0FBQ3ZCLFNBQXdCLFVBQUFDLGVBQWM7QUFDdEMsU0FBUyxPQUFBQyxZQUFXO0FBR2IsSUFBTSxhQUE0QixNQUFLO0FBQzVDLFFBQU0sY0FBY0MsUUFBTyxXQUFXO0FBQ3RDLFFBQU0sU0FBU0EsUUFBT0MsT0FBTTtBQUU1QixTQUFPLFlBQ0osV0FBVSxFQUNWLEtBQUtDLEtBQUksQ0FBQyxrQkFBbUIsZ0JBQWdCLE9BQU8sY0FBYyxDQUFDLFlBQVksQ0FBQyxJQUFJLElBQUssQ0FBQztBQUMvRjs7O0FDWkEsU0FBUyxVQUFBQyxlQUFjO0FBQ3ZCLFNBQXdCLFVBQUFDLGVBQWM7QUFFdEMsU0FBUyxPQUFBQyxZQUFXO0FBTWIsSUFBTSxrQkFBaUMsQ0FBQyxPQUFPLFVBQVM7QUFDN0QsUUFBTSxjQUFjQyxRQUFPLFdBQVc7QUFDdEMsUUFBTSxvQkFBb0JBLFFBQU8saUJBQWlCO0FBQ2xELFFBQU0sU0FBU0EsUUFBT0MsT0FBTTtBQUU1QixRQUFNLHFCQUFxQixNQUFNLEtBQUssWUFBWTtBQUVsRCxTQUFPLFlBQVksV0FBVSxFQUFHLEtBQzlCQyxLQUFJLENBQUMsa0JBQWlCO0FBQ3BCLFFBQUksQ0FBQyxlQUFlO0FBQ2xCLGFBQU8sT0FBTyxjQUFjLENBQUMsUUFBUSxHQUFHO1FBQ3RDLGFBQWE7VUFDWCxXQUFXLE1BQU07O09BRXBCO0lBQ0g7QUFFQSxRQUFJLHNCQUFzQixrQkFBa0IsSUFBSSxrQkFBa0IsR0FBRztBQUNuRSxhQUFPO0lBQ1Q7QUFFQSxXQUFPLE9BQU8sY0FBYyxDQUFDLFlBQVksQ0FBQztFQUM1QyxDQUFDLENBQUM7QUFFTjs7O0FDM0JPLElBQU0sU0FBaUI7RUFDNUI7SUFDRSxNQUFNO0lBQ04sYUFBYSxDQUFDLFVBQVU7SUFDeEIsZUFBZSxNQUFNLE9BQU8scUJBQTZCLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLOztFQUVoRjtJQUNFLE1BQU07SUFDTixhQUFhLENBQUMsU0FBUztJQUN2QixrQkFBa0IsQ0FBQyxTQUFTO0lBQzVCLGVBQWUsTUFBTSxPQUFPLHFCQUFvQyxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVztJQUMzRixVQUFVO01BQ1I7UUFDRSxNQUFNO1FBQ04sV0FBVztRQUNYLFlBQVk7O01BRWQ7UUFDRSxNQUFNO1FBQ04sYUFBYSxDQUFDLGVBQWU7UUFDN0IsTUFBTSxFQUFFLFlBQVksaUJBQWdCO1FBQ3BDLGVBQWUsTUFBTSxPQUFPLHFCQUFnQyxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsU0FBUzs7TUFFdkY7UUFDRSxNQUFNO1FBQ04sYUFBYSxDQUFDLGVBQWU7UUFDN0IsTUFBTSxFQUFFLFlBQVksYUFBWTtRQUNoQyxlQUFlLE1BQU0sT0FBTyxxQkFBd0IsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUs7O01BRTNFO1FBQ0UsTUFBTTtRQUNOLGFBQWEsQ0FBQyxlQUFlO1FBQzdCLE1BQU0sRUFBRSxZQUFZLGdCQUFlO1FBQ25DLGVBQWUsTUFBTSxPQUFPLHFCQUE4QixFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUTs7TUFFcEY7UUFDRSxNQUFNO1FBQ04sZUFBZSxNQUFNLE9BQU8scUJBQWdDLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxTQUFTOzs7O0VBSTNGO0lBQ0UsTUFBTTtJQUNOLFlBQVk7Ozs7O0FDaERoQixTQUFTLFlBQVksa0JBQWtCO0FBRWhDLElBQU0sc0JBQXlDLENBQUMsS0FBSyxTQUFRO0FBQ2xFLFNBQU8sS0FBSyxHQUFHLEVBQUUsS0FDZixXQUFXLENBQUMsVUFBNEI7QUFDdEMsUUFBSSxVQUFVO0FBRWQsUUFBSSxNQUFNLFdBQVcsR0FBRztBQUN0QixnQkFBVTtJQUNaLFdBQVcsTUFBTSxXQUFXLEtBQUs7QUFDL0IsZ0JBQVU7SUFDWixXQUFXLE1BQU0sV0FBVyxLQUFLO0FBQy9CLGdCQUFVO0lBQ1osV0FBVyxNQUFNLFdBQVcsS0FBSztBQUMvQixnQkFBVTtJQUNaLFdBQVcsTUFBTSxXQUFXLEtBQUs7QUFDL0IsZ0JBQVU7SUFDWixXQUFXLE1BQU0sV0FBVyxLQUFLO0FBQy9CLGdCQUFVO0lBQ1osV0FBVyxNQUFNLFVBQVUsS0FBSztBQUM5QixnQkFBVTtJQUNaO0FBRUEsWUFBUSxNQUFNLGdCQUFnQjtNQUM1QixLQUFLLElBQUk7TUFDVCxRQUFRLElBQUk7TUFDWixRQUFRLE1BQU07TUFDZDtLQUNEO0FBRUQsV0FBTyxXQUFXLE1BQU0sS0FBSztFQUMvQixDQUFDLENBQUM7QUFFTjs7O0FDOUJPLElBQU0seUJBQTRDLENBQUMsS0FBSyxTQUFRO0FBRXJFLFFBQU0sVUFBVSxJQUFJLElBQUksWUFBWSxNQUFNO0FBQzFDLFFBQU0sYUFBYSxJQUFJLElBQUksSUFBSSxLQUFLLE9BQU87QUFFM0MsUUFBTSxlQUNKLFdBQVcsV0FBVyxRQUFRLFVBQzlCLFdBQVcsU0FBUyxXQUFXLFFBQVEsU0FBUyxRQUFRLE9BQU8sRUFBRSxJQUFJLEdBQUc7QUFFMUUsTUFBSSxDQUFDLGNBQWM7QUFDakIsV0FBTyxLQUFLLEdBQUc7RUFDakI7QUFFQSxTQUFPLEtBQ0wsSUFBSSxNQUFNO0lBQ1IsaUJBQWlCO0dBQ2xCLENBQUM7QUFFTjs7O0FDdEJBLFNBQVMsVUFBQUMsZUFBYztBQUV2QixTQUFTLFVBQUFDLGVBQWM7QUFDdkIsU0FBUyxjQUFBQyxhQUFZLGNBQUFDLG1CQUFrQjtBQUtoQyxJQUFNLHFCQUF3QyxDQUFDLEtBQUssU0FBUTtBQUNqRSxRQUFNLGNBQWNDLFFBQU8sV0FBVztBQUN0QyxRQUFNLFVBQVVBLFFBQU8scUJBQXFCO0FBQzVDLFFBQU0sU0FBU0EsUUFBT0MsT0FBTTtBQUU1QixRQUFNLFNBQVMsWUFBWSxPQUFPLFFBQVEsT0FBTyxFQUFFO0FBQ25ELFFBQU0sZUFBZSxJQUFJLElBQUksV0FBVyxHQUFHLE1BQU0sR0FBRztBQUNwRCxRQUFNLGlCQUFpQixJQUFJLFFBQVEsR0FBRyxNQUFNO0FBQzVDLFFBQU0saUJBQWlCLElBQUksUUFBUSxHQUFHLE1BQU07QUFFNUMsU0FBTyxLQUFLLEdBQUcsRUFBRSxLQUNmQyxZQUFXLENBQUMsVUFBNEI7QUFDdEMsUUFBSSxnQkFBZ0IsTUFBTSxXQUFXLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxnQkFBZ0I7QUFDOUUsa0JBQVksa0JBQWlCO0FBQzdCLGNBQVEsTUFBSztBQUViLFlBQU0sWUFBWSxPQUFPO0FBRXpCLFdBQUssT0FBTyxTQUFTLENBQUMsUUFBUSxHQUFHO1FBQy9CLGFBQWE7VUFDWCxXQUFXLFVBQVUsV0FBVyxRQUFRLElBQUksZUFBZTs7T0FFOUQ7SUFDSDtBQUVBLFdBQU9DLFlBQVcsTUFBTSxLQUFLO0VBQy9CLENBQUMsQ0FBQztBQUVOOzs7QVB4Qk8sSUFBTSxZQUErQjtFQUMxQyxXQUFXO0lBQ1QsY0FBYyxNQUFNO0lBQ3BCLGtCQUNFLGlCQUFpQixDQUFDLHFCQUFxQix3QkFBd0Isa0JBQWtCLENBQUMsQ0FBQztJQUVyRixlQUFlO01BQ2IsT0FBTztRQUNMLFFBQVE7UUFDUixTQUFTO1VBQ1Asa0JBQWtCOzs7TUFHdEIsUUFBUTtLQUNUOzs7OztBUTFCTCxTQUFTLGlCQUF5QjtBQUNsQyxTQUFTLG9CQUFvQjs7QUFRdkIsSUFBTyxNQUFQLE1BQU8sS0FBRzs7cUNBQUgsTUFBRztFQUFBOzRFQUFILE1BQUcsV0FBQSxDQUFBLENBQUEsVUFBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxVQUFBLFNBQUEsYUFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQUhILE1BQUEsdUJBQUEsR0FBQSxlQUFBOztvQkFERCxZQUFZLEdBQUEsZUFBQSxFQUFBLENBQUE7OzsrRUFJWCxLQUFHLENBQUE7VUFOZjtXQUFVO01BQ1QsVUFBVTtNQUNWLFNBQVMsQ0FBQyxZQUFZO01BQ3RCLFVBQVU7S0FDWDs7OztnRkFFWSxLQUFHLEVBQUEsV0FBQSxPQUFBLFVBQUEsY0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7OERBQUgsS0FBRyxFQUFBLFNBQUEsQ0FBQSxFQUFBLEdBQUEsQ0FBQSxjQUFBLFNBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLFlBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsWUFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBVExoQixxQkFBcUIsS0FBSyxTQUFTLEVBQ2hDLE1BQU0sQ0FBQyxRQUFRLFFBQVEsTUFBTSxHQUFHLENBQUM7IiwibmFtZXMiOlsiaW5qZWN0IiwiUm91dGVyIiwibWFwIiwiaW5qZWN0IiwiUm91dGVyIiwibWFwIiwiaW5qZWN0IiwiUm91dGVyIiwibWFwIiwiaW5qZWN0IiwiUm91dGVyIiwibWFwIiwiaW5qZWN0IiwiUm91dGVyIiwiY2F0Y2hFcnJvciIsInRocm93RXJyb3IiLCJpbmplY3QiLCJSb3V0ZXIiLCJjYXRjaEVycm9yIiwidGhyb3dFcnJvciJdfQ==