import {
  environment
} from "/chunk-P37EOHI7.js";
import {
  __spreadProps,
  __spreadValues
} from "/chunk-VUJOFXKG.js";

// src/app/features/users/store/user-store.ts
import { Injectable as Injectable2, computed, inject as inject2, signal, DestroyRef } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { finalize } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/rxjs.js?v=b9a49161";
import { takeUntilDestroyed } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core_rxjs-interop.js?v=b9a49161";

// src/app/features/users/services/user.ts
import { Injectable, inject } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { HttpClient } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_common_http.js?v=b9a49161";
import * as i0 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
var UserService = class _UserService {
  http = inject(HttpClient);
  apiUrl = `${environment.apiUrl}/users`;
  // GET: Obtener todos los usuarios
  getUsers() {
    return this.http.get(this.apiUrl);
  }
  // GET: Obtener un usuario por ID
  getUserById(id) {
    return this.http.get(`${this.apiUrl}/${encodeURIComponent(id)}`);
  }
  // POST: Registrar usuario
  createUser(user) {
    return this.http.post(this.apiUrl, user);
  }
  // PUT: Actualizar usuario
  updateUser(id, user) {
    return this.http.put(`${this.apiUrl}/${encodeURIComponent(id)}`, user);
  }
  // DELETE: Eliminar usuario
  deleteUser(id) {
    return this.http.delete(`${this.apiUrl}/${encodeURIComponent(id)}`);
  }
  static \u0275fac = function UserService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _UserService)();
  };
  static \u0275prov = /* @__PURE__ */ i0.\u0275\u0275defineInjectable({ token: _UserService, factory: _UserService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(UserService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

// src/app/features/users/store/user-store.ts
import * as i02 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
var UserStore = class _UserStore {
  userService = inject2(UserService);
  destroyRef = inject2(DestroyRef);
  requestVersion = 0;
  // ESTADOS PRIVADOS (MUTABLES)
  _users = signal([], ...ngDevMode ? [{ debugName: "_users" }] : (
    /* istanbul ignore next */
    []
  ));
  _loading = signal(false, ...ngDevMode ? [{ debugName: "_loading" }] : (
    /* istanbul ignore next */
    []
  ));
  _saving = signal(false, ...ngDevMode ? [{ debugName: "_saving" }] : (
    /* istanbul ignore next */
    []
  ));
  _deleting = signal(null, ...ngDevMode ? [{ debugName: "_deleting" }] : (
    /* istanbul ignore next */
    []
  ));
  _search = signal("", ...ngDevMode ? [{ debugName: "_search" }] : (
    /* istanbul ignore next */
    []
  ));
  _dialogVisible = signal(false, ...ngDevMode ? [{ debugName: "_dialogVisible" }] : (
    /* istanbul ignore next */
    []
  ));
  _selectedUser = signal(null, ...ngDevMode ? [{ debugName: "_selectedUser" }] : (
    /* istanbul ignore next */
    []
  ));
  // SEÑALES PÚBLICAS (SOLO LECTURA)
  users = this._users.asReadonly();
  loading = this._loading.asReadonly();
  saving = this._saving.asReadonly();
  deleting = this._deleting.asReadonly();
  search = this._search.asReadonly();
  dialogVisible = this._dialogVisible.asReadonly();
  selectedUser = this._selectedUser.asReadonly();
  // COMPUTADOS
  totalUsers = computed(() => this._users().length, ...ngDevMode ? [{ debugName: "totalUsers" }] : (
    /* istanbul ignore next */
    []
  ));
  activeUsers = computed(() => this._users().filter((user) => user.status === "Activo").length, ...ngDevMode ? [{ debugName: "activeUsers" }] : (
    /* istanbul ignore next */
    []
  ));
  inactiveUsers = computed(() => this._users().filter((user) => user.status === "Inactivo").length, ...ngDevMode ? [{ debugName: "inactiveUsers" }] : (
    /* istanbul ignore next */
    []
  ));
  // Evitar cargas duplicadas de la API
  _loaded = signal(false, ...ngDevMode ? [{ debugName: "_loaded" }] : (
    /* istanbul ignore next */
    []
  ));
  _error = signal(null, ...ngDevMode ? [{ debugName: "_error" }] : (
    /* istanbul ignore next */
    []
  ));
  loaded = this._loaded.asReadonly();
  error = this._error.asReadonly();
  filteredUsers = computed(() => {
    const term = this._search().trim().toLowerCase();
    if (!term)
      return this._users();
    return this._users().filter((user) => user.name.toLowerCase().includes(term) || user.email.toLowerCase().includes(term) || user.role.toLowerCase().includes(term) || user.status.toLowerCase().includes(term));
  }, ...ngDevMode ? [{ debugName: "filteredUsers" }] : (
    /* istanbul ignore next */
    []
  ));
  reset() {
    this.requestVersion++;
    this._users.set([]);
    this._loading.set(false);
    this._saving.set(false);
    this._deleting.set(null);
    this._search.set("");
    this._dialogVisible.set(false);
    this._selectedUser.set(null);
    this._error.set(null);
    this._loaded.set(false);
  }
  // MUTACIONES DIRECTAS DE ESTADO LOCAL
  setSearch(term) {
    this._search.set(term);
  }
  openCreate() {
    if (this._saving() || this._deleting() !== null)
      return;
    this._selectedUser.set(null);
    this._dialogVisible.set(true);
  }
  openEdit(user) {
    if (this._saving() || this._deleting() !== null)
      return;
    this._selectedUser.set(__spreadValues({}, user));
    this._dialogVisible.set(true);
  }
  closeDialog() {
    if (this._saving())
      return;
    this._dialogVisible.set(false);
    this._selectedUser.set(null);
  }
  setDialogVisible(visible) {
    if (visible) {
      this._dialogVisible.set(true);
    } else {
      this.closeDialog();
    }
  }
  checkEmailExists(email, currentUserId) {
    const normalizedEmail = email.trim().toLowerCase();
    return this._users().some((user) => user.email.trim().toLowerCase() === normalizedEmail && user.id !== currentUserId);
  }
  // ACCIONES ASÍNCRONAS
  loadUsers(callbacks, forceRefresh = false) {
    if (this._loading())
      return;
    if (this._loaded() && !forceRefresh)
      return;
    this._loading.set(true);
    this._error.set(null);
    const version = this.requestVersion;
    this.userService.getUsers().pipe(takeUntilDestroyed(this.destroyRef), finalize(() => {
      if (version === this.requestVersion) {
        this._loading.set(false);
      }
    })).subscribe({
      next: (users) => {
        if (version !== this.requestVersion) {
          return;
        }
        this._users.set(users);
        this._loaded.set(true);
      },
      error: (error) => {
        if (version !== this.requestVersion) {
          return;
        }
        this._error.set("No se pudieron cargar los usuarios.");
        callbacks?.onError?.(error);
      }
    });
  }
  saveUser(data, callbacks) {
    if (this._saving())
      return;
    const currentUser = this._selectedUser();
    const isEditing = currentUser !== null;
    const userData = __spreadProps(__spreadValues({}, data), {
      name: data.name.trim(),
      email: data.email.trim().toLowerCase()
    });
    this._saving.set(true);
    const request$ = currentUser ? this.userService.updateUser(currentUser.id, userData) : this.userService.createUser(userData);
    request$.pipe(takeUntilDestroyed(this.destroyRef), finalize(() => this._saving.set(false))).subscribe({
      next: () => {
        this._dialogVisible.set(false);
        this._selectedUser.set(null);
        callbacks?.onSuccess?.(isEditing);
        this.loadUsers(void 0, true);
      },
      error: (error) => callbacks?.onError?.(error)
    });
  }
  deleteUser(id, callbacks) {
    if (this._deleting() !== null)
      return;
    this._deleting.set(id);
    this.userService.deleteUser(id).pipe(takeUntilDestroyed(this.destroyRef), finalize(() => this._deleting.set(null))).subscribe({
      next: () => {
        callbacks?.onSuccess?.();
        this.loadUsers(void 0, true);
      },
      error: (error) => callbacks?.onError?.(error)
    });
  }
  static \u0275fac = function UserStore_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _UserStore)();
  };
  static \u0275prov = /* @__PURE__ */ i02.\u0275\u0275defineInjectable({ token: _UserStore, factory: _UserStore.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassMetadata(UserStore, [{
    type: Injectable2,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

export {
  UserStore
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZmVhdHVyZXMvdXNlcnMvc3RvcmUvdXNlci1zdG9yZS50cyIsInNyYy9hcHAvZmVhdHVyZXMvdXNlcnMvc2VydmljZXMvdXNlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlLCBjb21wdXRlZCwgaW5qZWN0LCBzaWduYWwsIERlc3Ryb3lSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBFcnJvclJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgZmluYWxpemUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IHRha2VVbnRpbERlc3Ryb3llZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUvcnhqcy1pbnRlcm9wJztcblxuaW1wb3J0IHsgVXNlclNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy91c2VyJztcbmltcG9ydCB7IFVzZXIsIFVzZXJGb3JtVmFsdWUgfSBmcm9tICcuLi91c2VyLm1vZGVsJztcblxuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCcsXG59KVxuZXhwb3J0IGNsYXNzIFVzZXJTdG9yZSB7XG4gIHByaXZhdGUgcmVhZG9ubHkgdXNlclNlcnZpY2UgPSBpbmplY3QoVXNlclNlcnZpY2UpO1xuICBwcml2YXRlIHJlYWRvbmx5IGRlc3Ryb3lSZWYgPSBpbmplY3QoRGVzdHJveVJlZik7XG5cbiAgcHJpdmF0ZSByZXF1ZXN0VmVyc2lvbiA9IDA7XG5cbiAgLy8gRVNUQURPUyBQUklWQURPUyAoTVVUQUJMRVMpXG4gIHByaXZhdGUgcmVhZG9ubHkgX3VzZXJzID0gc2lnbmFsPFVzZXJbXT4oW10pO1xuICBwcml2YXRlIHJlYWRvbmx5IF9sb2FkaW5nID0gc2lnbmFsPGJvb2xlYW4+KGZhbHNlKTtcbiAgcHJpdmF0ZSByZWFkb25seSBfc2F2aW5nID0gc2lnbmFsPGJvb2xlYW4+KGZhbHNlKTtcbiAgcHJpdmF0ZSByZWFkb25seSBfZGVsZXRpbmcgPSBzaWduYWw8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIHByaXZhdGUgcmVhZG9ubHkgX3NlYXJjaCA9IHNpZ25hbDxzdHJpbmc+KCcnKTtcbiAgcHJpdmF0ZSByZWFkb25seSBfZGlhbG9nVmlzaWJsZSA9IHNpZ25hbDxib29sZWFuPihmYWxzZSk7XG4gIHByaXZhdGUgcmVhZG9ubHkgX3NlbGVjdGVkVXNlciA9IHNpZ25hbDxVc2VyIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gU0XDkUFMRVMgUMOaQkxJQ0FTIChTT0xPIExFQ1RVUkEpXG4gIHJlYWRvbmx5IHVzZXJzID0gdGhpcy5fdXNlcnMuYXNSZWFkb25seSgpO1xuICByZWFkb25seSBsb2FkaW5nID0gdGhpcy5fbG9hZGluZy5hc1JlYWRvbmx5KCk7XG4gIHJlYWRvbmx5IHNhdmluZyA9IHRoaXMuX3NhdmluZy5hc1JlYWRvbmx5KCk7XG4gIHJlYWRvbmx5IGRlbGV0aW5nID0gdGhpcy5fZGVsZXRpbmcuYXNSZWFkb25seSgpO1xuICByZWFkb25seSBzZWFyY2ggPSB0aGlzLl9zZWFyY2guYXNSZWFkb25seSgpO1xuICByZWFkb25seSBkaWFsb2dWaXNpYmxlID0gdGhpcy5fZGlhbG9nVmlzaWJsZS5hc1JlYWRvbmx5KCk7XG4gIHJlYWRvbmx5IHNlbGVjdGVkVXNlciA9IHRoaXMuX3NlbGVjdGVkVXNlci5hc1JlYWRvbmx5KCk7XG5cbiAgLy8gQ09NUFVUQURPU1xuICByZWFkb25seSB0b3RhbFVzZXJzID0gY29tcHV0ZWQoKCkgPT4gdGhpcy5fdXNlcnMoKS5sZW5ndGgpO1xuICByZWFkb25seSBhY3RpdmVVc2VycyA9IGNvbXB1dGVkKFxuICAgICgpID0+IHRoaXMuX3VzZXJzKCkuZmlsdGVyKCh1c2VyKSA9PiB1c2VyLnN0YXR1cyA9PT0gJ0FjdGl2bycpLmxlbmd0aCxcbiAgKTtcbiAgcmVhZG9ubHkgaW5hY3RpdmVVc2VycyA9IGNvbXB1dGVkKFxuICAgICgpID0+IHRoaXMuX3VzZXJzKCkuZmlsdGVyKCh1c2VyKSA9PiB1c2VyLnN0YXR1cyA9PT0gJ0luYWN0aXZvJykubGVuZ3RoLFxuICApO1xuXG4gIC8vIEV2aXRhciBjYXJnYXMgZHVwbGljYWRhcyBkZSBsYSBBUElcbiAgcHJpdmF0ZSByZWFkb25seSBfbG9hZGVkID0gc2lnbmFsKGZhbHNlKTtcbiAgcHJpdmF0ZSByZWFkb25seSBfZXJyb3IgPSBzaWduYWw8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIHJlYWRvbmx5IGxvYWRlZCA9IHRoaXMuX2xvYWRlZC5hc1JlYWRvbmx5KCk7XG4gIHJlYWRvbmx5IGVycm9yID0gdGhpcy5fZXJyb3IuYXNSZWFkb25seSgpO1xuXG4gIHJlYWRvbmx5IGZpbHRlcmVkVXNlcnMgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgY29uc3QgdGVybSA9IHRoaXMuX3NlYXJjaCgpLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgIGlmICghdGVybSkgcmV0dXJuIHRoaXMuX3VzZXJzKCk7XG4gICAgcmV0dXJuIHRoaXMuX3VzZXJzKCkuZmlsdGVyKFxuICAgICAgKHVzZXIpID0+XG4gICAgICAgIHVzZXIubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHRlcm0pIHx8XG4gICAgICAgIHVzZXIuZW1haWwudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyh0ZXJtKSB8fFxuICAgICAgICB1c2VyLnJvbGUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyh0ZXJtKSB8fFxuICAgICAgICB1c2VyLnN0YXR1cy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHRlcm0pLFxuICAgICk7XG4gIH0pO1xuXG4gIHJlc2V0KCk6IHZvaWQge1xuICAgIHRoaXMucmVxdWVzdFZlcnNpb24rKztcbiAgICB0aGlzLl91c2Vycy5zZXQoW10pO1xuICAgIHRoaXMuX2xvYWRpbmcuc2V0KGZhbHNlKTtcbiAgICB0aGlzLl9zYXZpbmcuc2V0KGZhbHNlKTtcbiAgICB0aGlzLl9kZWxldGluZy5zZXQobnVsbCk7XG4gICAgdGhpcy5fc2VhcmNoLnNldCgnJyk7XG4gICAgdGhpcy5fZGlhbG9nVmlzaWJsZS5zZXQoZmFsc2UpO1xuICAgIHRoaXMuX3NlbGVjdGVkVXNlci5zZXQobnVsbCk7XG4gICAgdGhpcy5fZXJyb3Iuc2V0KG51bGwpO1xuICAgIHRoaXMuX2xvYWRlZC5zZXQoZmFsc2UpO1xuICB9XG5cbiAgLy8gTVVUQUNJT05FUyBESVJFQ1RBUyBERSBFU1RBRE8gTE9DQUxcbiAgc2V0U2VhcmNoKHRlcm06IHN0cmluZyk6IHZvaWQge1xuICAgIHRoaXMuX3NlYXJjaC5zZXQodGVybSk7XG4gIH1cblxuICBvcGVuQ3JlYXRlKCk6IHZvaWQge1xuICAgIGlmICh0aGlzLl9zYXZpbmcoKSB8fCB0aGlzLl9kZWxldGluZygpICE9PSBudWxsKSByZXR1cm47XG4gICAgdGhpcy5fc2VsZWN0ZWRVc2VyLnNldChudWxsKTtcbiAgICB0aGlzLl9kaWFsb2dWaXNpYmxlLnNldCh0cnVlKTtcbiAgfVxuXG4gIG9wZW5FZGl0KHVzZXI6IFVzZXIpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5fc2F2aW5nKCkgfHwgdGhpcy5fZGVsZXRpbmcoKSAhPT0gbnVsbCkgcmV0dXJuO1xuICAgIHRoaXMuX3NlbGVjdGVkVXNlci5zZXQoeyAuLi51c2VyIH0pO1xuICAgIHRoaXMuX2RpYWxvZ1Zpc2libGUuc2V0KHRydWUpO1xuICB9XG5cbiAgY2xvc2VEaWFsb2coKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuX3NhdmluZygpKSByZXR1cm47XG4gICAgdGhpcy5fZGlhbG9nVmlzaWJsZS5zZXQoZmFsc2UpO1xuICAgIHRoaXMuX3NlbGVjdGVkVXNlci5zZXQobnVsbCk7XG4gIH1cblxuICBzZXREaWFsb2dWaXNpYmxlKHZpc2libGU6IGJvb2xlYW4pOiB2b2lkIHtcbiAgICBpZiAodmlzaWJsZSkge1xuICAgICAgdGhpcy5fZGlhbG9nVmlzaWJsZS5zZXQodHJ1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuY2xvc2VEaWFsb2coKTtcbiAgICB9XG4gIH1cblxuICBjaGVja0VtYWlsRXhpc3RzKGVtYWlsOiBzdHJpbmcsIGN1cnJlbnRVc2VySWQ/OiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICBjb25zdCBub3JtYWxpemVkRW1haWwgPSBlbWFpbC50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICByZXR1cm4gdGhpcy5fdXNlcnMoKS5zb21lKFxuICAgICAgKHVzZXIpID0+IHVzZXIuZW1haWwudHJpbSgpLnRvTG93ZXJDYXNlKCkgPT09IG5vcm1hbGl6ZWRFbWFpbCAmJiB1c2VyLmlkICE9PSBjdXJyZW50VXNlcklkLFxuICAgICk7XG4gIH1cblxuICAvLyBBQ0NJT05FUyBBU8ONTkNST05BU1xuXG4gIGxvYWRVc2VycyhcbiAgICBjYWxsYmFja3M/OiB7XG4gICAgICBvbkVycm9yPzogKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4gdm9pZDtcbiAgICB9LFxuICAgIGZvcmNlUmVmcmVzaCA9IGZhbHNlLFxuICApOiB2b2lkIHtcbiAgICAvLyBFdml0YXIgcGV0aWNpb25lcyBzaW11bHTDoW5lYXNcbiAgICBpZiAodGhpcy5fbG9hZGluZygpKSByZXR1cm47XG5cbiAgICAvLyBFdml0YXIgY2FyZ2FzIHJlcGV0aWRhcyBzaSBsb3MgZGF0b3MgeWEgZXhpc3RlblxuICAgIGlmICh0aGlzLl9sb2FkZWQoKSAmJiAhZm9yY2VSZWZyZXNoKSByZXR1cm47XG5cbiAgICB0aGlzLl9sb2FkaW5nLnNldCh0cnVlKTtcbiAgICB0aGlzLl9lcnJvci5zZXQobnVsbCk7XG5cbiAgICAvLyAxLiBDQVBUVVJBUiBMQSBWRVJTScOTTiBBQ1RVQUwgQU5URVMgREUgTEEgUEVUSUNJw5NOXG4gICAgY29uc3QgdmVyc2lvbiA9IHRoaXMucmVxdWVzdFZlcnNpb247XG5cbiAgICB0aGlzLnVzZXJTZXJ2aWNlXG4gICAgICAuZ2V0VXNlcnMoKVxuICAgICAgLnBpcGUoXG4gICAgICAgIHRha2VVbnRpbERlc3Ryb3llZCh0aGlzLmRlc3Ryb3lSZWYpLFxuICAgICAgICBmaW5hbGl6ZSgoKSA9PiB7XG4gICAgICAgICAgLy8gU29sbyBhcGFnYXIgbG9hZGluZyBzaSBzaWd1ZSBzaWVuZG8gbGEgcGV0aWNpw7NuIHZpZ2VudGVcbiAgICAgICAgICBpZiAodmVyc2lvbiA9PT0gdGhpcy5yZXF1ZXN0VmVyc2lvbikge1xuICAgICAgICAgICAgdGhpcy5fbG9hZGluZy5zZXQoZmFsc2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSksXG4gICAgICApXG4gICAgICAuc3Vic2NyaWJlKHtcbiAgICAgICAgbmV4dDogKHVzZXJzKSA9PiB7XG4gICAgICAgICAgLy8gMS4gVkVSSUZJQ0FSIFNJIExBIFZFUlNJw5NOIEVTIExBIE3DgVMgUkVDRU5URVxuICAgICAgICAgIGlmICh2ZXJzaW9uICE9PSB0aGlzLnJlcXVlc3RWZXJzaW9uKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMuX3VzZXJzLnNldCh1c2Vycyk7XG4gICAgICAgICAgdGhpcy5fbG9hZGVkLnNldCh0cnVlKTtcbiAgICAgICAgfSxcbiAgICAgICAgZXJyb3I6IChlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAvLyAyLiBERVNDQVJUQVIgRVJST1IgU0kgTEEgVkVSU0nDk04gWUEgTk8gRVMgVklHRU5URVxuICAgICAgICAgIGlmICh2ZXJzaW9uICE9PSB0aGlzLnJlcXVlc3RWZXJzaW9uKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMuX2Vycm9yLnNldCgnTm8gc2UgcHVkaWVyb24gY2FyZ2FyIGxvcyB1c3Vhcmlvcy4nKTtcbiAgICAgICAgICBjYWxsYmFja3M/Lm9uRXJyb3I/LihlcnJvcik7XG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgfVxuXG4gIHNhdmVVc2VyKFxuICAgIGRhdGE6IFVzZXJGb3JtVmFsdWUsXG4gICAgY2FsbGJhY2tzPzoge1xuICAgICAgb25TdWNjZXNzPzogKGlzRWRpdGluZzogYm9vbGVhbikgPT4gdm9pZDtcbiAgICAgIG9uRXJyb3I/OiAoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiB2b2lkO1xuICAgIH0sXG4gICk6IHZvaWQge1xuICAgIGlmICh0aGlzLl9zYXZpbmcoKSkgcmV0dXJuO1xuXG4gICAgY29uc3QgY3VycmVudFVzZXIgPSB0aGlzLl9zZWxlY3RlZFVzZXIoKTtcbiAgICBjb25zdCBpc0VkaXRpbmcgPSBjdXJyZW50VXNlciAhPT0gbnVsbDtcblxuICAgIGNvbnN0IHVzZXJEYXRhOiBVc2VyRm9ybVZhbHVlID0ge1xuICAgICAgLi4uZGF0YSxcbiAgICAgIG5hbWU6IGRhdGEubmFtZS50cmltKCksXG4gICAgICBlbWFpbDogZGF0YS5lbWFpbC50cmltKCkudG9Mb3dlckNhc2UoKSxcbiAgICB9O1xuXG4gICAgdGhpcy5fc2F2aW5nLnNldCh0cnVlKTtcblxuICAgIGNvbnN0IHJlcXVlc3QkID0gY3VycmVudFVzZXJcbiAgICAgID8gdGhpcy51c2VyU2VydmljZS51cGRhdGVVc2VyKGN1cnJlbnRVc2VyLmlkLCB1c2VyRGF0YSlcbiAgICAgIDogdGhpcy51c2VyU2VydmljZS5jcmVhdGVVc2VyKHVzZXJEYXRhKTtcblxuICAgIHJlcXVlc3QkXG4gICAgICAucGlwZShcbiAgICAgICAgdGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZiksXG4gICAgICAgIGZpbmFsaXplKCgpID0+IHRoaXMuX3NhdmluZy5zZXQoZmFsc2UpKSxcbiAgICAgIClcbiAgICAgIC5zdWJzY3JpYmUoe1xuICAgICAgICBuZXh0OiAoKSA9PiB7XG4gICAgICAgICAgdGhpcy5fZGlhbG9nVmlzaWJsZS5zZXQoZmFsc2UpO1xuICAgICAgICAgIHRoaXMuX3NlbGVjdGVkVXNlci5zZXQobnVsbCk7XG4gICAgICAgICAgY2FsbGJhY2tzPy5vblN1Y2Nlc3M/Lihpc0VkaXRpbmcpO1xuICAgICAgICAgIHRoaXMubG9hZFVzZXJzKHVuZGVmaW5lZCwgdHJ1ZSk7XG4gICAgICAgIH0sXG4gICAgICAgIGVycm9yOiAoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiBjYWxsYmFja3M/Lm9uRXJyb3I/LihlcnJvciksXG4gICAgICB9KTtcbiAgfVxuXG4gIGRlbGV0ZVVzZXIoXG4gICAgaWQ6IHN0cmluZyxcbiAgICBjYWxsYmFja3M/OiB7XG4gICAgICBvblN1Y2Nlc3M/OiAoKSA9PiB2b2lkO1xuICAgICAgb25FcnJvcj86IChlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHZvaWQ7XG4gICAgfSxcbiAgKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuX2RlbGV0aW5nKCkgIT09IG51bGwpIHJldHVybjtcblxuICAgIHRoaXMuX2RlbGV0aW5nLnNldChpZCk7XG5cbiAgICB0aGlzLnVzZXJTZXJ2aWNlXG4gICAgICAuZGVsZXRlVXNlcihpZClcbiAgICAgIC5waXBlKFxuICAgICAgICB0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSxcbiAgICAgICAgZmluYWxpemUoKCkgPT4gdGhpcy5fZGVsZXRpbmcuc2V0KG51bGwpKSxcbiAgICAgIClcbiAgICAgIC5zdWJzY3JpYmUoe1xuICAgICAgICBuZXh0OiAoKSA9PiB7XG4gICAgICAgICAgY2FsbGJhY2tzPy5vblN1Y2Nlc3M/LigpO1xuICAgICAgICAgIHRoaXMubG9hZFVzZXJzKHVuZGVmaW5lZCwgdHJ1ZSk7XG4gICAgICAgIH0sXG4gICAgICAgIGVycm9yOiAoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiBjYWxsYmFja3M/Lm9uRXJyb3I/LihlcnJvciksXG4gICAgICB9KTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuXG5pbXBvcnQgeyBlbnZpcm9ubWVudCB9IGZyb20gJy4uLy4uLy4uLy4uL2Vudmlyb25tZW50cy9lbnZpcm9ubWVudCc7XG5pbXBvcnQgeyBVc2VyLCBVc2VyRm9ybVZhbHVlIH0gZnJvbSAnLi4vdXNlci5tb2RlbCc7XG5cbkBJbmplY3RhYmxlKHtcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxufSlcbmV4cG9ydCBjbGFzcyBVc2VyU2VydmljZSB7XG4gIHByaXZhdGUgcmVhZG9ubHkgaHR0cCA9IGluamVjdChIdHRwQ2xpZW50KTtcbiAgcHJpdmF0ZSByZWFkb25seSBhcGlVcmwgPSBgJHtlbnZpcm9ubWVudC5hcGlVcmx9L3VzZXJzYDtcblxuICAvLyBHRVQ6IE9idGVuZXIgdG9kb3MgbG9zIHVzdWFyaW9zXG4gIGdldFVzZXJzKCk6IE9ic2VydmFibGU8VXNlcltdPiB7XG4gICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8VXNlcltdPih0aGlzLmFwaVVybCk7XG4gIH1cblxuICAvLyBHRVQ6IE9idGVuZXIgdW4gdXN1YXJpbyBwb3IgSURcbiAgZ2V0VXNlckJ5SWQoaWQ6IHN0cmluZyk6IE9ic2VydmFibGU8VXNlcj4ge1xuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFVzZXI+KGAke3RoaXMuYXBpVXJsfS8ke2VuY29kZVVSSUNvbXBvbmVudChpZCl9YCk7XG4gIH1cblxuICAvLyBQT1NUOiBSZWdpc3RyYXIgdXN1YXJpb1xuICBjcmVhdGVVc2VyKHVzZXI6IFVzZXJGb3JtVmFsdWUpOiBPYnNlcnZhYmxlPFVzZXI+IHtcbiAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8VXNlcj4odGhpcy5hcGlVcmwsIHVzZXIpO1xuICB9XG5cbiAgLy8gUFVUOiBBY3R1YWxpemFyIHVzdWFyaW9cbiAgdXBkYXRlVXNlcihpZDogc3RyaW5nLCB1c2VyOiBVc2VyRm9ybVZhbHVlKTogT2JzZXJ2YWJsZTxVc2VyPiB7XG4gICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8VXNlcj4oYCR7dGhpcy5hcGlVcmx9LyR7ZW5jb2RlVVJJQ29tcG9uZW50KGlkKX1gLCB1c2VyKTtcbiAgfVxuXG4gIC8vIERFTEVURTogRWxpbWluYXIgdXN1YXJpb1xuICBkZWxldGVVc2VyKGlkOiBzdHJpbmcpOiBPYnNlcnZhYmxlPHZvaWQ+IHtcbiAgICByZXR1cm4gdGhpcy5odHRwLmRlbGV0ZTx2b2lkPihgJHt0aGlzLmFwaVVybH0vJHtlbmNvZGVVUklDb21wb25lbnQoaWQpfWApO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLFNBQVMsY0FBQUEsYUFBWSxVQUFVLFVBQUFDLFNBQVEsUUFBUSxrQkFBa0I7QUFFakUsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUywwQkFBMEI7OztBQ0huQyxTQUFTLFlBQVksY0FBYztBQUNuQyxTQUFTLGtCQUFrQjs7QUFTckIsSUFBTyxjQUFQLE1BQU8sYUFBVztFQUNMLE9BQU8sT0FBTyxVQUFVO0VBQ3hCLFNBQVMsR0FBRyxZQUFZLE1BQU07O0VBRy9DLFdBQVE7QUFDTixXQUFPLEtBQUssS0FBSyxJQUFZLEtBQUssTUFBTTtFQUMxQzs7RUFHQSxZQUFZLElBQVU7QUFDcEIsV0FBTyxLQUFLLEtBQUssSUFBVSxHQUFHLEtBQUssTUFBTSxJQUFJLG1CQUFtQixFQUFFLENBQUMsRUFBRTtFQUN2RTs7RUFHQSxXQUFXLE1BQW1CO0FBQzVCLFdBQU8sS0FBSyxLQUFLLEtBQVcsS0FBSyxRQUFRLElBQUk7RUFDL0M7O0VBR0EsV0FBVyxJQUFZLE1BQW1CO0FBQ3hDLFdBQU8sS0FBSyxLQUFLLElBQVUsR0FBRyxLQUFLLE1BQU0sSUFBSSxtQkFBbUIsRUFBRSxDQUFDLElBQUksSUFBSTtFQUM3RTs7RUFHQSxXQUFXLElBQVU7QUFDbkIsV0FBTyxLQUFLLEtBQUssT0FBYSxHQUFHLEtBQUssTUFBTSxJQUFJLG1CQUFtQixFQUFFLENBQUMsRUFBRTtFQUMxRTs7cUNBM0JXLGNBQVc7RUFBQTsrRUFBWCxjQUFXLFNBQVgsYUFBVyxXQUFBLFlBRlYsT0FBTSxDQUFBOzs7K0VBRVAsYUFBVyxDQUFBO1VBSHZCO1dBQVc7TUFDVixZQUFZO0tBQ2I7OztBOzs7QURFSyxJQUFPLFlBQVAsTUFBTyxXQUFTO0VBQ0gsY0FBY0MsUUFBTyxXQUFXO0VBQ2hDLGFBQWFBLFFBQU8sVUFBVTtFQUV2QyxpQkFBaUI7O0VBR1IsU0FBUyxPQUFlLENBQUEsR0FBRSxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsU0FBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUMxQixXQUFXLE9BQWdCLE9BQUssR0FBQSxZQUFBLENBQUEsRUFBQSxXQUFBLFdBQUEsQ0FBQTs7SUFBQSxDQUFBO0dBQUE7RUFDaEMsVUFBVSxPQUFnQixPQUFLLEdBQUEsWUFBQSxDQUFBLEVBQUEsV0FBQSxVQUFBLENBQUE7O0lBQUEsQ0FBQTtHQUFBO0VBQy9CLFlBQVksT0FBc0IsTUFBSSxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsWUFBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUN0QyxVQUFVLE9BQWUsSUFBRSxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsVUFBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUMzQixpQkFBaUIsT0FBZ0IsT0FBSyxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsaUJBQUEsQ0FBQTs7SUFBQSxDQUFBO0dBQUE7RUFDdEMsZ0JBQWdCLE9BQW9CLE1BQUksR0FBQSxZQUFBLENBQUEsRUFBQSxXQUFBLGdCQUFBLENBQUE7O0lBQUEsQ0FBQTtHQUFBOztFQUdoRCxRQUFRLEtBQUssT0FBTyxXQUFVO0VBQzlCLFVBQVUsS0FBSyxTQUFTLFdBQVU7RUFDbEMsU0FBUyxLQUFLLFFBQVEsV0FBVTtFQUNoQyxXQUFXLEtBQUssVUFBVSxXQUFVO0VBQ3BDLFNBQVMsS0FBSyxRQUFRLFdBQVU7RUFDaEMsZ0JBQWdCLEtBQUssZUFBZSxXQUFVO0VBQzlDLGVBQWUsS0FBSyxjQUFjLFdBQVU7O0VBRzVDLGFBQWEsU0FBUyxNQUFNLEtBQUssT0FBTSxFQUFHLFFBQU0sR0FBQSxZQUFBLENBQUEsRUFBQSxXQUFBLGFBQUEsQ0FBQTs7SUFBQSxDQUFBO0dBQUE7RUFDaEQsY0FBYyxTQUNyQixNQUFNLEtBQUssT0FBTSxFQUFHLE9BQU8sQ0FBQyxTQUFTLEtBQUssV0FBVyxRQUFRLEVBQUUsUUFBTSxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsY0FBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUU5RCxnQkFBZ0IsU0FDdkIsTUFBTSxLQUFLLE9BQU0sRUFBRyxPQUFPLENBQUMsU0FBUyxLQUFLLFdBQVcsVUFBVSxFQUFFLFFBQU0sR0FBQSxZQUFBLENBQUEsRUFBQSxXQUFBLGdCQUFBLENBQUE7O0lBQUEsQ0FBQTtHQUFBOztFQUl4RCxVQUFVLE9BQU8sT0FBSyxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsVUFBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUN0QixTQUFTLE9BQXNCLE1BQUksR0FBQSxZQUFBLENBQUEsRUFBQSxXQUFBLFNBQUEsQ0FBQTs7SUFBQSxDQUFBO0dBQUE7RUFDM0MsU0FBUyxLQUFLLFFBQVEsV0FBVTtFQUNoQyxRQUFRLEtBQUssT0FBTyxXQUFVO0VBRTlCLGdCQUFnQixTQUFTLE1BQUs7QUFDckMsVUFBTSxPQUFPLEtBQUssUUFBTyxFQUFHLEtBQUksRUFBRyxZQUFXO0FBQzlDLFFBQUksQ0FBQztBQUFNLGFBQU8sS0FBSyxPQUFNO0FBQzdCLFdBQU8sS0FBSyxPQUFNLEVBQUcsT0FDbkIsQ0FBQyxTQUNDLEtBQUssS0FBSyxZQUFXLEVBQUcsU0FBUyxJQUFJLEtBQ3JDLEtBQUssTUFBTSxZQUFXLEVBQUcsU0FBUyxJQUFJLEtBQ3RDLEtBQUssS0FBSyxZQUFXLEVBQUcsU0FBUyxJQUFJLEtBQ3JDLEtBQUssT0FBTyxZQUFXLEVBQUcsU0FBUyxJQUFJLENBQUM7RUFFOUMsR0FBQyxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsZ0JBQUEsQ0FBQTs7SUFBQSxDQUFBO0dBQUE7RUFFRCxRQUFLO0FBQ0gsU0FBSztBQUNMLFNBQUssT0FBTyxJQUFJLENBQUEsQ0FBRTtBQUNsQixTQUFLLFNBQVMsSUFBSSxLQUFLO0FBQ3ZCLFNBQUssUUFBUSxJQUFJLEtBQUs7QUFDdEIsU0FBSyxVQUFVLElBQUksSUFBSTtBQUN2QixTQUFLLFFBQVEsSUFBSSxFQUFFO0FBQ25CLFNBQUssZUFBZSxJQUFJLEtBQUs7QUFDN0IsU0FBSyxjQUFjLElBQUksSUFBSTtBQUMzQixTQUFLLE9BQU8sSUFBSSxJQUFJO0FBQ3BCLFNBQUssUUFBUSxJQUFJLEtBQUs7RUFDeEI7O0VBR0EsVUFBVSxNQUFZO0FBQ3BCLFNBQUssUUFBUSxJQUFJLElBQUk7RUFDdkI7RUFFQSxhQUFVO0FBQ1IsUUFBSSxLQUFLLFFBQU8sS0FBTSxLQUFLLFVBQVMsTUFBTztBQUFNO0FBQ2pELFNBQUssY0FBYyxJQUFJLElBQUk7QUFDM0IsU0FBSyxlQUFlLElBQUksSUFBSTtFQUM5QjtFQUVBLFNBQVMsTUFBVTtBQUNqQixRQUFJLEtBQUssUUFBTyxLQUFNLEtBQUssVUFBUyxNQUFPO0FBQU07QUFDakQsU0FBSyxjQUFjLElBQUksbUJBQUssS0FBTTtBQUNsQyxTQUFLLGVBQWUsSUFBSSxJQUFJO0VBQzlCO0VBRUEsY0FBVztBQUNULFFBQUksS0FBSyxRQUFPO0FBQUk7QUFDcEIsU0FBSyxlQUFlLElBQUksS0FBSztBQUM3QixTQUFLLGNBQWMsSUFBSSxJQUFJO0VBQzdCO0VBRUEsaUJBQWlCLFNBQWdCO0FBQy9CLFFBQUksU0FBUztBQUNYLFdBQUssZUFBZSxJQUFJLElBQUk7SUFDOUIsT0FBTztBQUNMLFdBQUssWUFBVztJQUNsQjtFQUNGO0VBRUEsaUJBQWlCLE9BQWUsZUFBc0I7QUFDcEQsVUFBTSxrQkFBa0IsTUFBTSxLQUFJLEVBQUcsWUFBVztBQUNoRCxXQUFPLEtBQUssT0FBTSxFQUFHLEtBQ25CLENBQUMsU0FBUyxLQUFLLE1BQU0sS0FBSSxFQUFHLFlBQVcsTUFBTyxtQkFBbUIsS0FBSyxPQUFPLGFBQWE7RUFFOUY7O0VBSUEsVUFDRSxXQUdBLGVBQWUsT0FBSztBQUdwQixRQUFJLEtBQUssU0FBUTtBQUFJO0FBR3JCLFFBQUksS0FBSyxRQUFPLEtBQU0sQ0FBQztBQUFjO0FBRXJDLFNBQUssU0FBUyxJQUFJLElBQUk7QUFDdEIsU0FBSyxPQUFPLElBQUksSUFBSTtBQUdwQixVQUFNLFVBQVUsS0FBSztBQUVyQixTQUFLLFlBQ0YsU0FBUSxFQUNSLEtBQ0MsbUJBQW1CLEtBQUssVUFBVSxHQUNsQyxTQUFTLE1BQUs7QUFFWixVQUFJLFlBQVksS0FBSyxnQkFBZ0I7QUFDbkMsYUFBSyxTQUFTLElBQUksS0FBSztNQUN6QjtJQUNGLENBQUMsQ0FBQyxFQUVILFVBQVU7TUFDVCxNQUFNLENBQUMsVUFBUztBQUVkLFlBQUksWUFBWSxLQUFLLGdCQUFnQjtBQUNuQztRQUNGO0FBQ0EsYUFBSyxPQUFPLElBQUksS0FBSztBQUNyQixhQUFLLFFBQVEsSUFBSSxJQUFJO01BQ3ZCO01BQ0EsT0FBTyxDQUFDLFVBQTRCO0FBRWxDLFlBQUksWUFBWSxLQUFLLGdCQUFnQjtBQUNuQztRQUNGO0FBQ0EsYUFBSyxPQUFPLElBQUkscUNBQXFDO0FBQ3JELG1CQUFXLFVBQVUsS0FBSztNQUM1QjtLQUNEO0VBQ0w7RUFFQSxTQUNFLE1BQ0EsV0FHQztBQUVELFFBQUksS0FBSyxRQUFPO0FBQUk7QUFFcEIsVUFBTSxjQUFjLEtBQUssY0FBYTtBQUN0QyxVQUFNLFlBQVksZ0JBQWdCO0FBRWxDLFVBQU0sV0FBMEIsaUNBQzNCLE9BRDJCO01BRTlCLE1BQU0sS0FBSyxLQUFLLEtBQUk7TUFDcEIsT0FBTyxLQUFLLE1BQU0sS0FBSSxFQUFHLFlBQVc7O0FBR3RDLFNBQUssUUFBUSxJQUFJLElBQUk7QUFFckIsVUFBTSxXQUFXLGNBQ2IsS0FBSyxZQUFZLFdBQVcsWUFBWSxJQUFJLFFBQVEsSUFDcEQsS0FBSyxZQUFZLFdBQVcsUUFBUTtBQUV4QyxhQUNHLEtBQ0MsbUJBQW1CLEtBQUssVUFBVSxHQUNsQyxTQUFTLE1BQU0sS0FBSyxRQUFRLElBQUksS0FBSyxDQUFDLENBQUMsRUFFeEMsVUFBVTtNQUNULE1BQU0sTUFBSztBQUNULGFBQUssZUFBZSxJQUFJLEtBQUs7QUFDN0IsYUFBSyxjQUFjLElBQUksSUFBSTtBQUMzQixtQkFBVyxZQUFZLFNBQVM7QUFDaEMsYUFBSyxVQUFVLFFBQVcsSUFBSTtNQUNoQztNQUNBLE9BQU8sQ0FBQyxVQUE2QixXQUFXLFVBQVUsS0FBSztLQUNoRTtFQUNMO0VBRUEsV0FDRSxJQUNBLFdBR0M7QUFFRCxRQUFJLEtBQUssVUFBUyxNQUFPO0FBQU07QUFFL0IsU0FBSyxVQUFVLElBQUksRUFBRTtBQUVyQixTQUFLLFlBQ0YsV0FBVyxFQUFFLEVBQ2IsS0FDQyxtQkFBbUIsS0FBSyxVQUFVLEdBQ2xDLFNBQVMsTUFBTSxLQUFLLFVBQVUsSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUV6QyxVQUFVO01BQ1QsTUFBTSxNQUFLO0FBQ1QsbUJBQVcsWUFBVztBQUN0QixhQUFLLFVBQVUsUUFBVyxJQUFJO01BQ2hDO01BQ0EsT0FBTyxDQUFDLFVBQTZCLFdBQVcsVUFBVSxLQUFLO0tBQ2hFO0VBQ0w7O3FDQXpOVyxZQUFTO0VBQUE7Z0ZBQVQsWUFBUyxTQUFULFdBQVMsV0FBQSxZQUZSLE9BQU0sQ0FBQTs7O2dGQUVQLFdBQVMsQ0FBQTtVQUhyQkM7V0FBVztNQUNWLFlBQVk7S0FDYjs7OyIsIm5hbWVzIjpbIkluamVjdGFibGUiLCJpbmplY3QiLCJpbmplY3QiLCJJbmplY3RhYmxlIl19