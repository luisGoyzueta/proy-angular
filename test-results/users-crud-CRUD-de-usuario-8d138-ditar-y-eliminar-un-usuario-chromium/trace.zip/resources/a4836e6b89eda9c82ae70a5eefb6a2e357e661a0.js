import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/chunk-2SHIL3UT.js");import {
  PermissionService
} from "/chunk-KIW7SE4H.js";
import "/chunk-HUEL4CRJ.js";
import {
  UserStore
} from "/chunk-WOIO7PCB.js";
import "/chunk-P37EOHI7.js";
import "/chunk-VUJOFXKG.js";

// src/app/features/users/users.ts
import { Component as Component2, inject as inject2, computed as computed2 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { FormsModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_forms.js?v=b9a49161";
import { TableModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_table.js?v=b9a49161";
import { TagModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_tag.js?v=b9a49161";
import { ButtonModule as ButtonModule2 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_button.js?v=b9a49161";
import { InputTextModule as InputTextModule2 } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_inputtext.js?v=b9a49161";
import { ConfirmDialogModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_confirmdialog.js?v=b9a49161";
import { ToastModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_toast.js?v=b9a49161";
import { ConfirmationService, MessageService } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_api.js?v=b9a49161";

// src/app/features/users/user-form/user-form.ts
import { Component, input, output, computed, effect, untracked, inject } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { FormBuilder, ReactiveFormsModule, Validators } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_forms.js?v=b9a49161";
import { DialogModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_dialog.js?v=b9a49161";
import { InputTextModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_inputtext.js?v=b9a49161";
import { SelectModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_select.js?v=b9a49161";
import { ButtonModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_button.js?v=b9a49161";
import * as i0 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import * as i1 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_forms.js?v=b9a49161";
import * as i2 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_dialog.js?v=b9a49161";
import * as i3 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_api.js?v=b9a49161";
import * as i4 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_inputtext.js?v=b9a49161";
import * as i5 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_select.js?v=b9a49161";
import * as i6 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_button.js?v=b9a49161";
var _c0 = () => ({ width: "550px", maxWidth: "95vw" });
var _c1 = () => ({ "640px": "95vw" });
function UserForm_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "small", 7);
    i0.\u0275\u0275text(1, " El nombre es obligatorio. ");
    i0.\u0275\u0275elementEnd();
  }
}
function UserForm_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "small", 7);
    i0.\u0275\u0275text(1, " El nombre debe tener al menos 3 caracteres. ");
    i0.\u0275\u0275elementEnd();
  }
}
function UserForm_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "small", 7);
    i0.\u0275\u0275text(1, " El nombre no debe superar los 100 caracteres. ");
    i0.\u0275\u0275elementEnd();
  }
}
function UserForm_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "small", 10);
    i0.\u0275\u0275text(1, " El correo es obligatorio. ");
    i0.\u0275\u0275elementEnd();
  }
}
function UserForm_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "small", 10);
    i0.\u0275\u0275text(1, " Ingresa un correo electr\xF3nico v\xE1lido. ");
    i0.\u0275\u0275elementEnd();
  }
}
function UserForm_ng_template_32_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 16)(1, "p-button", 17);
    i0.\u0275\u0275listener("onClick", function UserForm_ng_template_32_Template_p_button_onClick_1_listener() {
      i0.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.close());
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(2, "p-button", 18);
    i0.\u0275\u0275listener("onClick", function UserForm_ng_template_32_Template_p_button_onClick_2_listener() {
      i0.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.submit());
    });
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275property("outlined", true);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275property("label", ctx_r1.isEditing() ? "Actualizar" : "Guardar usuario");
  }
}
var UserForm = class _UserForm {
  fb = inject(FormBuilder);
  // Inputs modernos con Signals
  visible = input(false, ...ngDevMode ? [{ debugName: "visible" }] : (
    /* istanbul ignore next */
    []
  ));
  user = input(null, ...ngDevMode ? [{ debugName: "user" }] : (
    /* istanbul ignore next */
    []
  ));
  // Outputs modernos
  visibleChange = output();
  save = output();
  // Opciones de los selectores
  roles = [
    { label: "Administrador", value: "Administrador" },
    { label: "Editor", value: "Editor" },
    { label: "Usuario", value: "Usuario" }
  ];
  statuses = [
    { label: "Activo", value: "Activo" },
    { label: "Inactivo", value: "Inactivo" }
  ];
  // Formulario reactivo
  form = this.fb.nonNullable.group({
    name: ["", [Validators.required, Validators.minLength(3), Validators.maxLength(100)]],
    email: ["", [Validators.required, Validators.email]],
    role: this.fb.nonNullable.control("Usuario", Validators.required),
    status: this.fb.nonNullable.control("Activo", Validators.required)
  });
  // Detectar si estamos editando
  isEditing = computed(() => this.user() !== null, ...ngDevMode ? [{ debugName: "isEditing" }] : (
    /* istanbul ignore next */
    []
  ));
  constructor() {
    let previousVisible = false;
    let previousUserId = null;
    effect(() => {
      const isVisible = this.visible();
      const currentUser = this.user();
      const currentUserId = currentUser?.id ?? null;
      const justOpened = isVisible && !previousVisible;
      const userChanged = isVisible && currentUserId !== previousUserId;
      previousVisible = isVisible;
      previousUserId = isVisible ? currentUserId : null;
      if (justOpened || userChanged) {
        untracked(() => this.loadForm(currentUser));
      }
    });
  }
  // Cargar datos para crear o editar
  loadForm(user) {
    this.form.reset({
      name: user?.name ?? "",
      email: user?.email ?? "",
      role: user?.role ?? "Usuario",
      status: user?.status ?? "Activo"
    });
  }
  // Validar y emitir los datos
  submit() {
    this.form.markAllAsTouched();
    if (this.form.invalid) {
      return;
    }
    const value = this.form.getRawValue();
    this.save.emit({
      name: value.name.trim(),
      email: value.email.trim(),
      role: value.role,
      status: value.status
    });
  }
  // Solicitar el cierre del modal
  close() {
    this.visibleChange.emit(false);
  }
  static \u0275fac = function UserForm_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _UserForm)();
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _UserForm, selectors: [["app-user-form"]], inputs: { visible: [1, "visible"], user: [1, "user"] }, outputs: { visibleChange: "visibleChange", save: "save" }, decls: 34, vars: 25, consts: [["footer", ""], [3, "visibleChange", "header", "visible", "modal", "draggable", "resizable", "closable", "dismissableMask", "breakpoints"], ["id", "userForm", "data-testid", "user-form", 1, "user-form", 3, "ngSubmit", "formGroup"], [1, "field"], ["for", "name"], [1, "required"], ["id", "name", "pInputText", "", "data-testid", "user-name", "type", "text", "formControlName", "name", "placeholder", "Ingresa el nombre completo", "aria-required", "true"], ["id", "name-error", 1, "error"], ["for", "email"], ["id", "email", "pInputText", "", "data-testid", "user-email", "type", "email", "formControlName", "email", "placeholder", "ejemplo@empresa.com", "aria-required", "true"], ["id", "email-error", 1, "error"], [1, "form-grid"], ["for", "role"], ["inputId", "role", "optionLabel", "label", "optionValue", "value", "data-testid", "user-role", "formControlName", "role", "placeholder", "Seleccionar rol", "aria-required", "true", "appendTo", "body", "styleClass", "full-control", 3, "options"], ["for", "status"], ["inputId", "status", "optionLabel", "label", "optionValue", "value", "data-testid", "user-status", "formControlName", "status", "placeholder", "Seleccionar estado", "aria-required", "true", "appendTo", "body", "styleClass", "full-control", 3, "options"], [1, "dialog-actions"], ["label", "Cancelar", "icon", "pi pi-times", "severity", "secondary", 3, "onClick", "outlined"], ["data-testid", "save-user-button", "type", "button", "icon", "pi pi-check", 3, "onClick", "label"]], template: function UserForm_Template(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275elementStart(0, "p-dialog", 1);
      i0.\u0275\u0275listener("visibleChange", function UserForm_Template_p_dialog_visibleChange_0_listener($event) {
        return ctx.visibleChange.emit($event);
      });
      i0.\u0275\u0275elementStart(1, "form", 2);
      i0.\u0275\u0275listener("ngSubmit", function UserForm_Template_form_ngSubmit_1_listener() {
        return ctx.submit();
      });
      i0.\u0275\u0275elementStart(2, "div", 3)(3, "label", 4);
      i0.\u0275\u0275text(4, " Nombre completo ");
      i0.\u0275\u0275elementStart(5, "span", 5);
      i0.\u0275\u0275text(6, "*");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275element(7, "input", 6);
      i0.\u0275\u0275conditionalCreate(8, UserForm_Conditional_8_Template, 2, 0, "small", 7)(9, UserForm_Conditional_9_Template, 2, 0, "small", 7)(10, UserForm_Conditional_10_Template, 2, 0, "small", 7);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(11, "div", 3)(12, "label", 8);
      i0.\u0275\u0275text(13, " Correo electr\xF3nico ");
      i0.\u0275\u0275elementStart(14, "span", 5);
      i0.\u0275\u0275text(15, "*");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275element(16, "input", 9);
      i0.\u0275\u0275conditionalCreate(17, UserForm_Conditional_17_Template, 2, 0, "small", 10)(18, UserForm_Conditional_18_Template, 2, 0, "small", 10);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(19, "div", 11)(20, "div", 3)(21, "label", 12);
      i0.\u0275\u0275text(22, " Rol ");
      i0.\u0275\u0275elementStart(23, "span", 5);
      i0.\u0275\u0275text(24, "*");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275element(25, "p-select", 13);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(26, "div", 3)(27, "label", 14);
      i0.\u0275\u0275text(28, " Estado ");
      i0.\u0275\u0275elementStart(29, "span", 5);
      i0.\u0275\u0275text(30, "*");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275element(31, "p-select", 15);
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275template(32, UserForm_ng_template_32_Template, 3, 2, "ng-template", null, 0, i0.\u0275\u0275templateRefExtractor);
      i0.\u0275\u0275elementEnd();
    }
    if (rf & 2) {
      i0.\u0275\u0275styleMap(i0.\u0275\u0275pureFunction0(23, _c0));
      i0.\u0275\u0275property("header", ctx.isEditing() ? "Editar usuario" : "Nuevo usuario")("visible", ctx.visible())("modal", true)("draggable", false)("resizable", false)("closable", true)("dismissableMask", false)("breakpoints", i0.\u0275\u0275pureFunction0(24, _c1));
      i0.\u0275\u0275advance();
      i0.\u0275\u0275property("formGroup", ctx.form);
      i0.\u0275\u0275advance(6);
      i0.\u0275\u0275classProp("ng-invalid", ctx.form.controls.name.touched && ctx.form.controls.name.invalid);
      i0.\u0275\u0275attribute("aria-invalid", ctx.form.controls.name.touched && ctx.form.controls.name.invalid)("aria-describedby", ctx.form.controls.name.touched && ctx.form.controls.name.invalid ? "name-error" : null);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.form.controls.name.touched && ctx.form.controls.name.hasError("required") ? 8 : ctx.form.controls.name.touched && ctx.form.controls.name.hasError("minlength") ? 9 : ctx.form.controls.name.touched && ctx.form.controls.name.hasError("maxlength") ? 10 : -1);
      i0.\u0275\u0275advance(8);
      i0.\u0275\u0275classProp("ng-invalid", ctx.form.controls.email.touched && ctx.form.controls.email.invalid);
      i0.\u0275\u0275attribute("aria-invalid", ctx.form.controls.email.touched && ctx.form.controls.email.invalid)("aria-describedby", ctx.form.controls.email.touched && ctx.form.controls.email.invalid ? "email-error" : null);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.form.controls.email.touched && ctx.form.controls.email.hasError("required") ? 17 : ctx.form.controls.email.touched && ctx.form.controls.email.hasError("email") ? 18 : -1);
      i0.\u0275\u0275advance(8);
      i0.\u0275\u0275property("options", ctx.roles);
      i0.\u0275\u0275advance(6);
      i0.\u0275\u0275property("options", ctx.statuses);
    }
  }, dependencies: [ReactiveFormsModule, i1.\u0275NgNoValidate, i1.NgSelectOption, i1.\u0275NgSelectMultipleOption, i1.DefaultValueAccessor, i1.NumberValueAccessor, i1.RangeValueAccessor, i1.CheckboxControlValueAccessor, i1.SelectControlValueAccessor, i1.SelectMultipleControlValueAccessor, i1.RadioControlValueAccessor, i1.NgControlStatus, i1.NgControlStatusGroup, i1.RequiredValidator, i1.MinLengthValidator, i1.MaxLengthValidator, i1.PatternValidator, i1.CheckboxRequiredValidator, i1.EmailValidator, i1.MinValidator, i1.MaxValidator, i1.FormControlDirective, i1.FormGroupDirective, i1.FormArrayDirective, i1.FormControlName, i1.FormGroupName, i1.FormArrayName, DialogModule, i2.Dialog, i3.Header, i3.Footer, i3.PrimeTemplate, InputTextModule, i4.InputText, SelectModule, i5.Select, ButtonModule, i6.ButtonDirective, i6.Button, i6.ButtonLabel, i6.ButtonIcon], styles: ["\n.user-form[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 22px;\n  padding: 12px 0;\n}\n.field[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 9px;\n  min-width: 0;\n}\n.field[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 600;\n  color: #334155;\n}\n.field[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: 100%;\n  min-height: 44px;\n  border-radius: 8px;\n}\n.required[_ngcontent-%COMP%] {\n  color: #dc2626;\n}\n.error[_ngcontent-%COMP%] {\n  color: #dc2626;\n  font-size: 12px;\n  line-height: 1.4;\n}\n.form-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  gap: 16px;\n}\n[_nghost-%COMP%]     .full-control {\n  width: 100%;\n  min-height: 44px;\n}\n.dialog-actions[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: flex-end;\n  gap: 12px;\n  padding-top: 12px;\n}\ninput.ng-invalid.ng-touched[_ngcontent-%COMP%] {\n  border-color: #dc2626;\n}\n.error[_ngcontent-%COMP%] {\n  color: #dc2626;\n  font-size: 12px;\n}\n@media (max-width: 600px) {\n  .form-grid[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n  .dialog-actions[_ngcontent-%COMP%] {\n    flex-wrap: wrap;\n  }\n}\n/*# sourceMappingURL=user-form.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(UserForm, [{
    type: Component,
    args: [{ selector: "app-user-form", standalone: true, imports: [ReactiveFormsModule, DialogModule, InputTextModule, SelectModule, ButtonModule], template: `<p-dialog
  [header]="isEditing() ? 'Editar usuario' : 'Nuevo usuario'"
  [visible]="visible()"
  (visibleChange)="visibleChange.emit($event)"
  [modal]="true"
  [draggable]="false"
  [resizable]="false"
  [closable]="true"
  [dismissableMask]="false"
  [style]="{ width: '550px', maxWidth: '95vw' }"
  [breakpoints]="{ '640px': '95vw' }"
>
  <form
    id="userForm"
    data-testid="user-form"
    [formGroup]="form"
    (ngSubmit)="submit()"
    class="user-form"
  >
    <!-- NOMBRE -->
    <div class="field">
      <label for="name"> Nombre completo <span class="required">*</span> </label>

      <input
        id="name"
        pInputText
        data-testid="user-name"
        type="text"
        formControlName="name"
        placeholder="Ingresa el nombre completo"
        aria-required="true"
        [class.ng-invalid]="form.controls.name.touched && form.controls.name.invalid"
        [attr.aria-invalid]="form.controls.name.touched && form.controls.name.invalid"
        [attr.aria-describedby]="
          form.controls.name.touched && form.controls.name.invalid ? 'name-error' : null
        "
      />

      @if (form.controls.name.touched && form.controls.name.hasError('required')) {
        <small id="name-error" class="error"> El nombre es obligatorio. </small>
      } @else if (form.controls.name.touched && form.controls.name.hasError('minlength')) {
        <small id="name-error" class="error"> El nombre debe tener al menos 3 caracteres. </small>
      } @else if (form.controls.name.touched && form.controls.name.hasError('maxlength')) {
        <small id="name-error" class="error"> El nombre no debe superar los 100 caracteres. </small>
      }
    </div>

    <!-- CORREO -->
    <div class="field">
      <label for="email"> Correo electr\xF3nico <span class="required">*</span> </label>

      <input
        id="email"
        pInputText
        data-testid="user-email"
        type="email"
        formControlName="email"
        placeholder="ejemplo@empresa.com"
        aria-required="true"
        [class.ng-invalid]="form.controls.email.touched && form.controls.email.invalid"
        [attr.aria-invalid]="form.controls.email.touched && form.controls.email.invalid"
        [attr.aria-describedby]="
          form.controls.email.touched && form.controls.email.invalid ? 'email-error' : null
        "
      />

      @if (form.controls.email.touched && form.controls.email.hasError('required')) {
        <small id="email-error" class="error"> El correo es obligatorio. </small>
      } @else if (form.controls.email.touched && form.controls.email.hasError('email')) {
        <small id="email-error" class="error"> Ingresa un correo electr\xF3nico v\xE1lido. </small>
      }
    </div>

    <!-- ROL Y ESTADO -->
    <div class="form-grid">
      <div class="field">
        <label for="role"> Rol <span class="required">*</span> </label>

        <p-select
          inputId="role"
          [options]="roles"
          optionLabel="label"
          optionValue="value"
          data-testid="user-role"
          formControlName="role"
          placeholder="Seleccionar rol"
          aria-required="true"
          appendTo="body"
          styleClass="full-control"
        />
      </div>

      <div class="field">
        <label for="status"> Estado <span class="required">*</span> </label>

        <p-select
          inputId="status"
          [options]="statuses"
          optionLabel="label"
          optionValue="value"
          data-testid="user-status"
          formControlName="status"
          placeholder="Seleccionar estado"
          aria-required="true"
          appendTo="body"
          styleClass="full-control"
        />
      </div>
    </div>
  </form>

  <!-- BOTONES -->
  <ng-template #footer>
    <div class="dialog-actions">
      <p-button
        label="Cancelar"
        icon="pi pi-times"
        severity="secondary"
        [outlined]="true"
        (onClick)="close()"
      />

      <p-button
        data-testid="save-user-button"
        type="button"
        [label]="isEditing() ? 'Actualizar' : 'Guardar usuario'"
        icon="pi pi-check"
        (onClick)="submit()"
      />
    </div>
  </ng-template>
</p-dialog>
`, styles: ["/* src/app/features/users/user-form/user-form.scss */\n.user-form {\n  display: flex;\n  flex-direction: column;\n  gap: 22px;\n  padding: 12px 0;\n}\n.field {\n  display: flex;\n  flex-direction: column;\n  gap: 9px;\n  min-width: 0;\n}\n.field label {\n  font-size: 14px;\n  font-weight: 600;\n  color: #334155;\n}\n.field input {\n  width: 100%;\n  min-height: 44px;\n  border-radius: 8px;\n}\n.required {\n  color: #dc2626;\n}\n.error {\n  color: #dc2626;\n  font-size: 12px;\n  line-height: 1.4;\n}\n.form-grid {\n  display: grid;\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  gap: 16px;\n}\n:host ::ng-deep .full-control {\n  width: 100%;\n  min-height: 44px;\n}\n.dialog-actions {\n  display: flex;\n  justify-content: flex-end;\n  gap: 12px;\n  padding-top: 12px;\n}\ninput.ng-invalid.ng-touched {\n  border-color: #dc2626;\n}\n.error {\n  color: #dc2626;\n  font-size: 12px;\n}\n@media (max-width: 600px) {\n  .form-grid {\n    grid-template-columns: 1fr;\n  }\n  .dialog-actions {\n    flex-wrap: wrap;\n  }\n}\n/*# sourceMappingURL=user-form.css.map */\n"] }]
  }], () => [], { visible: [{ type: i0.Input, args: [{ isSignal: true, alias: "visible", required: false }] }], user: [{ type: i0.Input, args: [{ isSignal: true, alias: "user", required: false }] }], visibleChange: [{ type: i0.Output, args: ["visibleChange"] }], save: [{ type: i0.Output, args: ["save"] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(UserForm, { className: "UserForm", filePath: "app/features/users/user-form/user-form.ts", lineNumber: 16 });
})();
(() => {
  const id = "app%2Ffeatures%2Fusers%2Fuser-form%2Fuser-form.ts%40UserForm";
  function UserForm_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i0.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i0.\u0275\u0275replaceMetadata(UserForm, m.default, [i0, i1, i2, i3, i4, i5, i6], [ReactiveFormsModule, DialogModule, InputTextModule, SelectModule, ButtonModule, Component], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && UserForm_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && UserForm_HmrLoad(d.timestamp)));
})();

// src/app/features/users/users.ts
import * as i02 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import * as i12 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_forms.js?v=b9a49161";
import * as i22 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_table.js?v=b9a49161";
import * as i32 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_api.js?v=b9a49161";
import * as i42 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_scroller.js?v=b9a49161";
import * as i52 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_tag.js?v=b9a49161";
import * as i62 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_button.js?v=b9a49161";
import * as i7 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_inputtext.js?v=b9a49161";
import * as i8 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_confirmdialog.js?v=b9a49161";
import * as i9 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_toast.js?v=b9a49161";
var _c02 = () => [10, 20, 30];
var _c12 = () => ({ "min-width": "750px" });
function Users_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275elementStart(0, "p-button", 10);
    i02.\u0275\u0275listener("onClick", function Users_Conditional_7_Template_p_button_onClick_0_listener() {
      i02.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r1.openCreate());
    });
    i02.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275property("disabled", ctx_r1.saving() || ctx_r1.deleting());
  }
}
function Users_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275elementStart(0, "div", 11)(1, "div", 12)(2, "label", 13);
    i02.\u0275\u0275text(3, "Buscar usuario");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(4, "input", 14);
    i02.\u0275\u0275listener("ngModelChange", function Users_ng_template_10_Template_input_ngModelChange_4_listener($event) {
      i02.\u0275\u0275restoreView(_r3);
      const ctx_r1 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r1.setSearch($event));
    });
    i02.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275property("ngModel", ctx_r1.search());
  }
}
function Users_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275elementStart(0, "tr")(1, "th", 15);
    i02.\u0275\u0275text(2, " Nombre ");
    i02.\u0275\u0275element(3, "p-sortIcon", 16);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(4, "th", 17);
    i02.\u0275\u0275text(5, " Correo electr\xF3nico ");
    i02.\u0275\u0275element(6, "p-sortIcon", 18);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(7, "th", 19);
    i02.\u0275\u0275text(8, " Rol ");
    i02.\u0275\u0275element(9, "p-sortIcon", 20);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(10, "th", 21);
    i02.\u0275\u0275text(11, " Estado ");
    i02.\u0275\u0275element(12, "p-sortIcon", 22);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(13, "th");
    i02.\u0275\u0275text(14, "Acciones");
    i02.\u0275\u0275elementEnd()();
  }
}
function Users_ng_template_14_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275elementStart(0, "p-button", 29);
    i02.\u0275\u0275listener("onClick", function Users_ng_template_14_Conditional_14_Template_p_button_onClick_0_listener() {
      i02.\u0275\u0275restoreView(_r4);
      const user_r5 = i02.\u0275\u0275nextContext().$implicit;
      const ctx_r1 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r1.openEdit(user_r5));
    });
    i02.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    i02.\u0275\u0275property("text", true)("rounded", true);
  }
}
function Users_ng_template_14_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275elementStart(0, "p-button", 30);
    i02.\u0275\u0275listener("onClick", function Users_ng_template_14_Conditional_15_Template_p_button_onClick_0_listener() {
      i02.\u0275\u0275restoreView(_r6);
      const user_r5 = i02.\u0275\u0275nextContext().$implicit;
      const ctx_r1 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r1.confirmDelete(user_r5));
    });
    i02.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const user_r5 = i02.\u0275\u0275nextContext().$implicit;
    const ctx_r1 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275property("text", true)("rounded", true)("disabled", ctx_r1.deleting() !== null)("loading", ctx_r1.deleting() === user_r5.id);
  }
}
function Users_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275elementStart(0, "tr")(1, "td")(2, "div", 23);
    i02.\u0275\u0275element(3, "i", 24);
    i02.\u0275\u0275elementStart(4, "span");
    i02.\u0275\u0275text(5);
    i02.\u0275\u0275elementEnd()()();
    i02.\u0275\u0275elementStart(6, "td");
    i02.\u0275\u0275text(7);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(8, "td");
    i02.\u0275\u0275text(9);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(10, "td");
    i02.\u0275\u0275element(11, "p-tag", 25);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(12, "td")(13, "div", 26);
    i02.\u0275\u0275conditionalCreate(14, Users_ng_template_14_Conditional_14_Template, 1, 2, "p-button", 27);
    i02.\u0275\u0275conditionalCreate(15, Users_ng_template_14_Conditional_15_Template, 1, 4, "p-button", 28);
    i02.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const user_r5 = ctx.$implicit;
    const ctx_r1 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275textInterpolate(user_r5.name);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(user_r5.email);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(user_r5.role);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("value", user_r5.status)("severity", user_r5.status === "Activo" ? "success" : "danger");
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(ctx_r1.canEdit() ? 14 : -1);
    i02.\u0275\u0275advance();
    i02.\u0275\u0275conditional(ctx_r1.canDelete() ? 15 : -1);
  }
}
function Users_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275elementStart(0, "tr")(1, "td", 31);
    i02.\u0275\u0275text(2, "No se encontraron usuarios.");
    i02.\u0275\u0275elementEnd()();
  }
}
var Users = class _Users {
  // INYECCIÓN DE DEPENDENCIAS
  store = inject2(UserStore);
  messageService = inject2(MessageService);
  confirmationService = inject2(ConfirmationService);
  // Una única fuente de estado: UserStore.
  users = this.store.users;
  filteredUsers = this.store.filteredUsers;
  loading = this.store.loading;
  saving = this.store.saving;
  deleting = this.store.deleting;
  totalUsers = this.store.totalUsers;
  activeUsers = this.store.activeUsers;
  search = this.store.search;
  dialogVisible = this.store.dialogVisible;
  selectedUser = this.store.selectedUser;
  permissions = inject2(PermissionService);
  canCreate = computed2(() => this.permissions.has("users.create"), ...ngDevMode ? [{ debugName: "canCreate" }] : (
    /* istanbul ignore next */
    []
  ));
  canEdit = computed2(() => this.permissions.has("users.edit"), ...ngDevMode ? [{ debugName: "canEdit" }] : (
    /* istanbul ignore next */
    []
  ));
  canDelete = computed2(() => this.permissions.has("users.delete"), ...ngDevMode ? [{ debugName: "canDelete" }] : (
    /* istanbul ignore next */
    []
  ));
  // INICIALIZACIÓN
  ngOnInit() {
    this.loadUsers();
  }
  // OBTENER USUARIOS DESDE LA API
  loadUsers() {
    this.store.loadUsers({
      onError: (error) => this.showError(error, "No se pudieron cargar los usuarios.")
    });
  }
  setSearch(term) {
    this.store.setSearch(term);
  }
  setDialogVisible(visible) {
    this.store.setDialogVisible(visible);
  }
  // ABRIR MODAL NUEVO USUARIO
  openCreate() {
    if (!this.canCreate())
      return;
    this.store.openCreate();
  }
  // ABRIR MODAL EDITAR USUARIO
  openEdit(user) {
    if (!this.canEdit())
      return;
    this.store.openEdit(user);
  }
  // REGISTRAR O ACTUALIZAR USUARIO
  saveUser(data) {
    const currentUser = this.selectedUser();
    const editing = currentUser !== null;
    if (editing && !this.canEdit())
      return;
    if (!editing && !this.canCreate())
      return;
    if (this.saving())
      return;
    const email = data.email.trim().toLowerCase();
    if (this.store.checkEmailExists(email, currentUser?.id)) {
      this.messageService.add({
        severity: "warn",
        summary: "Correo duplicado",
        detail: "Ya existe un usuario con ese correo."
      });
      return;
    }
    this.store.saveUser(data, {
      onSuccess: (isEditing) => {
        this.messageService.add({
          severity: "success",
          summary: isEditing ? "Usuario actualizado" : "Usuario registrado",
          detail: "La operaci\xF3n se realiz\xF3 correctamente."
        });
      },
      onError: (error) => {
        this.showError(error, "No se pudo guardar el usuario.");
      }
    });
  }
  // CONFIRMAR ELIMINACIÓN
  confirmDelete(user) {
    if (!this.canDelete())
      return;
    if (this.deleting() !== null || this.saving())
      return;
    this.confirmationService.confirm({
      header: "Eliminar usuario",
      message: `\xBFDeseas eliminar a ${user.name}?`,
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Eliminar",
      rejectLabel: "Cancelar",
      acceptButtonProps: { severity: "danger" },
      rejectButtonProps: { severity: "secondary", outlined: true },
      accept: () => this.deleteUser(user.id)
    });
  }
  // ELIMINAR USUARIO DESDE LA API
  deleteUser(id) {
    if (!this.canDelete())
      return;
    if (this.deleting() !== null || this.saving())
      return;
    this.store.deleteUser(id, {
      onSuccess: () => {
        this.messageService.add({
          severity: "success",
          summary: "Usuario eliminado",
          detail: "El registro fue eliminado correctamente."
        });
      },
      onError: (error) => this.showError(error, "No se pudo eliminar el usuario.")
    });
  }
  // MANEJO DE ERRORES PARA LA INTERFAZ
  showError(error, fallback) {
    console.error("Error HTTP:", error);
    let detail = fallback;
    if (error.status === 0) {
      detail = "No hay conexi\xF3n con la API. Verifica JSON Server.";
    } else if (error.status === 404) {
      detail = "El registro solicitado ya no existe.";
    } else if (error.status === 409) {
      detail = "Existe un conflicto con los datos enviados.";
    } else if (error.status >= 500) {
      detail = "Error interno del servidor. Int\xE9ntalo nuevamente.";
    }
    this.messageService.add({ severity: "error", summary: "Error", detail });
  }
  static \u0275fac = function Users_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Users)();
  };
  static \u0275cmp = /* @__PURE__ */ i02.\u0275\u0275defineComponent({ type: _Users, selectors: [["app-users"]], features: [i02.\u0275\u0275ProvidersFeature([ConfirmationService, MessageService])], decls: 21, vars: 11, consts: [["caption", ""], ["header", ""], ["body", ""], ["emptymessage", ""], [1, "users-page"], [1, "page-header"], ["data-testid", "new-user-button", "label", "Nuevo usuario", "icon", "pi pi-plus", 3, "disabled"], [1, "table-card"], ["data-testid", "users-table", 3, "value", "loading", "paginator", "rows", "rowsPerPageOptions", "tableStyle"], [3, "visibleChange", "save", "visible", "user"], ["data-testid", "new-user-button", "label", "Nuevo usuario", "icon", "pi pi-plus", 3, "onClick", "disabled"], [1, "table-toolbar"], [1, "search-container"], ["for", "search-users"], ["id", "search-users", "pInputText", "", "type", "search", "placeholder", "Buscar usuario...", 3, "ngModelChange", "ngModel"], ["pSortableColumn", "name"], ["field", "name"], ["pSortableColumn", "email"], ["field", "email"], ["pSortableColumn", "role"], ["field", "role"], ["pSortableColumn", "status"], ["field", "status"], [1, "user-name"], ["aria-hidden", "true", 1, "pi", "pi-user"], [3, "value", "severity"], [1, "actions"], ["icon", "pi pi-pencil", "severity", "info", "data-testid", "edit-user-button", "ariaLabel", "Editar usuario", 3, "text", "rounded"], ["data-testid", "delete-user-button", "icon", "pi pi-trash", "severity", "danger", "ariaLabel", "Eliminar usuario", 3, "text", "rounded", "disabled", "loading"], ["icon", "pi pi-pencil", "severity", "info", "data-testid", "edit-user-button", "ariaLabel", "Editar usuario", 3, "onClick", "text", "rounded"], ["data-testid", "delete-user-button", "icon", "pi pi-trash", "severity", "danger", "ariaLabel", "Eliminar usuario", 3, "onClick", "text", "rounded", "disabled", "loading"], ["colspan", "5", 1, "empty-message"]], template: function Users_Template(rf, ctx) {
    if (rf & 1) {
      i02.\u0275\u0275elementStart(0, "section", 4)(1, "div", 5)(2, "div")(3, "h1");
      i02.\u0275\u0275text(4, "Gesti\xF3n de usuarios");
      i02.\u0275\u0275elementEnd();
      i02.\u0275\u0275elementStart(5, "p");
      i02.\u0275\u0275text(6, "Administra los usuarios registrados en el sistema");
      i02.\u0275\u0275elementEnd()();
      i02.\u0275\u0275conditionalCreate(7, Users_Conditional_7_Template, 1, 1, "p-button", 6);
      i02.\u0275\u0275elementEnd();
      i02.\u0275\u0275elementStart(8, "div", 7)(9, "p-table", 8);
      i02.\u0275\u0275template(10, Users_ng_template_10_Template, 5, 1, "ng-template", null, 0, i02.\u0275\u0275templateRefExtractor)(12, Users_ng_template_12_Template, 15, 0, "ng-template", null, 1, i02.\u0275\u0275templateRefExtractor)(14, Users_ng_template_14_Template, 16, 7, "ng-template", null, 2, i02.\u0275\u0275templateRefExtractor)(16, Users_ng_template_16_Template, 3, 0, "ng-template", null, 3, i02.\u0275\u0275templateRefExtractor);
      i02.\u0275\u0275elementEnd()()();
      i02.\u0275\u0275elementStart(18, "app-user-form", 9);
      i02.\u0275\u0275listener("visibleChange", function Users_Template_app_user_form_visibleChange_18_listener($event) {
        return ctx.setDialogVisible($event);
      })("save", function Users_Template_app_user_form_save_18_listener($event) {
        return ctx.saveUser($event);
      });
      i02.\u0275\u0275elementEnd();
      i02.\u0275\u0275element(19, "p-confirmDialog")(20, "p-toast");
    }
    if (rf & 2) {
      i02.\u0275\u0275advance(7);
      i02.\u0275\u0275conditional(ctx.canCreate() ? 7 : -1);
      i02.\u0275\u0275advance(2);
      i02.\u0275\u0275property("value", ctx.filteredUsers())("loading", ctx.loading())("paginator", true)("rows", 10)("rowsPerPageOptions", i02.\u0275\u0275pureFunction0(9, _c02))("tableStyle", i02.\u0275\u0275pureFunction0(10, _c12));
      i02.\u0275\u0275advance(9);
      i02.\u0275\u0275property("visible", ctx.dialogVisible())("user", ctx.selectedUser());
    }
  }, dependencies: [FormsModule, i12.\u0275NgNoValidate, i12.NgSelectOption, i12.\u0275NgSelectMultipleOption, i12.DefaultValueAccessor, i12.NumberValueAccessor, i12.RangeValueAccessor, i12.CheckboxControlValueAccessor, i12.SelectControlValueAccessor, i12.SelectMultipleControlValueAccessor, i12.RadioControlValueAccessor, i12.NgControlStatus, i12.NgControlStatusGroup, i12.RequiredValidator, i12.MinLengthValidator, i12.MaxLengthValidator, i12.PatternValidator, i12.CheckboxRequiredValidator, i12.EmailValidator, i12.MinValidator, i12.MaxValidator, i12.NgModel, i12.NgModelGroup, i12.NgForm, TableModule, i22.Table, i32.Header, i32.Footer, i32.PrimeTemplate, i22.SortableColumn, i22.FrozenColumn, i22.RowGroupHeader, i22.SelectableRow, i22.RowToggler, i22.ContextMenuRow, i22.ResizableColumn, i22.ReorderableColumn, i22.EditableColumn, i22.CellEditor, i22.SortIcon, i22.TableRadioButton, i22.TableCheckbox, i22.TableHeaderCheckbox, i22.ReorderableRowHandle, i22.ReorderableRow, i22.SelectableRowDblClick, i22.EditableRow, i22.InitEditableRow, i22.SaveEditableRow, i22.CancelEditableRow, i22.ColumnFilter, i22.ColumnFilterFormElement, i42.Scroller, TagModule, i52.Tag, ButtonModule2, i62.ButtonDirective, i62.Button, i62.ButtonLabel, i62.ButtonIcon, InputTextModule2, i7.InputText, ConfirmDialogModule, i8.ConfirmDialog, ToastModule, i9.Toast, UserForm], styles: ["\n.user-form[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 22px;\n  padding: 12px 0;\n}\n.page-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.field[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 9px;\n  min-width: 0;\n}\n.field[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 600;\n  color: #334155;\n}\n.field[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: 100%;\n  min-height: 44px;\n  border-radius: 8px;\n}\n.required[_ngcontent-%COMP%] {\n  color: #dc2626;\n}\n.error[_ngcontent-%COMP%] {\n  color: #dc2626;\n  font-size: 12px;\n  line-height: 1.4;\n}\n.form-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  gap: 16px;\n}\n[_nghost-%COMP%]     .full-control {\n  width: 100%;\n  min-height: 44px;\n}\n.dialog-actions[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: flex-end;\n  gap: 12px;\n  padding-top: 12px;\n}\n@media (max-width: 600px) {\n  .form-grid[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n  .dialog-actions[_ngcontent-%COMP%] {\n    flex-wrap: wrap;\n  }\n}\n.table-toolbar[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 16px;\n  padding: 8px 0;\n}\n.search-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.search-container[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  min-width: 250px;\n}\n.user-name[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.actions[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n@media (max-width: 768px) {\n  .search-container[_ngcontent-%COMP%] {\n    flex-direction: column;\n    align-items: flex-start;\n  }\n  .search-container[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n    min-width: 0;\n    width: 100%;\n  }\n}\n.users-summary[_ngcontent-%COMP%] {\n  display: flex;\n  flex: 1 1 100%;\n  gap: 16px;\n  margin: 24px 0;\n}\n.summary-card[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  padding: 22px;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 14px;\n}\n.summary-card[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #64748b;\n  font-size: 14px;\n}\n.summary-card[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #1e293b;\n  font-size: 30px;\n  font-weight: 700;\n}\n/*# sourceMappingURL=users.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassMetadata(Users, [{
    type: Component2,
    args: [{ selector: "app-users", standalone: true, imports: [
      FormsModule,
      TableModule,
      TagModule,
      ButtonModule2,
      InputTextModule2,
      ConfirmDialogModule,
      ToastModule,
      UserForm
    ], providers: [ConfirmationService, MessageService], template: `<section class="users-page">
  <!-- ENCABEZADO -->
  <div class="page-header">
    <div>
      <h1>Gesti\xF3n de usuarios</h1>
      <p>Administra los usuarios registrados en el sistema</p>
    </div>
    @if (canCreate()) {
      <p-button
        data-testid="new-user-button"
        label="Nuevo usuario"
        icon="pi pi-plus"
        [disabled]="saving() || deleting()"
        (onClick)="openCreate()"
      />
    }
  </div>

  <!-- TABLA -->
  <div class="table-card">
    <p-table
      [value]="filteredUsers()"
      [loading]="loading()"
      [paginator]="true"
      data-testid="users-table"
      [rows]="10"
      [rowsPerPageOptions]="[10, 20, 30]"
      [tableStyle]="{ 'min-width': '750px' }"
    >
      <!-- BUSCADOR -->
      <ng-template #caption>
        <div class="table-toolbar">
          <div class="search-container">
            <label for="search-users">Buscar usuario</label>
            <input
              id="search-users"
              pInputText
              type="search"
              [ngModel]="search()"
              (ngModelChange)="setSearch($event)"
              placeholder="Buscar usuario..."
            />
          </div>
        </div>
      </ng-template>

      <!-- CABECERA -->
      <ng-template #header>
        <tr>
          <th pSortableColumn="name">
            Nombre
            <p-sortIcon field="name" />
          </th>
          <th pSortableColumn="email">
            Correo electr\xF3nico
            <p-sortIcon field="email" />
          </th>
          <th pSortableColumn="role">
            Rol
            <p-sortIcon field="role" />
          </th>
          <th pSortableColumn="status">
            Estado
            <p-sortIcon field="status" />
          </th>
          <th>Acciones</th>
        </tr>
      </ng-template>

      <!-- CONTENIDO -->
      <ng-template #body let-user>
        <tr>
          <td>
            <div class="user-name">
              <i class="pi pi-user" aria-hidden="true"></i>
              <span>{{ user.name }}</span>
            </div>
          </td>
          <td>{{ user.email }}</td>
          <td>{{ user.role }}</td>
          <td>
            <p-tag
              [value]="user.status"
              [severity]="user.status === 'Activo' ? 'success' : 'danger'"
            />
          </td>
          <!-- BOTONES DE ACCIONES -->
          <td>
            <div class="actions">
              @if (canEdit()) {
                <p-button
                  icon="pi pi-pencil"
                  severity="info"
                  [text]="true"
                  [rounded]="true"
                  data-testid="edit-user-button"
                  ariaLabel="Editar usuario"
                  (onClick)="openEdit(user)"
                />
              }
              @if (canDelete()) {
                <p-button
                  data-testid="delete-user-button"
                  icon="pi pi-trash"
                  severity="danger"
                  [text]="true"
                  [rounded]="true"
                  [disabled]="deleting() !== null"
                  [loading]="deleting() === user.id"
                  ariaLabel="Eliminar usuario"
                  (onClick)="confirmDelete(user)"
                />
              }
            </div>
          </td>
        </tr>
      </ng-template>
      <!-- <ng-template #footer>
        <div class="users-summary">
          <div class="summary-card">
            <span>Total de usuarios</span>
            <strong>{{ totalUsers() }}</strong>
          </div>
          <div class="summary-card">
            <span>Usuarios activos</span>
            <strong>{{ activeUsers() }}</strong>
          </div>
        </div>
      </ng-template> -->

      <!-- SIN RESULTADOS -->
      <ng-template #emptymessage>
        <tr>
          <td colspan="5" class="empty-message">No se encontraron usuarios.</td>
        </tr>
      </ng-template>
    </p-table>
  </div>
</section>

<!-- MODAL REGISTRAR / EDITAR -->
<app-user-form
  [visible]="dialogVisible()"
  [user]="selectedUser()"
  (visibleChange)="setDialogVisible($event)"
  (save)="saveUser($event)"
/>

<!-- CONFIRMACI\xD3N PARA ELIMINAR -->
<p-confirmDialog />

<!-- NOTIFICACIONES -->
<p-toast />
`, styles: ["/* src/app/features/users/users.scss */\n.user-form {\n  display: flex;\n  flex-direction: column;\n  gap: 22px;\n  padding: 12px 0;\n}\n.page-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.field {\n  display: flex;\n  flex-direction: column;\n  gap: 9px;\n  min-width: 0;\n}\n.field label {\n  font-size: 14px;\n  font-weight: 600;\n  color: #334155;\n}\n.field input {\n  width: 100%;\n  min-height: 44px;\n  border-radius: 8px;\n}\n.required {\n  color: #dc2626;\n}\n.error {\n  color: #dc2626;\n  font-size: 12px;\n  line-height: 1.4;\n}\n.form-grid {\n  display: grid;\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  gap: 16px;\n}\n:host ::ng-deep .full-control {\n  width: 100%;\n  min-height: 44px;\n}\n.dialog-actions {\n  display: flex;\n  justify-content: flex-end;\n  gap: 12px;\n  padding-top: 12px;\n}\n@media (max-width: 600px) {\n  .form-grid {\n    grid-template-columns: 1fr;\n  }\n  .dialog-actions {\n    flex-wrap: wrap;\n  }\n}\n.table-toolbar {\n  display: flex;\n  align-items: center;\n  gap: 16px;\n  padding: 8px 0;\n}\n.search-container {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.search-container input {\n  min-width: 250px;\n}\n.user-name {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.actions {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n@media (max-width: 768px) {\n  .search-container {\n    flex-direction: column;\n    align-items: flex-start;\n  }\n  .search-container input {\n    min-width: 0;\n    width: 100%;\n  }\n}\n.users-summary {\n  display: flex;\n  flex: 1 1 100%;\n  gap: 16px;\n  margin: 24px 0;\n}\n.summary-card {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  padding: 22px;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 14px;\n}\n.summary-card span {\n  color: #64748b;\n  font-size: 14px;\n}\n.summary-card strong {\n  color: #1e293b;\n  font-size: 30px;\n  font-weight: 700;\n}\n/*# sourceMappingURL=users.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(Users, { className: "Users", filePath: "app/features/users/users.ts", lineNumber: 36 });
})();
(() => {
  const id = "app%2Ffeatures%2Fusers%2Fusers.ts%40Users";
  function Users_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i02.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i02.\u0275\u0275replaceMetadata(Users, m.default, [i02, i12, i22, i32, i42, i52, i62, i7, i8, i9], [ConfirmationService, MessageService, FormsModule, TableModule, TagModule, ButtonModule2, InputTextModule2, ConfirmDialogModule, ToastModule, UserForm, Component2], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Users_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Users_HmrLoad(d.timestamp)));
})();
export {
  Users
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZmVhdHVyZXMvdXNlcnMvdXNlcnMudHMiLCJzcmMvYXBwL2ZlYXR1cmVzL3VzZXJzL3VzZXJzLmh0bWwiLCJzcmMvYXBwL2ZlYXR1cmVzL3VzZXJzL3VzZXItZm9ybS91c2VyLWZvcm0udHMiLCJzcmMvYXBwL2ZlYXR1cmVzL3VzZXJzL3VzZXItZm9ybS91c2VyLWZvcm0uaHRtbCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgaW5qZWN0LCBjb21wdXRlZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcblxuaW1wb3J0IHsgVGFibGVNb2R1bGUgfSBmcm9tICdwcmltZW5nL3RhYmxlJztcbmltcG9ydCB7IFRhZ01vZHVsZSB9IGZyb20gJ3ByaW1lbmcvdGFnJztcbmltcG9ydCB7IEJ1dHRvbk1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvYnV0dG9uJztcbmltcG9ydCB7IElucHV0VGV4dE1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvaW5wdXR0ZXh0JztcbmltcG9ydCB7IENvbmZpcm1EaWFsb2dNb2R1bGUgfSBmcm9tICdwcmltZW5nL2NvbmZpcm1kaWFsb2cnO1xuaW1wb3J0IHsgVG9hc3RNb2R1bGUgfSBmcm9tICdwcmltZW5nL3RvYXN0JztcbmltcG9ydCB7IENvbmZpcm1hdGlvblNlcnZpY2UsIE1lc3NhZ2VTZXJ2aWNlIH0gZnJvbSAncHJpbWVuZy9hcGknO1xuXG5pbXBvcnQgeyBVc2VyRm9ybSB9IGZyb20gJy4vdXNlci1mb3JtL3VzZXItZm9ybSc7XG5pbXBvcnQgeyBVc2VyLCBVc2VyRm9ybVZhbHVlIH0gZnJvbSAnLi91c2VyLm1vZGVsJztcbmltcG9ydCB7IFVzZXJTdG9yZSB9IGZyb20gJy4vc3RvcmUvdXNlci1zdG9yZSc7XG5cbmltcG9ydCB7IFBlcm1pc3Npb25TZXJ2aWNlIH0gZnJvbSAnLi4vLi4vY29yZS9zZXJ2aWNlcy9wZXJtaXNzaW9uJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYXBwLXVzZXJzJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW1xuICAgIEZvcm1zTW9kdWxlLFxuICAgIFRhYmxlTW9kdWxlLFxuICAgIFRhZ01vZHVsZSxcbiAgICBCdXR0b25Nb2R1bGUsXG4gICAgSW5wdXRUZXh0TW9kdWxlLFxuICAgIENvbmZpcm1EaWFsb2dNb2R1bGUsXG4gICAgVG9hc3RNb2R1bGUsXG4gICAgVXNlckZvcm0sXG4gIF0sXG4gIHByb3ZpZGVyczogW0NvbmZpcm1hdGlvblNlcnZpY2UsIE1lc3NhZ2VTZXJ2aWNlXSxcbiAgdGVtcGxhdGVVcmw6ICcuL3VzZXJzLmh0bWwnLFxuICBzdHlsZVVybDogJy4vdXNlcnMuc2NzcycsXG59KVxuZXhwb3J0IGNsYXNzIFVzZXJzIGltcGxlbWVudHMgT25Jbml0IHtcbiAgLy8gSU5ZRUNDScOTTiBERSBERVBFTkRFTkNJQVNcbiAgcmVhZG9ubHkgc3RvcmUgPSBpbmplY3QoVXNlclN0b3JlKTtcbiAgcHJpdmF0ZSByZWFkb25seSBtZXNzYWdlU2VydmljZSA9IGluamVjdChNZXNzYWdlU2VydmljZSk7XG4gIHByaXZhdGUgcmVhZG9ubHkgY29uZmlybWF0aW9uU2VydmljZSA9IGluamVjdChDb25maXJtYXRpb25TZXJ2aWNlKTtcblxuICAvLyBVbmEgw7puaWNhIGZ1ZW50ZSBkZSBlc3RhZG86IFVzZXJTdG9yZS5cbiAgcmVhZG9ubHkgdXNlcnMgPSB0aGlzLnN0b3JlLnVzZXJzO1xuICByZWFkb25seSBmaWx0ZXJlZFVzZXJzID0gdGhpcy5zdG9yZS5maWx0ZXJlZFVzZXJzO1xuICByZWFkb25seSBsb2FkaW5nID0gdGhpcy5zdG9yZS5sb2FkaW5nO1xuICByZWFkb25seSBzYXZpbmcgPSB0aGlzLnN0b3JlLnNhdmluZztcbiAgcmVhZG9ubHkgZGVsZXRpbmcgPSB0aGlzLnN0b3JlLmRlbGV0aW5nO1xuICByZWFkb25seSB0b3RhbFVzZXJzID0gdGhpcy5zdG9yZS50b3RhbFVzZXJzO1xuICByZWFkb25seSBhY3RpdmVVc2VycyA9IHRoaXMuc3RvcmUuYWN0aXZlVXNlcnM7XG4gIHJlYWRvbmx5IHNlYXJjaCA9IHRoaXMuc3RvcmUuc2VhcmNoO1xuICByZWFkb25seSBkaWFsb2dWaXNpYmxlID0gdGhpcy5zdG9yZS5kaWFsb2dWaXNpYmxlO1xuICByZWFkb25seSBzZWxlY3RlZFVzZXIgPSB0aGlzLnN0b3JlLnNlbGVjdGVkVXNlcjtcblxuICByZWFkb25seSBwZXJtaXNzaW9ucyA9IGluamVjdChQZXJtaXNzaW9uU2VydmljZSk7XG4gIHJlYWRvbmx5IGNhbkNyZWF0ZSA9IGNvbXB1dGVkKCgpID0+IHRoaXMucGVybWlzc2lvbnMuaGFzKCd1c2Vycy5jcmVhdGUnKSk7XG4gIHJlYWRvbmx5IGNhbkVkaXQgPSBjb21wdXRlZCgoKSA9PiB0aGlzLnBlcm1pc3Npb25zLmhhcygndXNlcnMuZWRpdCcpKTtcbiAgcmVhZG9ubHkgY2FuRGVsZXRlID0gY29tcHV0ZWQoKCkgPT4gdGhpcy5wZXJtaXNzaW9ucy5oYXMoJ3VzZXJzLmRlbGV0ZScpKTtcblxuICAvLyBJTklDSUFMSVpBQ0nDk05cbiAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy5sb2FkVXNlcnMoKTtcbiAgfVxuXG4gIC8vIE9CVEVORVIgVVNVQVJJT1MgREVTREUgTEEgQVBJXG4gIGxvYWRVc2VycygpOiB2b2lkIHtcbiAgICB0aGlzLnN0b3JlLmxvYWRVc2Vycyh7XG4gICAgICBvbkVycm9yOiAoZXJyb3IpID0+IHRoaXMuc2hvd0Vycm9yKGVycm9yLCAnTm8gc2UgcHVkaWVyb24gY2FyZ2FyIGxvcyB1c3Vhcmlvcy4nKSxcbiAgICB9KTtcbiAgfVxuXG4gIHNldFNlYXJjaCh0ZXJtOiBzdHJpbmcpOiB2b2lkIHtcbiAgICB0aGlzLnN0b3JlLnNldFNlYXJjaCh0ZXJtKTtcbiAgfVxuXG4gIHNldERpYWxvZ1Zpc2libGUodmlzaWJsZTogYm9vbGVhbik6IHZvaWQge1xuICAgIHRoaXMuc3RvcmUuc2V0RGlhbG9nVmlzaWJsZSh2aXNpYmxlKTtcbiAgfVxuXG4gIC8vIEFCUklSIE1PREFMIE5VRVZPIFVTVUFSSU9cbiAgb3BlbkNyZWF0ZSgpOiB2b2lkIHtcbiAgICBpZiAoIXRoaXMuY2FuQ3JlYXRlKCkpIHJldHVybjtcbiAgICB0aGlzLnN0b3JlLm9wZW5DcmVhdGUoKTtcbiAgfVxuXG4gIC8vIEFCUklSIE1PREFMIEVESVRBUiBVU1VBUklPXG4gIG9wZW5FZGl0KHVzZXI6IFVzZXIpOiB2b2lkIHtcbiAgICBpZiAoIXRoaXMuY2FuRWRpdCgpKSByZXR1cm47XG4gICAgdGhpcy5zdG9yZS5vcGVuRWRpdCh1c2VyKTtcbiAgfVxuXG4gIC8vIFJFR0lTVFJBUiBPIEFDVFVBTElaQVIgVVNVQVJJT1xuICBzYXZlVXNlcihkYXRhOiBVc2VyRm9ybVZhbHVlKTogdm9pZCB7XG4gICAgLy8gT2J0ZW5lciBlbCB1c3VhcmlvIHNlbGVjY2lvbmFkbyBkZXNkZSBlbCBTaWduYWxcbiAgICBjb25zdCBjdXJyZW50VXNlciA9IHRoaXMuc2VsZWN0ZWRVc2VyKCk7XG4gICAgY29uc3QgZWRpdGluZyA9IGN1cnJlbnRVc2VyICE9PSBudWxsO1xuXG4gICAgLy8gVmVyaWZpY2FyIHBlcm1pc29zXG4gICAgaWYgKGVkaXRpbmcgJiYgIXRoaXMuY2FuRWRpdCgpKSByZXR1cm47XG4gICAgaWYgKCFlZGl0aW5nICYmICF0aGlzLmNhbkNyZWF0ZSgpKSByZXR1cm47XG5cbiAgICAvLyBFdml0YXIgb3BlcmFjaW9uZXMgc2ltdWx0w6FuZWFzXG4gICAgaWYgKHRoaXMuc2F2aW5nKCkpIHJldHVybjtcblxuICAgIC8vIE5vcm1hbGl6YXIgY29ycmVvXG4gICAgY29uc3QgZW1haWwgPSBkYXRhLmVtYWlsLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuXG4gICAgLy8gVmVyaWZpY2FyIGR1cGxpY2Fkb3NcbiAgICBpZiAodGhpcy5zdG9yZS5jaGVja0VtYWlsRXhpc3RzKGVtYWlsLCBjdXJyZW50VXNlcj8uaWQpKSB7XG4gICAgICB0aGlzLm1lc3NhZ2VTZXJ2aWNlLmFkZCh7XG4gICAgICAgIHNldmVyaXR5OiAnd2FybicsXG4gICAgICAgIHN1bW1hcnk6ICdDb3JyZW8gZHVwbGljYWRvJyxcbiAgICAgICAgZGV0YWlsOiAnWWEgZXhpc3RlIHVuIHVzdWFyaW8gY29uIGVzZSBjb3JyZW8uJyxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIERlbGVnYXIgZ3VhcmRhZG8gYWwgU3RvcmVcbiAgICB0aGlzLnN0b3JlLnNhdmVVc2VyKGRhdGEsIHtcbiAgICAgIG9uU3VjY2VzczogKGlzRWRpdGluZykgPT4ge1xuICAgICAgICB0aGlzLm1lc3NhZ2VTZXJ2aWNlLmFkZCh7XG4gICAgICAgICAgc2V2ZXJpdHk6ICdzdWNjZXNzJyxcbiAgICAgICAgICBzdW1tYXJ5OiBpc0VkaXRpbmcgPyAnVXN1YXJpbyBhY3R1YWxpemFkbycgOiAnVXN1YXJpbyByZWdpc3RyYWRvJyxcbiAgICAgICAgICBkZXRhaWw6ICdMYSBvcGVyYWNpw7NuIHNlIHJlYWxpesOzIGNvcnJlY3RhbWVudGUuJyxcbiAgICAgICAgfSk7XG4gICAgICB9LFxuICAgICAgb25FcnJvcjogKGVycm9yKSA9PiB7XG4gICAgICAgIHRoaXMuc2hvd0Vycm9yKGVycm9yLCAnTm8gc2UgcHVkbyBndWFyZGFyIGVsIHVzdWFyaW8uJyk7XG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgLy8gQ09ORklSTUFSIEVMSU1JTkFDScOTTlxuICBjb25maXJtRGVsZXRlKHVzZXI6IFVzZXIpOiB2b2lkIHtcbiAgICBpZiAoIXRoaXMuY2FuRGVsZXRlKCkpIHJldHVybjtcbiAgICBpZiAodGhpcy5kZWxldGluZygpICE9PSBudWxsIHx8IHRoaXMuc2F2aW5nKCkpIHJldHVybjtcblxuICAgIHRoaXMuY29uZmlybWF0aW9uU2VydmljZS5jb25maXJtKHtcbiAgICAgIGhlYWRlcjogJ0VsaW1pbmFyIHVzdWFyaW8nLFxuICAgICAgbWVzc2FnZTogYMK/RGVzZWFzIGVsaW1pbmFyIGEgJHt1c2VyLm5hbWV9P2AsXG4gICAgICBpY29uOiAncGkgcGktZXhjbGFtYXRpb24tdHJpYW5nbGUnLFxuICAgICAgYWNjZXB0TGFiZWw6ICdFbGltaW5hcicsXG4gICAgICByZWplY3RMYWJlbDogJ0NhbmNlbGFyJyxcbiAgICAgIGFjY2VwdEJ1dHRvblByb3BzOiB7IHNldmVyaXR5OiAnZGFuZ2VyJyB9LFxuICAgICAgcmVqZWN0QnV0dG9uUHJvcHM6IHsgc2V2ZXJpdHk6ICdzZWNvbmRhcnknLCBvdXRsaW5lZDogdHJ1ZSB9LFxuICAgICAgYWNjZXB0OiAoKSA9PiB0aGlzLmRlbGV0ZVVzZXIodXNlci5pZCksXG4gICAgfSk7XG4gIH1cblxuICAvLyBFTElNSU5BUiBVU1VBUklPIERFU0RFIExBIEFQSVxuICBwcml2YXRlIGRlbGV0ZVVzZXIoaWQ6IHN0cmluZyk6IHZvaWQge1xuICAgIGlmICghdGhpcy5jYW5EZWxldGUoKSkgcmV0dXJuO1xuICAgIGlmICh0aGlzLmRlbGV0aW5nKCkgIT09IG51bGwgfHwgdGhpcy5zYXZpbmcoKSkgcmV0dXJuO1xuXG4gICAgdGhpcy5zdG9yZS5kZWxldGVVc2VyKGlkLCB7XG4gICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcbiAgICAgICAgdGhpcy5tZXNzYWdlU2VydmljZS5hZGQoe1xuICAgICAgICAgIHNldmVyaXR5OiAnc3VjY2VzcycsXG4gICAgICAgICAgc3VtbWFyeTogJ1VzdWFyaW8gZWxpbWluYWRvJyxcbiAgICAgICAgICBkZXRhaWw6ICdFbCByZWdpc3RybyBmdWUgZWxpbWluYWRvIGNvcnJlY3RhbWVudGUuJyxcbiAgICAgICAgfSk7XG4gICAgICB9LFxuICAgICAgb25FcnJvcjogKGVycm9yKSA9PiB0aGlzLnNob3dFcnJvcihlcnJvciwgJ05vIHNlIHB1ZG8gZWxpbWluYXIgZWwgdXN1YXJpby4nKSxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIE1BTkVKTyBERSBFUlJPUkVTIFBBUkEgTEEgSU5URVJGQVpcbiAgcHJpdmF0ZSBzaG93RXJyb3IoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlLCBmYWxsYmFjazogc3RyaW5nKTogdm9pZCB7XG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgSFRUUDonLCBlcnJvcik7XG4gICAgbGV0IGRldGFpbCA9IGZhbGxiYWNrO1xuICAgIGlmIChlcnJvci5zdGF0dXMgPT09IDApIHtcbiAgICAgIGRldGFpbCA9ICdObyBoYXkgY29uZXhpw7NuIGNvbiBsYSBBUEkuIFZlcmlmaWNhIEpTT04gU2VydmVyLic7XG4gICAgfSBlbHNlIGlmIChlcnJvci5zdGF0dXMgPT09IDQwNCkge1xuICAgICAgZGV0YWlsID0gJ0VsIHJlZ2lzdHJvIHNvbGljaXRhZG8geWEgbm8gZXhpc3RlLic7XG4gICAgfSBlbHNlIGlmIChlcnJvci5zdGF0dXMgPT09IDQwOSkge1xuICAgICAgZGV0YWlsID0gJ0V4aXN0ZSB1biBjb25mbGljdG8gY29uIGxvcyBkYXRvcyBlbnZpYWRvcy4nO1xuICAgIH0gZWxzZSBpZiAoZXJyb3Iuc3RhdHVzID49IDUwMCkge1xuICAgICAgZGV0YWlsID0gJ0Vycm9yIGludGVybm8gZGVsIHNlcnZpZG9yLiBJbnTDqW50YWxvIG51ZXZhbWVudGUuJztcbiAgICB9XG4gICAgdGhpcy5tZXNzYWdlU2VydmljZS5hZGQoeyBzZXZlcml0eTogJ2Vycm9yJywgc3VtbWFyeTogJ0Vycm9yJywgZGV0YWlsIH0pO1xuICB9XG59XG4iLCI8c2VjdGlvbiBjbGFzcz1cInVzZXJzLXBhZ2VcIj5cbiAgPCEtLSBFTkNBQkVaQURPIC0tPlxuICA8ZGl2IGNsYXNzPVwicGFnZS1oZWFkZXJcIj5cbiAgICA8ZGl2PlxuICAgICAgPGgxPkdlc3Rpw7NuIGRlIHVzdWFyaW9zPC9oMT5cbiAgICAgIDxwPkFkbWluaXN0cmEgbG9zIHVzdWFyaW9zIHJlZ2lzdHJhZG9zIGVuIGVsIHNpc3RlbWE8L3A+XG4gICAgPC9kaXY+XG4gICAgQGlmIChjYW5DcmVhdGUoKSkge1xuICAgICAgPHAtYnV0dG9uXG4gICAgICAgIGRhdGEtdGVzdGlkPVwibmV3LXVzZXItYnV0dG9uXCJcbiAgICAgICAgbGFiZWw9XCJOdWV2byB1c3VhcmlvXCJcbiAgICAgICAgaWNvbj1cInBpIHBpLXBsdXNcIlxuICAgICAgICBbZGlzYWJsZWRdPVwic2F2aW5nKCkgfHwgZGVsZXRpbmcoKVwiXG4gICAgICAgIChvbkNsaWNrKT1cIm9wZW5DcmVhdGUoKVwiXG4gICAgICAvPlxuICAgIH1cbiAgPC9kaXY+XG5cbiAgPCEtLSBUQUJMQSAtLT5cbiAgPGRpdiBjbGFzcz1cInRhYmxlLWNhcmRcIj5cbiAgICA8cC10YWJsZVxuICAgICAgW3ZhbHVlXT1cImZpbHRlcmVkVXNlcnMoKVwiXG4gICAgICBbbG9hZGluZ109XCJsb2FkaW5nKClcIlxuICAgICAgW3BhZ2luYXRvcl09XCJ0cnVlXCJcbiAgICAgIGRhdGEtdGVzdGlkPVwidXNlcnMtdGFibGVcIlxuICAgICAgW3Jvd3NdPVwiMTBcIlxuICAgICAgW3Jvd3NQZXJQYWdlT3B0aW9uc109XCJbMTAsIDIwLCAzMF1cIlxuICAgICAgW3RhYmxlU3R5bGVdPVwieyAnbWluLXdpZHRoJzogJzc1MHB4JyB9XCJcbiAgICA+XG4gICAgICA8IS0tIEJVU0NBRE9SIC0tPlxuICAgICAgPG5nLXRlbXBsYXRlICNjYXB0aW9uPlxuICAgICAgICA8ZGl2IGNsYXNzPVwidGFibGUtdG9vbGJhclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2gtY29udGFpbmVyXCI+XG4gICAgICAgICAgICA8bGFiZWwgZm9yPVwic2VhcmNoLXVzZXJzXCI+QnVzY2FyIHVzdWFyaW88L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIGlkPVwic2VhcmNoLXVzZXJzXCJcbiAgICAgICAgICAgICAgcElucHV0VGV4dFxuICAgICAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcbiAgICAgICAgICAgICAgW25nTW9kZWxdPVwic2VhcmNoKClcIlxuICAgICAgICAgICAgICAobmdNb2RlbENoYW5nZSk9XCJzZXRTZWFyY2goJGV2ZW50KVwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQnVzY2FyIHVzdWFyaW8uLi5cIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L25nLXRlbXBsYXRlPlxuXG4gICAgICA8IS0tIENBQkVDRVJBIC0tPlxuICAgICAgPG5nLXRlbXBsYXRlICNoZWFkZXI+XG4gICAgICAgIDx0cj5cbiAgICAgICAgICA8dGggcFNvcnRhYmxlQ29sdW1uPVwibmFtZVwiPlxuICAgICAgICAgICAgTm9tYnJlXG4gICAgICAgICAgICA8cC1zb3J0SWNvbiBmaWVsZD1cIm5hbWVcIiAvPlxuICAgICAgICAgIDwvdGg+XG4gICAgICAgICAgPHRoIHBTb3J0YWJsZUNvbHVtbj1cImVtYWlsXCI+XG4gICAgICAgICAgICBDb3JyZW8gZWxlY3Ryw7NuaWNvXG4gICAgICAgICAgICA8cC1zb3J0SWNvbiBmaWVsZD1cImVtYWlsXCIgLz5cbiAgICAgICAgICA8L3RoPlxuICAgICAgICAgIDx0aCBwU29ydGFibGVDb2x1bW49XCJyb2xlXCI+XG4gICAgICAgICAgICBSb2xcbiAgICAgICAgICAgIDxwLXNvcnRJY29uIGZpZWxkPVwicm9sZVwiIC8+XG4gICAgICAgICAgPC90aD5cbiAgICAgICAgICA8dGggcFNvcnRhYmxlQ29sdW1uPVwic3RhdHVzXCI+XG4gICAgICAgICAgICBFc3RhZG9cbiAgICAgICAgICAgIDxwLXNvcnRJY29uIGZpZWxkPVwic3RhdHVzXCIgLz5cbiAgICAgICAgICA8L3RoPlxuICAgICAgICAgIDx0aD5BY2Npb25lczwvdGg+XG4gICAgICAgIDwvdHI+XG4gICAgICA8L25nLXRlbXBsYXRlPlxuXG4gICAgICA8IS0tIENPTlRFTklETyAtLT5cbiAgICAgIDxuZy10ZW1wbGF0ZSAjYm9keSBsZXQtdXNlcj5cbiAgICAgICAgPHRyPlxuICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ1c2VyLW5hbWVcIj5cbiAgICAgICAgICAgICAgPGkgY2xhc3M9XCJwaSBwaS11c2VyXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9pPlxuICAgICAgICAgICAgICA8c3Bhbj57eyB1c2VyLm5hbWUgfX08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L3RkPlxuICAgICAgICAgIDx0ZD57eyB1c2VyLmVtYWlsIH19PC90ZD5cbiAgICAgICAgICA8dGQ+e3sgdXNlci5yb2xlIH19PC90ZD5cbiAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICA8cC10YWdcbiAgICAgICAgICAgICAgW3ZhbHVlXT1cInVzZXIuc3RhdHVzXCJcbiAgICAgICAgICAgICAgW3NldmVyaXR5XT1cInVzZXIuc3RhdHVzID09PSAnQWN0aXZvJyA/ICdzdWNjZXNzJyA6ICdkYW5nZXInXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8IS0tIEJPVE9ORVMgREUgQUNDSU9ORVMgLS0+XG4gICAgICAgICAgPHRkPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFjdGlvbnNcIj5cbiAgICAgICAgICAgICAgQGlmIChjYW5FZGl0KCkpIHtcbiAgICAgICAgICAgICAgICA8cC1idXR0b25cbiAgICAgICAgICAgICAgICAgIGljb249XCJwaSBwaS1wZW5jaWxcIlxuICAgICAgICAgICAgICAgICAgc2V2ZXJpdHk9XCJpbmZvXCJcbiAgICAgICAgICAgICAgICAgIFt0ZXh0XT1cInRydWVcIlxuICAgICAgICAgICAgICAgICAgW3JvdW5kZWRdPVwidHJ1ZVwiXG4gICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImVkaXQtdXNlci1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgYXJpYUxhYmVsPVwiRWRpdGFyIHVzdWFyaW9cIlxuICAgICAgICAgICAgICAgICAgKG9uQ2xpY2spPVwib3BlbkVkaXQodXNlcilcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgQGlmIChjYW5EZWxldGUoKSkge1xuICAgICAgICAgICAgICAgIDxwLWJ1dHRvblxuICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJkZWxldGUtdXNlci1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgaWNvbj1cInBpIHBpLXRyYXNoXCJcbiAgICAgICAgICAgICAgICAgIHNldmVyaXR5PVwiZGFuZ2VyXCJcbiAgICAgICAgICAgICAgICAgIFt0ZXh0XT1cInRydWVcIlxuICAgICAgICAgICAgICAgICAgW3JvdW5kZWRdPVwidHJ1ZVwiXG4gICAgICAgICAgICAgICAgICBbZGlzYWJsZWRdPVwiZGVsZXRpbmcoKSAhPT0gbnVsbFwiXG4gICAgICAgICAgICAgICAgICBbbG9hZGluZ109XCJkZWxldGluZygpID09PSB1c2VyLmlkXCJcbiAgICAgICAgICAgICAgICAgIGFyaWFMYWJlbD1cIkVsaW1pbmFyIHVzdWFyaW9cIlxuICAgICAgICAgICAgICAgICAgKG9uQ2xpY2spPVwiY29uZmlybURlbGV0ZSh1c2VyKVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgPC90cj5cbiAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICA8IS0tIDxuZy10ZW1wbGF0ZSAjZm9vdGVyPlxuICAgICAgICA8ZGl2IGNsYXNzPVwidXNlcnMtc3VtbWFyeVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdW1tYXJ5LWNhcmRcIj5cbiAgICAgICAgICAgIDxzcGFuPlRvdGFsIGRlIHVzdWFyaW9zPC9zcGFuPlxuICAgICAgICAgICAgPHN0cm9uZz57eyB0b3RhbFVzZXJzKCkgfX08L3N0cm9uZz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwic3VtbWFyeS1jYXJkXCI+XG4gICAgICAgICAgICA8c3Bhbj5Vc3VhcmlvcyBhY3Rpdm9zPC9zcGFuPlxuICAgICAgICAgICAgPHN0cm9uZz57eyBhY3RpdmVVc2VycygpIH19PC9zdHJvbmc+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9uZy10ZW1wbGF0ZT4gLS0+XG5cbiAgICAgIDwhLS0gU0lOIFJFU1VMVEFET1MgLS0+XG4gICAgICA8bmctdGVtcGxhdGUgI2VtcHR5bWVzc2FnZT5cbiAgICAgICAgPHRyPlxuICAgICAgICAgIDx0ZCBjb2xzcGFuPVwiNVwiIGNsYXNzPVwiZW1wdHktbWVzc2FnZVwiPk5vIHNlIGVuY29udHJhcm9uIHVzdWFyaW9zLjwvdGQ+XG4gICAgICAgIDwvdHI+XG4gICAgICA8L25nLXRlbXBsYXRlPlxuICAgIDwvcC10YWJsZT5cbiAgPC9kaXY+XG48L3NlY3Rpb24+XG5cbjwhLS0gTU9EQUwgUkVHSVNUUkFSIC8gRURJVEFSIC0tPlxuPGFwcC11c2VyLWZvcm1cbiAgW3Zpc2libGVdPVwiZGlhbG9nVmlzaWJsZSgpXCJcbiAgW3VzZXJdPVwic2VsZWN0ZWRVc2VyKClcIlxuICAodmlzaWJsZUNoYW5nZSk9XCJzZXREaWFsb2dWaXNpYmxlKCRldmVudClcIlxuICAoc2F2ZSk9XCJzYXZlVXNlcigkZXZlbnQpXCJcbi8+XG5cbjwhLS0gQ09ORklSTUFDScOTTiBQQVJBIEVMSU1JTkFSIC0tPlxuPHAtY29uZmlybURpYWxvZyAvPlxuXG48IS0tIE5PVElGSUNBQ0lPTkVTIC0tPlxuPHAtdG9hc3QgLz5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgaW5wdXQsIG91dHB1dCwgY29tcHV0ZWQsIGVmZmVjdCwgdW50cmFja2VkLCBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZvcm1CdWlsZGVyLCBSZWFjdGl2ZUZvcm1zTW9kdWxlLCBWYWxpZGF0b3JzIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgRGlhbG9nTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9kaWFsb2cnO1xuaW1wb3J0IHsgSW5wdXRUZXh0TW9kdWxlIH0gZnJvbSAncHJpbWVuZy9pbnB1dHRleHQnO1xuaW1wb3J0IHsgU2VsZWN0TW9kdWxlIH0gZnJvbSAncHJpbWVuZy9zZWxlY3QnO1xuaW1wb3J0IHsgQnV0dG9uTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9idXR0b24nO1xuaW1wb3J0IHsgVXNlciwgVXNlckZvcm1WYWx1ZSwgVXNlclJvbGUsIFVzZXJTdGF0dXMgfSBmcm9tICcuLi91c2VyLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYXBwLXVzZXItZm9ybScsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtSZWFjdGl2ZUZvcm1zTW9kdWxlLCBEaWFsb2dNb2R1bGUsIElucHV0VGV4dE1vZHVsZSwgU2VsZWN0TW9kdWxlLCBCdXR0b25Nb2R1bGVdLFxuICB0ZW1wbGF0ZVVybDogJy4vdXNlci1mb3JtLmh0bWwnLFxuICBzdHlsZVVybDogJy4vdXNlci1mb3JtLnNjc3MnLFxufSlcbmV4cG9ydCBjbGFzcyBVc2VyRm9ybSB7XG4gIHByaXZhdGUgcmVhZG9ubHkgZmIgPSBpbmplY3QoRm9ybUJ1aWxkZXIpO1xuXG4gIC8vIElucHV0cyBtb2Rlcm5vcyBjb24gU2lnbmFsc1xuICByZWFkb25seSB2aXNpYmxlID0gaW5wdXQoZmFsc2UpO1xuICByZWFkb25seSB1c2VyID0gaW5wdXQ8VXNlciB8IG51bGw+KG51bGwpO1xuXG4gIC8vIE91dHB1dHMgbW9kZXJub3NcbiAgcmVhZG9ubHkgdmlzaWJsZUNoYW5nZSA9IG91dHB1dDxib29sZWFuPigpO1xuICByZWFkb25seSBzYXZlID0gb3V0cHV0PFVzZXJGb3JtVmFsdWU+KCk7XG5cbiAgLy8gT3BjaW9uZXMgZGUgbG9zIHNlbGVjdG9yZXNcbiAgcmVhZG9ubHkgcm9sZXMgPSBbXG4gICAgeyBsYWJlbDogJ0FkbWluaXN0cmFkb3InLCB2YWx1ZTogJ0FkbWluaXN0cmFkb3InIH0sXG4gICAgeyBsYWJlbDogJ0VkaXRvcicsIHZhbHVlOiAnRWRpdG9yJyB9LFxuICAgIHsgbGFiZWw6ICdVc3VhcmlvJywgdmFsdWU6ICdVc3VhcmlvJyB9LFxuICBdO1xuXG4gIHJlYWRvbmx5IHN0YXR1c2VzID0gW1xuICAgIHsgbGFiZWw6ICdBY3Rpdm8nLCB2YWx1ZTogJ0FjdGl2bycgfSxcbiAgICB7IGxhYmVsOiAnSW5hY3Rpdm8nLCB2YWx1ZTogJ0luYWN0aXZvJyB9LFxuICBdO1xuXG4gIC8vIEZvcm11bGFyaW8gcmVhY3Rpdm9cbiAgcmVhZG9ubHkgZm9ybSA9IHRoaXMuZmIubm9uTnVsbGFibGUuZ3JvdXAoe1xuICAgIG5hbWU6IFsnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRvcnMubWluTGVuZ3RoKDMpLCBWYWxpZGF0b3JzLm1heExlbmd0aCgxMDApXV0sXG4gICAgZW1haWw6IFsnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRvcnMuZW1haWxdXSxcbiAgICByb2xlOiB0aGlzLmZiLm5vbk51bGxhYmxlLmNvbnRyb2w8VXNlclJvbGU+KCdVc3VhcmlvJywgVmFsaWRhdG9ycy5yZXF1aXJlZCksXG4gICAgc3RhdHVzOiB0aGlzLmZiLm5vbk51bGxhYmxlLmNvbnRyb2w8VXNlclN0YXR1cz4oJ0FjdGl2bycsIFZhbGlkYXRvcnMucmVxdWlyZWQpLFxuICB9KTtcblxuICAvLyBEZXRlY3RhciBzaSBlc3RhbW9zIGVkaXRhbmRvXG4gIHJlYWRvbmx5IGlzRWRpdGluZyA9IGNvbXB1dGVkKCgpID0+IHRoaXMudXNlcigpICE9PSBudWxsKTtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgbGV0IHByZXZpb3VzVmlzaWJsZSA9IGZhbHNlO1xuICAgIGxldCBwcmV2aW91c1VzZXJJZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG5cbiAgICBlZmZlY3QoKCkgPT4ge1xuICAgICAgY29uc3QgaXNWaXNpYmxlID0gdGhpcy52aXNpYmxlKCk7XG4gICAgICBjb25zdCBjdXJyZW50VXNlciA9IHRoaXMudXNlcigpO1xuICAgICAgY29uc3QgY3VycmVudFVzZXJJZCA9IGN1cnJlbnRVc2VyPy5pZCA/PyBudWxsO1xuXG4gICAgICAvLyBEZXRlY3RhciB0cmFuc2ljacOzbiBkZSBhcGVydHVyYSBvIGNhbWJpbyByZWFsIGRlIHJlZ2lzdHJvIG1pZW50cmFzIGVzdMOhIGFiaWVydG9cbiAgICAgIGNvbnN0IGp1c3RPcGVuZWQgPSBpc1Zpc2libGUgJiYgIXByZXZpb3VzVmlzaWJsZTtcbiAgICAgIGNvbnN0IHVzZXJDaGFuZ2VkID0gaXNWaXNpYmxlICYmIGN1cnJlbnRVc2VySWQgIT09IHByZXZpb3VzVXNlcklkO1xuXG4gICAgICAvLyBBY3R1YWxpemFyIGVzdGFkbyBwcmV2aW9cbiAgICAgIHByZXZpb3VzVmlzaWJsZSA9IGlzVmlzaWJsZTtcbiAgICAgIHByZXZpb3VzVXNlcklkID0gaXNWaXNpYmxlID8gY3VycmVudFVzZXJJZCA6IG51bGw7IC8vIFJlc2V0IGFsIGNlcnJhciBwYXJhIGdhcmFudGl6YXIgY2FyZ2EgbGltcGlhIGVuIHJlYXBlcnR1cmFzXG5cbiAgICAgIGlmIChqdXN0T3BlbmVkIHx8IHVzZXJDaGFuZ2VkKSB7XG4gICAgICAgIHVudHJhY2tlZCgoKSA9PiB0aGlzLmxvYWRGb3JtKGN1cnJlbnRVc2VyKSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvLyBDYXJnYXIgZGF0b3MgcGFyYSBjcmVhciBvIGVkaXRhclxuICBsb2FkRm9ybSh1c2VyOiBVc2VyIHwgbnVsbCk6IHZvaWQge1xuICAgIHRoaXMuZm9ybS5yZXNldCh7XG4gICAgICBuYW1lOiB1c2VyPy5uYW1lID8/ICcnLFxuICAgICAgZW1haWw6IHVzZXI/LmVtYWlsID8/ICcnLFxuICAgICAgcm9sZTogdXNlcj8ucm9sZSA/PyAnVXN1YXJpbycsXG4gICAgICBzdGF0dXM6IHVzZXI/LnN0YXR1cyA/PyAnQWN0aXZvJyxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIFZhbGlkYXIgeSBlbWl0aXIgbG9zIGRhdG9zXG4gIHN1Ym1pdCgpOiB2b2lkIHtcbiAgICB0aGlzLmZvcm0ubWFya0FsbEFzVG91Y2hlZCgpO1xuXG4gICAgaWYgKHRoaXMuZm9ybS5pbnZhbGlkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgdmFsdWUgPSB0aGlzLmZvcm0uZ2V0UmF3VmFsdWUoKTtcblxuICAgIHRoaXMuc2F2ZS5lbWl0KHtcbiAgICAgIG5hbWU6IHZhbHVlLm5hbWUudHJpbSgpLFxuICAgICAgZW1haWw6IHZhbHVlLmVtYWlsLnRyaW0oKSxcbiAgICAgIHJvbGU6IHZhbHVlLnJvbGUsXG4gICAgICBzdGF0dXM6IHZhbHVlLnN0YXR1cyxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIFNvbGljaXRhciBlbCBjaWVycmUgZGVsIG1vZGFsXG4gIGNsb3NlKCk6IHZvaWQge1xuICAgIHRoaXMudmlzaWJsZUNoYW5nZS5lbWl0KGZhbHNlKTtcbiAgfVxufVxuIiwiPHAtZGlhbG9nXG4gIFtoZWFkZXJdPVwiaXNFZGl0aW5nKCkgPyAnRWRpdGFyIHVzdWFyaW8nIDogJ051ZXZvIHVzdWFyaW8nXCJcbiAgW3Zpc2libGVdPVwidmlzaWJsZSgpXCJcbiAgKHZpc2libGVDaGFuZ2UpPVwidmlzaWJsZUNoYW5nZS5lbWl0KCRldmVudClcIlxuICBbbW9kYWxdPVwidHJ1ZVwiXG4gIFtkcmFnZ2FibGVdPVwiZmFsc2VcIlxuICBbcmVzaXphYmxlXT1cImZhbHNlXCJcbiAgW2Nsb3NhYmxlXT1cInRydWVcIlxuICBbZGlzbWlzc2FibGVNYXNrXT1cImZhbHNlXCJcbiAgW3N0eWxlXT1cInsgd2lkdGg6ICc1NTBweCcsIG1heFdpZHRoOiAnOTV2dycgfVwiXG4gIFticmVha3BvaW50c109XCJ7ICc2NDBweCc6ICc5NXZ3JyB9XCJcbj5cbiAgPGZvcm1cbiAgICBpZD1cInVzZXJGb3JtXCJcbiAgICBkYXRhLXRlc3RpZD1cInVzZXItZm9ybVwiXG4gICAgW2Zvcm1Hcm91cF09XCJmb3JtXCJcbiAgICAobmdTdWJtaXQpPVwic3VibWl0KClcIlxuICAgIGNsYXNzPVwidXNlci1mb3JtXCJcbiAgPlxuICAgIDwhLS0gTk9NQlJFIC0tPlxuICAgIDxkaXYgY2xhc3M9XCJmaWVsZFwiPlxuICAgICAgPGxhYmVsIGZvcj1cIm5hbWVcIj4gTm9tYnJlIGNvbXBsZXRvIDxzcGFuIGNsYXNzPVwicmVxdWlyZWRcIj4qPC9zcGFuPiA8L2xhYmVsPlxuXG4gICAgICA8aW5wdXRcbiAgICAgICAgaWQ9XCJuYW1lXCJcbiAgICAgICAgcElucHV0VGV4dFxuICAgICAgICBkYXRhLXRlc3RpZD1cInVzZXItbmFtZVwiXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwibmFtZVwiXG4gICAgICAgIHBsYWNlaG9sZGVyPVwiSW5ncmVzYSBlbCBub21icmUgY29tcGxldG9cIlxuICAgICAgICBhcmlhLXJlcXVpcmVkPVwidHJ1ZVwiXG4gICAgICAgIFtjbGFzcy5uZy1pbnZhbGlkXT1cImZvcm0uY29udHJvbHMubmFtZS50b3VjaGVkICYmIGZvcm0uY29udHJvbHMubmFtZS5pbnZhbGlkXCJcbiAgICAgICAgW2F0dHIuYXJpYS1pbnZhbGlkXT1cImZvcm0uY29udHJvbHMubmFtZS50b3VjaGVkICYmIGZvcm0uY29udHJvbHMubmFtZS5pbnZhbGlkXCJcbiAgICAgICAgW2F0dHIuYXJpYS1kZXNjcmliZWRieV09XCJcbiAgICAgICAgICBmb3JtLmNvbnRyb2xzLm5hbWUudG91Y2hlZCAmJiBmb3JtLmNvbnRyb2xzLm5hbWUuaW52YWxpZCA/ICduYW1lLWVycm9yJyA6IG51bGxcbiAgICAgICAgXCJcbiAgICAgIC8+XG5cbiAgICAgIEBpZiAoZm9ybS5jb250cm9scy5uYW1lLnRvdWNoZWQgJiYgZm9ybS5jb250cm9scy5uYW1lLmhhc0Vycm9yKCdyZXF1aXJlZCcpKSB7XG4gICAgICAgIDxzbWFsbCBpZD1cIm5hbWUtZXJyb3JcIiBjbGFzcz1cImVycm9yXCI+IEVsIG5vbWJyZSBlcyBvYmxpZ2F0b3Jpby4gPC9zbWFsbD5cbiAgICAgIH0gQGVsc2UgaWYgKGZvcm0uY29udHJvbHMubmFtZS50b3VjaGVkICYmIGZvcm0uY29udHJvbHMubmFtZS5oYXNFcnJvcignbWlubGVuZ3RoJykpIHtcbiAgICAgICAgPHNtYWxsIGlkPVwibmFtZS1lcnJvclwiIGNsYXNzPVwiZXJyb3JcIj4gRWwgbm9tYnJlIGRlYmUgdGVuZXIgYWwgbWVub3MgMyBjYXJhY3RlcmVzLiA8L3NtYWxsPlxuICAgICAgfSBAZWxzZSBpZiAoZm9ybS5jb250cm9scy5uYW1lLnRvdWNoZWQgJiYgZm9ybS5jb250cm9scy5uYW1lLmhhc0Vycm9yKCdtYXhsZW5ndGgnKSkge1xuICAgICAgICA8c21hbGwgaWQ9XCJuYW1lLWVycm9yXCIgY2xhc3M9XCJlcnJvclwiPiBFbCBub21icmUgbm8gZGViZSBzdXBlcmFyIGxvcyAxMDAgY2FyYWN0ZXJlcy4gPC9zbWFsbD5cbiAgICAgIH1cbiAgICA8L2Rpdj5cblxuICAgIDwhLS0gQ09SUkVPIC0tPlxuICAgIDxkaXYgY2xhc3M9XCJmaWVsZFwiPlxuICAgICAgPGxhYmVsIGZvcj1cImVtYWlsXCI+IENvcnJlbyBlbGVjdHLDs25pY28gPHNwYW4gY2xhc3M9XCJyZXF1aXJlZFwiPio8L3NwYW4+IDwvbGFiZWw+XG5cbiAgICAgIDxpbnB1dFxuICAgICAgICBpZD1cImVtYWlsXCJcbiAgICAgICAgcElucHV0VGV4dFxuICAgICAgICBkYXRhLXRlc3RpZD1cInVzZXItZW1haWxcIlxuICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJlbWFpbFwiXG4gICAgICAgIHBsYWNlaG9sZGVyPVwiZWplbXBsb0BlbXByZXNhLmNvbVwiXG4gICAgICAgIGFyaWEtcmVxdWlyZWQ9XCJ0cnVlXCJcbiAgICAgICAgW2NsYXNzLm5nLWludmFsaWRdPVwiZm9ybS5jb250cm9scy5lbWFpbC50b3VjaGVkICYmIGZvcm0uY29udHJvbHMuZW1haWwuaW52YWxpZFwiXG4gICAgICAgIFthdHRyLmFyaWEtaW52YWxpZF09XCJmb3JtLmNvbnRyb2xzLmVtYWlsLnRvdWNoZWQgJiYgZm9ybS5jb250cm9scy5lbWFpbC5pbnZhbGlkXCJcbiAgICAgICAgW2F0dHIuYXJpYS1kZXNjcmliZWRieV09XCJcbiAgICAgICAgICBmb3JtLmNvbnRyb2xzLmVtYWlsLnRvdWNoZWQgJiYgZm9ybS5jb250cm9scy5lbWFpbC5pbnZhbGlkID8gJ2VtYWlsLWVycm9yJyA6IG51bGxcbiAgICAgICAgXCJcbiAgICAgIC8+XG5cbiAgICAgIEBpZiAoZm9ybS5jb250cm9scy5lbWFpbC50b3VjaGVkICYmIGZvcm0uY29udHJvbHMuZW1haWwuaGFzRXJyb3IoJ3JlcXVpcmVkJykpIHtcbiAgICAgICAgPHNtYWxsIGlkPVwiZW1haWwtZXJyb3JcIiBjbGFzcz1cImVycm9yXCI+IEVsIGNvcnJlbyBlcyBvYmxpZ2F0b3Jpby4gPC9zbWFsbD5cbiAgICAgIH0gQGVsc2UgaWYgKGZvcm0uY29udHJvbHMuZW1haWwudG91Y2hlZCAmJiBmb3JtLmNvbnRyb2xzLmVtYWlsLmhhc0Vycm9yKCdlbWFpbCcpKSB7XG4gICAgICAgIDxzbWFsbCBpZD1cImVtYWlsLWVycm9yXCIgY2xhc3M9XCJlcnJvclwiPiBJbmdyZXNhIHVuIGNvcnJlbyBlbGVjdHLDs25pY28gdsOhbGlkby4gPC9zbWFsbD5cbiAgICAgIH1cbiAgICA8L2Rpdj5cblxuICAgIDwhLS0gUk9MIFkgRVNUQURPIC0tPlxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyaWRcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJmaWVsZFwiPlxuICAgICAgICA8bGFiZWwgZm9yPVwicm9sZVwiPiBSb2wgPHNwYW4gY2xhc3M9XCJyZXF1aXJlZFwiPio8L3NwYW4+IDwvbGFiZWw+XG5cbiAgICAgICAgPHAtc2VsZWN0XG4gICAgICAgICAgaW5wdXRJZD1cInJvbGVcIlxuICAgICAgICAgIFtvcHRpb25zXT1cInJvbGVzXCJcbiAgICAgICAgICBvcHRpb25MYWJlbD1cImxhYmVsXCJcbiAgICAgICAgICBvcHRpb25WYWx1ZT1cInZhbHVlXCJcbiAgICAgICAgICBkYXRhLXRlc3RpZD1cInVzZXItcm9sZVwiXG4gICAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwicm9sZVwiXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY2Npb25hciByb2xcIlxuICAgICAgICAgIGFyaWEtcmVxdWlyZWQ9XCJ0cnVlXCJcbiAgICAgICAgICBhcHBlbmRUbz1cImJvZHlcIlxuICAgICAgICAgIHN0eWxlQ2xhc3M9XCJmdWxsLWNvbnRyb2xcIlxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3M9XCJmaWVsZFwiPlxuICAgICAgICA8bGFiZWwgZm9yPVwic3RhdHVzXCI+IEVzdGFkbyA8c3BhbiBjbGFzcz1cInJlcXVpcmVkXCI+Kjwvc3Bhbj4gPC9sYWJlbD5cblxuICAgICAgICA8cC1zZWxlY3RcbiAgICAgICAgICBpbnB1dElkPVwic3RhdHVzXCJcbiAgICAgICAgICBbb3B0aW9uc109XCJzdGF0dXNlc1wiXG4gICAgICAgICAgb3B0aW9uTGFiZWw9XCJsYWJlbFwiXG4gICAgICAgICAgb3B0aW9uVmFsdWU9XCJ2YWx1ZVwiXG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJ1c2VyLXN0YXR1c1wiXG4gICAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwic3RhdHVzXCJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjY2lvbmFyIGVzdGFkb1wiXG4gICAgICAgICAgYXJpYS1yZXF1aXJlZD1cInRydWVcIlxuICAgICAgICAgIGFwcGVuZFRvPVwiYm9keVwiXG4gICAgICAgICAgc3R5bGVDbGFzcz1cImZ1bGwtY29udHJvbFwiXG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgPC9mb3JtPlxuXG4gIDwhLS0gQk9UT05FUyAtLT5cbiAgPG5nLXRlbXBsYXRlICNmb290ZXI+XG4gICAgPGRpdiBjbGFzcz1cImRpYWxvZy1hY3Rpb25zXCI+XG4gICAgICA8cC1idXR0b25cbiAgICAgICAgbGFiZWw9XCJDYW5jZWxhclwiXG4gICAgICAgIGljb249XCJwaSBwaS10aW1lc1wiXG4gICAgICAgIHNldmVyaXR5PVwic2Vjb25kYXJ5XCJcbiAgICAgICAgW291dGxpbmVkXT1cInRydWVcIlxuICAgICAgICAob25DbGljayk9XCJjbG9zZSgpXCJcbiAgICAgIC8+XG5cbiAgICAgIDxwLWJ1dHRvblxuICAgICAgICBkYXRhLXRlc3RpZD1cInNhdmUtdXNlci1idXR0b25cIlxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgW2xhYmVsXT1cImlzRWRpdGluZygpID8gJ0FjdHVhbGl6YXInIDogJ0d1YXJkYXIgdXN1YXJpbydcIlxuICAgICAgICBpY29uPVwicGkgcGktY2hlY2tcIlxuICAgICAgICAob25DbGljayk9XCJzdWJtaXQoKVwiXG4gICAgICAvPlxuICAgIDwvZGl2PlxuICA8L25nLXRlbXBsYXRlPlxuPC9wLWRpYWxvZz5cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLGFBQUFBLFlBQW1CLFVBQUFDLFNBQVEsWUFBQUMsaUJBQWdCO0FBRXBELFNBQVMsbUJBQW1CO0FBRTVCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsZ0JBQUFDLHFCQUFvQjtBQUM3QixTQUFTLG1CQUFBQyx3QkFBdUI7QUFDaEMsU0FBUywyQkFBMkI7QUFDcEMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxxQkFBcUIsc0JBQXNCOzs7QUVWcEQsU0FBUyxXQUFXLE9BQU8sUUFBUSxVQUFVLFFBQVEsV0FBVyxjQUFjO0FBQzlFLFNBQVMsYUFBYSxxQkFBcUIsa0JBQWtCO0FBQzdELFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsb0JBQW9COzs7Ozs7Ozs7Ozs7QUNrQ3JCLElBQUEsNEJBQUEsR0FBQSxTQUFBLENBQUE7QUFBc0MsSUFBQSxvQkFBQSxHQUFBLDZCQUFBO0FBQTBCLElBQUEsMEJBQUE7Ozs7O0FBRWhFLElBQUEsNEJBQUEsR0FBQSxTQUFBLENBQUE7QUFBc0MsSUFBQSxvQkFBQSxHQUFBLCtDQUFBO0FBQTRDLElBQUEsMEJBQUE7Ozs7O0FBRWxGLElBQUEsNEJBQUEsR0FBQSxTQUFBLENBQUE7QUFBc0MsSUFBQSxvQkFBQSxHQUFBLGlEQUFBO0FBQThDLElBQUEsMEJBQUE7Ozs7O0FBd0JwRixJQUFBLDRCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQXVDLElBQUEsb0JBQUEsR0FBQSw2QkFBQTtBQUEwQixJQUFBLDBCQUFBOzs7OztBQUVqRSxJQUFBLDRCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQXVDLElBQUEsb0JBQUEsR0FBQSwrQ0FBQTtBQUFzQyxJQUFBLDBCQUFBOzs7Ozs7QUE0Q2pGLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBNEIsR0FBQSxZQUFBLEVBQUE7QUFNeEIsSUFBQSx3QkFBQSxXQUFBLFNBQUEsK0RBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFXLE9BQUEsTUFBQSxDQUFPO0lBQUEsQ0FBQTtBQUxwQixJQUFBLDBCQUFBO0FBUUEsSUFBQSw0QkFBQSxHQUFBLFlBQUEsRUFBQTtBQUtFLElBQUEsd0JBQUEsV0FBQSxTQUFBLCtEQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBVyxPQUFBLE9BQUEsQ0FBUTtJQUFBLENBQUE7QUFMckIsSUFBQSwwQkFBQSxFQU1FOzs7O0FBVkEsSUFBQSx1QkFBQTtBQUFBLElBQUEsd0JBQUEsWUFBQSxJQUFBO0FBT0EsSUFBQSx1QkFBQTtBQUFBLElBQUEsd0JBQUEsU0FBQSxPQUFBLFVBQUEsSUFBQSxlQUFBLGlCQUFBOzs7QUQ5R0YsSUFBTyxXQUFQLE1BQU8sVUFBUTtFQUNGLEtBQUssT0FBTyxXQUFXOztFQUcvQixVQUFVLE1BQU0sT0FBSyxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsVUFBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUNyQixPQUFPLE1BQW1CLE1BQUksR0FBQSxZQUFBLENBQUEsRUFBQSxXQUFBLE9BQUEsQ0FBQTs7SUFBQSxDQUFBO0dBQUE7O0VBRzlCLGdCQUFnQixPQUFNO0VBQ3RCLE9BQU8sT0FBTTs7RUFHYixRQUFRO0lBQ2YsRUFBRSxPQUFPLGlCQUFpQixPQUFPLGdCQUFlO0lBQ2hELEVBQUUsT0FBTyxVQUFVLE9BQU8sU0FBUTtJQUNsQyxFQUFFLE9BQU8sV0FBVyxPQUFPLFVBQVM7O0VBRzdCLFdBQVc7SUFDbEIsRUFBRSxPQUFPLFVBQVUsT0FBTyxTQUFRO0lBQ2xDLEVBQUUsT0FBTyxZQUFZLE9BQU8sV0FBVTs7O0VBSS9CLE9BQU8sS0FBSyxHQUFHLFlBQVksTUFBTTtJQUN4QyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsVUFBVSxXQUFXLFVBQVUsQ0FBQyxHQUFHLFdBQVcsVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNwRixPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsVUFBVSxXQUFXLEtBQUssQ0FBQztJQUNuRCxNQUFNLEtBQUssR0FBRyxZQUFZLFFBQWtCLFdBQVcsV0FBVyxRQUFRO0lBQzFFLFFBQVEsS0FBSyxHQUFHLFlBQVksUUFBb0IsVUFBVSxXQUFXLFFBQVE7R0FDOUU7O0VBR1EsWUFBWSxTQUFTLE1BQU0sS0FBSyxLQUFJLE1BQU8sTUFBSSxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsWUFBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUN4RCxjQUFBO0FBQ0UsUUFBSSxrQkFBa0I7QUFDdEIsUUFBSSxpQkFBZ0M7QUFFcEMsV0FBTyxNQUFLO0FBQ1YsWUFBTSxZQUFZLEtBQUssUUFBTztBQUM5QixZQUFNLGNBQWMsS0FBSyxLQUFJO0FBQzdCLFlBQU0sZ0JBQWdCLGFBQWEsTUFBTTtBQUd6QyxZQUFNLGFBQWEsYUFBYSxDQUFDO0FBQ2pDLFlBQU0sY0FBYyxhQUFhLGtCQUFrQjtBQUduRCx3QkFBa0I7QUFDbEIsdUJBQWlCLFlBQVksZ0JBQWdCO0FBRTdDLFVBQUksY0FBYyxhQUFhO0FBQzdCLGtCQUFVLE1BQU0sS0FBSyxTQUFTLFdBQVcsQ0FBQztNQUM1QztJQUNGLENBQUM7RUFDSDs7RUFHQSxTQUFTLE1BQWlCO0FBQ3hCLFNBQUssS0FBSyxNQUFNO01BQ2QsTUFBTSxNQUFNLFFBQVE7TUFDcEIsT0FBTyxNQUFNLFNBQVM7TUFDdEIsTUFBTSxNQUFNLFFBQVE7TUFDcEIsUUFBUSxNQUFNLFVBQVU7S0FDekI7RUFDSDs7RUFHQSxTQUFNO0FBQ0osU0FBSyxLQUFLLGlCQUFnQjtBQUUxQixRQUFJLEtBQUssS0FBSyxTQUFTO0FBQ3JCO0lBQ0Y7QUFFQSxVQUFNLFFBQVEsS0FBSyxLQUFLLFlBQVc7QUFFbkMsU0FBSyxLQUFLLEtBQUs7TUFDYixNQUFNLE1BQU0sS0FBSyxLQUFJO01BQ3JCLE9BQU8sTUFBTSxNQUFNLEtBQUk7TUFDdkIsTUFBTSxNQUFNO01BQ1osUUFBUSxNQUFNO0tBQ2Y7RUFDSDs7RUFHQSxRQUFLO0FBQ0gsU0FBSyxjQUFjLEtBQUssS0FBSztFQUMvQjs7cUNBdkZXLFdBQVE7RUFBQTs0RUFBUixXQUFRLFdBQUEsQ0FBQSxDQUFBLGVBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxTQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsTUFBQSxDQUFBLEdBQUEsTUFBQSxFQUFBLEdBQUEsU0FBQSxFQUFBLGVBQUEsaUJBQUEsTUFBQSxPQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxVQUFBLEVBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsVUFBQSxXQUFBLFNBQUEsYUFBQSxhQUFBLFlBQUEsbUJBQUEsYUFBQSxHQUFBLENBQUEsTUFBQSxZQUFBLGVBQUEsYUFBQSxHQUFBLGFBQUEsR0FBQSxZQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsT0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLE1BQUEsUUFBQSxjQUFBLElBQUEsZUFBQSxhQUFBLFFBQUEsUUFBQSxtQkFBQSxRQUFBLGVBQUEsOEJBQUEsaUJBQUEsTUFBQSxHQUFBLENBQUEsTUFBQSxjQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsT0FBQSxPQUFBLEdBQUEsQ0FBQSxNQUFBLFNBQUEsY0FBQSxJQUFBLGVBQUEsY0FBQSxRQUFBLFNBQUEsbUJBQUEsU0FBQSxlQUFBLHVCQUFBLGlCQUFBLE1BQUEsR0FBQSxDQUFBLE1BQUEsZUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsT0FBQSxNQUFBLEdBQUEsQ0FBQSxXQUFBLFFBQUEsZUFBQSxTQUFBLGVBQUEsU0FBQSxlQUFBLGFBQUEsbUJBQUEsUUFBQSxlQUFBLG1CQUFBLGlCQUFBLFFBQUEsWUFBQSxRQUFBLGNBQUEsZ0JBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxPQUFBLFFBQUEsR0FBQSxDQUFBLFdBQUEsVUFBQSxlQUFBLFNBQUEsZUFBQSxTQUFBLGVBQUEsZUFBQSxtQkFBQSxVQUFBLGVBQUEsc0JBQUEsaUJBQUEsUUFBQSxZQUFBLFFBQUEsY0FBQSxnQkFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLFNBQUEsWUFBQSxRQUFBLGVBQUEsWUFBQSxhQUFBLEdBQUEsV0FBQSxVQUFBLEdBQUEsQ0FBQSxlQUFBLG9CQUFBLFFBQUEsVUFBQSxRQUFBLGVBQUEsR0FBQSxXQUFBLE9BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxrQkFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ2ZyQixNQUFBLDRCQUFBLEdBQUEsWUFBQSxDQUFBO0FBR0UsTUFBQSx3QkFBQSxpQkFBQSxTQUFBLG9EQUFBLFFBQUE7QUFBQSxlQUFpQixJQUFBLGNBQUEsS0FBQSxNQUFBO01BQTBCLENBQUE7QUFTM0MsTUFBQSw0QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUlFLE1BQUEsd0JBQUEsWUFBQSxTQUFBLDZDQUFBO0FBQUEsZUFBWSxJQUFBLE9BQUE7TUFBUSxDQUFBO0FBSXBCLE1BQUEsNEJBQUEsR0FBQSxPQUFBLENBQUEsRUFBbUIsR0FBQSxTQUFBLENBQUE7QUFDRSxNQUFBLG9CQUFBLEdBQUEsbUJBQUE7QUFBZ0IsTUFBQSw0QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUF1QixNQUFBLG9CQUFBLEdBQUEsR0FBQTtBQUFDLE1BQUEsMEJBQUEsRUFBTztBQUVsRSxNQUFBLHVCQUFBLEdBQUEsU0FBQSxDQUFBO0FBZUEsTUFBQSxpQ0FBQSxHQUFBLGlDQUFBLEdBQUEsR0FBQSxTQUFBLENBQUEsRUFBNkUsR0FBQSxpQ0FBQSxHQUFBLEdBQUEsU0FBQSxDQUFBLEVBRVEsSUFBQSxrQ0FBQSxHQUFBLEdBQUEsU0FBQSxDQUFBO0FBS3ZGLE1BQUEsMEJBQUE7QUFHQSxNQUFBLDRCQUFBLElBQUEsT0FBQSxDQUFBLEVBQW1CLElBQUEsU0FBQSxDQUFBO0FBQ0csTUFBQSxvQkFBQSxJQUFBLHlCQUFBO0FBQW1CLE1BQUEsNEJBQUEsSUFBQSxRQUFBLENBQUE7QUFBdUIsTUFBQSxvQkFBQSxJQUFBLEdBQUE7QUFBQyxNQUFBLDBCQUFBLEVBQU87QUFFdEUsTUFBQSx1QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQWVBLE1BQUEsaUNBQUEsSUFBQSxrQ0FBQSxHQUFBLEdBQUEsU0FBQSxFQUFBLEVBQStFLElBQUEsa0NBQUEsR0FBQSxHQUFBLFNBQUEsRUFBQTtBQUtqRixNQUFBLDBCQUFBO0FBR0EsTUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUF1QixJQUFBLE9BQUEsQ0FBQSxFQUNGLElBQUEsU0FBQSxFQUFBO0FBQ0UsTUFBQSxvQkFBQSxJQUFBLE9BQUE7QUFBSSxNQUFBLDRCQUFBLElBQUEsUUFBQSxDQUFBO0FBQXVCLE1BQUEsb0JBQUEsSUFBQSxHQUFBO0FBQUMsTUFBQSwwQkFBQSxFQUFPO0FBRXRELE1BQUEsdUJBQUEsSUFBQSxZQUFBLEVBQUE7QUFZRixNQUFBLDBCQUFBO0FBRUEsTUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUFtQixJQUFBLFNBQUEsRUFBQTtBQUNJLE1BQUEsb0JBQUEsSUFBQSxVQUFBO0FBQU8sTUFBQSw0QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUF1QixNQUFBLG9CQUFBLElBQUEsR0FBQTtBQUFDLE1BQUEsMEJBQUEsRUFBTztBQUUzRCxNQUFBLHVCQUFBLElBQUEsWUFBQSxFQUFBO0FBWUYsTUFBQSwwQkFBQSxFQUFNLEVBQ0Y7QUFJUixNQUFBLHdCQUFBLElBQUEsa0NBQUEsR0FBQSxHQUFBLGVBQUEsTUFBQSxHQUFBLG1DQUFBO0FBbUJGLE1BQUEsMEJBQUE7OztBQTFIRSxNQUFBLHdCQUFBLDZCQUFBLElBQUEsR0FBQSxDQUFBO0FBUkEsTUFBQSx3QkFBQSxVQUFBLElBQUEsVUFBQSxJQUFBLG1CQUFBLGVBQUEsRUFBMkQsV0FBQSxJQUFBLFFBQUEsQ0FBQSxFQUN0QyxTQUFBLElBQUEsRUFFUCxhQUFBLEtBQUEsRUFDSyxhQUFBLEtBQUEsRUFDQSxZQUFBLElBQUEsRUFDRixtQkFBQSxLQUFBLEVBQ1EsZUFBQSw2QkFBQSxJQUFBLEdBQUEsQ0FBQTtBQU92QixNQUFBLHVCQUFBO0FBQUEsTUFBQSx3QkFBQSxhQUFBLElBQUEsSUFBQTtBQWdCSSxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLHlCQUFBLGNBQUEsSUFBQSxLQUFBLFNBQUEsS0FBQSxXQUFBLElBQUEsS0FBQSxTQUFBLEtBQUEsT0FBQTs7QUFPRixNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLEtBQUEsU0FBQSxLQUFBLFdBQUEsSUFBQSxLQUFBLFNBQUEsS0FBQSxTQUFBLFVBQUEsSUFBQSxJQUFBLElBQUEsS0FBQSxTQUFBLEtBQUEsV0FBQSxJQUFBLEtBQUEsU0FBQSxLQUFBLFNBQUEsV0FBQSxJQUFBLElBQUEsSUFBQSxLQUFBLFNBQUEsS0FBQSxXQUFBLElBQUEsS0FBQSxTQUFBLEtBQUEsU0FBQSxXQUFBLElBQUEsS0FBQSxFQUFBO0FBcUJFLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEseUJBQUEsY0FBQSxJQUFBLEtBQUEsU0FBQSxNQUFBLFdBQUEsSUFBQSxLQUFBLFNBQUEsTUFBQSxPQUFBOztBQU9GLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsS0FBQSxTQUFBLE1BQUEsV0FBQSxJQUFBLEtBQUEsU0FBQSxNQUFBLFNBQUEsVUFBQSxJQUFBLEtBQUEsSUFBQSxLQUFBLFNBQUEsTUFBQSxXQUFBLElBQUEsS0FBQSxTQUFBLE1BQUEsU0FBQSxPQUFBLElBQUEsS0FBQSxFQUFBO0FBY0ksTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSx3QkFBQSxXQUFBLElBQUEsS0FBQTtBQWlCQSxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLHdCQUFBLFdBQUEsSUFBQSxRQUFBOztvQkR0RkUscUJBQW1CLHVCQUFBLG1CQUFBLGlDQUFBLHlCQUFBLHdCQUFBLHVCQUFBLGlDQUFBLCtCQUFBLHVDQUFBLDhCQUFBLG9CQUFBLHlCQUFBLHNCQUFBLHVCQUFBLHVCQUFBLHFCQUFBLDhCQUFBLG1CQUFBLGlCQUFBLGlCQUFBLHlCQUFBLHVCQUFBLHVCQUFBLG9CQUFBLGtCQUFBLGtCQUFFLGNBQVksV0FBQSxXQUFBLFdBQUEsa0JBQUUsaUJBQWUsY0FBRSxjQUFZLFdBQUUsY0FBWSxvQkFBQSxXQUFBLGdCQUFBLGFBQUEsR0FBQSxRQUFBLENBQUEsaXhDQUFBLEVBQUEsQ0FBQTs7OytFQUk3RSxVQUFRLENBQUE7VUFQcEI7dUJBQ1csaUJBQWUsWUFDYixNQUFJLFNBQ1AsQ0FBQyxxQkFBcUIsY0FBYyxpQkFBaUIsY0FBYyxZQUFZLEdBQUMsVUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBQUEsUUFBQSxDQUFBLHFqQ0FBQSxFQUFBLENBQUE7Ozs7Z0ZBSTlFLFVBQVEsRUFBQSxXQUFBLFlBQUEsVUFBQSw2Q0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7OERBQVIsVUFBUSxFQUFBLFNBQUEsQ0FBQSxJQUFBLElBQUEsSUFBQSxJQUFBLElBQUEsSUFBQSxFQUFBLEdBQUEsQ0FBQSxxQkFBQSxjQUFBLGlCQUFBLGNBQUEsY0FBQSxTQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxpQkFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxpQkFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7OztBRFBmLElBQUEsNkJBQUEsR0FBQSxZQUFBLEVBQUE7QUFLRSxJQUFBLHlCQUFBLFdBQUEsU0FBQSwyREFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQVcsT0FBQSxXQUFBLENBQVk7SUFBQSxDQUFBO0FBTHpCLElBQUEsMkJBQUE7Ozs7QUFJRSxJQUFBLHlCQUFBLFlBQUEsT0FBQSxPQUFBLEtBQUEsT0FBQSxTQUFBLENBQUE7Ozs7OztBQW1CQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTJCLEdBQUEsT0FBQSxFQUFBLEVBQ0ssR0FBQSxTQUFBLEVBQUE7QUFDRixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBYyxJQUFBLDJCQUFBO0FBQ3hDLElBQUEsNkJBQUEsR0FBQSxTQUFBLEVBQUE7QUFLRSxJQUFBLHlCQUFBLGlCQUFBLFNBQUEsNkRBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQWlCLE9BQUEsVUFBQSxNQUFBLENBQWlCO0lBQUEsQ0FBQTtBQUxwQyxJQUFBLDJCQUFBLEVBT0UsRUFDRTs7OztBQUpGLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxPQUFBLE9BQUEsQ0FBQTs7Ozs7QUFVTixJQUFBLDZCQUFBLEdBQUEsSUFBQSxFQUFJLEdBQUEsTUFBQSxFQUFBO0FBRUEsSUFBQSxxQkFBQSxHQUFBLFVBQUE7QUFDQSxJQUFBLHdCQUFBLEdBQUEsY0FBQSxFQUFBO0FBQ0YsSUFBQSwyQkFBQTtBQUNBLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDRSxJQUFBLHFCQUFBLEdBQUEseUJBQUE7QUFDQSxJQUFBLHdCQUFBLEdBQUEsY0FBQSxFQUFBO0FBQ0YsSUFBQSwyQkFBQTtBQUNBLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDRSxJQUFBLHFCQUFBLEdBQUEsT0FBQTtBQUNBLElBQUEsd0JBQUEsR0FBQSxjQUFBLEVBQUE7QUFDRixJQUFBLDJCQUFBO0FBQ0EsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNFLElBQUEscUJBQUEsSUFBQSxVQUFBO0FBQ0EsSUFBQSx3QkFBQSxJQUFBLGNBQUEsRUFBQTtBQUNGLElBQUEsMkJBQUE7QUFDQSxJQUFBLDZCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEscUJBQUEsSUFBQSxVQUFBO0FBQVEsSUFBQSwyQkFBQSxFQUFLOzs7Ozs7QUF5QlgsSUFBQSw2QkFBQSxHQUFBLFlBQUEsRUFBQTtBQU9FLElBQUEseUJBQUEsV0FBQSxTQUFBLDJFQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLEVBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFBLDBCQUFXLE9BQUEsU0FBQSxPQUFBLENBQWM7SUFBQSxDQUFBO0FBUDNCLElBQUEsMkJBQUE7OztBQUdFLElBQUEseUJBQUEsUUFBQSxJQUFBLEVBQWEsV0FBQSxJQUFBOzs7Ozs7QUFRZixJQUFBLDZCQUFBLEdBQUEsWUFBQSxFQUFBO0FBU0UsSUFBQSx5QkFBQSxXQUFBLFNBQUEsMkVBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsRUFBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQVcsT0FBQSxjQUFBLE9BQUEsQ0FBbUI7SUFBQSxDQUFBO0FBVGhDLElBQUEsMkJBQUE7Ozs7O0FBSUUsSUFBQSx5QkFBQSxRQUFBLElBQUEsRUFBYSxXQUFBLElBQUEsRUFDRyxZQUFBLE9BQUEsU0FBQSxNQUFBLElBQUEsRUFDZ0IsV0FBQSxPQUFBLFNBQUEsTUFBQSxRQUFBLEVBQUE7Ozs7O0FBcEMxQyxJQUFBLDZCQUFBLEdBQUEsSUFBQSxFQUFJLEdBQUEsSUFBQSxFQUNFLEdBQUEsT0FBQSxFQUFBO0FBRUEsSUFBQSx3QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBO0FBQWUsSUFBQSwyQkFBQSxFQUFPLEVBQ3hCO0FBRVIsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHFCQUFBLENBQUE7QUFBZ0IsSUFBQSwyQkFBQTtBQUNwQixJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEscUJBQUEsQ0FBQTtBQUFlLElBQUEsMkJBQUE7QUFDbkIsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDRSxJQUFBLHdCQUFBLElBQUEsU0FBQSxFQUFBO0FBSUYsSUFBQSwyQkFBQTtBQUVBLElBQUEsNkJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxPQUFBLEVBQUE7QUFFQSxJQUFBLGtDQUFBLElBQUEsOENBQUEsR0FBQSxHQUFBLFlBQUEsRUFBQTtBQVdBLElBQUEsa0NBQUEsSUFBQSw4Q0FBQSxHQUFBLEdBQUEsWUFBQSxFQUFBO0FBYUYsSUFBQSwyQkFBQSxFQUFNLEVBQ0g7Ozs7O0FBdkNLLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsUUFBQSxJQUFBO0FBR04sSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxRQUFBLEtBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFFBQUEsSUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsU0FBQSxRQUFBLE1BQUEsRUFBcUIsWUFBQSxRQUFBLFdBQUEsV0FBQSxZQUFBLFFBQUE7QUFPckIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxPQUFBLFFBQUEsSUFBQSxLQUFBLEVBQUE7QUFXQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxPQUFBLFVBQUEsSUFBQSxLQUFBLEVBQUE7Ozs7O0FBZ0NOLElBQUEsNkJBQUEsR0FBQSxJQUFBLEVBQUksR0FBQSxNQUFBLEVBQUE7QUFDb0MsSUFBQSxxQkFBQSxHQUFBLDZCQUFBO0FBQTJCLElBQUEsMkJBQUEsRUFBSzs7O0FEbEcxRSxJQUFPLFFBQVAsTUFBTyxPQUFLOztFQUVQLFFBQVFDLFFBQU8sU0FBUztFQUNoQixpQkFBaUJBLFFBQU8sY0FBYztFQUN0QyxzQkFBc0JBLFFBQU8sbUJBQW1COztFQUd4RCxRQUFRLEtBQUssTUFBTTtFQUNuQixnQkFBZ0IsS0FBSyxNQUFNO0VBQzNCLFVBQVUsS0FBSyxNQUFNO0VBQ3JCLFNBQVMsS0FBSyxNQUFNO0VBQ3BCLFdBQVcsS0FBSyxNQUFNO0VBQ3RCLGFBQWEsS0FBSyxNQUFNO0VBQ3hCLGNBQWMsS0FBSyxNQUFNO0VBQ3pCLFNBQVMsS0FBSyxNQUFNO0VBQ3BCLGdCQUFnQixLQUFLLE1BQU07RUFDM0IsZUFBZSxLQUFLLE1BQU07RUFFMUIsY0FBY0EsUUFBTyxpQkFBaUI7RUFDdEMsWUFBWUMsVUFBUyxNQUFNLEtBQUssWUFBWSxJQUFJLGNBQWMsR0FBQyxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsWUFBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUMvRCxVQUFVQSxVQUFTLE1BQU0sS0FBSyxZQUFZLElBQUksWUFBWSxHQUFDLEdBQUEsWUFBQSxDQUFBLEVBQUEsV0FBQSxVQUFBLENBQUE7O0lBQUEsQ0FBQTtHQUFBO0VBQzNELFlBQVlBLFVBQVMsTUFBTSxLQUFLLFlBQVksSUFBSSxjQUFjLEdBQUMsR0FBQSxZQUFBLENBQUEsRUFBQSxXQUFBLFlBQUEsQ0FBQTs7SUFBQSxDQUFBO0dBQUE7O0VBR3hFLFdBQVE7QUFDTixTQUFLLFVBQVM7RUFDaEI7O0VBR0EsWUFBUztBQUNQLFNBQUssTUFBTSxVQUFVO01BQ25CLFNBQVMsQ0FBQyxVQUFVLEtBQUssVUFBVSxPQUFPLHFDQUFxQztLQUNoRjtFQUNIO0VBRUEsVUFBVSxNQUFZO0FBQ3BCLFNBQUssTUFBTSxVQUFVLElBQUk7RUFDM0I7RUFFQSxpQkFBaUIsU0FBZ0I7QUFDL0IsU0FBSyxNQUFNLGlCQUFpQixPQUFPO0VBQ3JDOztFQUdBLGFBQVU7QUFDUixRQUFJLENBQUMsS0FBSyxVQUFTO0FBQUk7QUFDdkIsU0FBSyxNQUFNLFdBQVU7RUFDdkI7O0VBR0EsU0FBUyxNQUFVO0FBQ2pCLFFBQUksQ0FBQyxLQUFLLFFBQU87QUFBSTtBQUNyQixTQUFLLE1BQU0sU0FBUyxJQUFJO0VBQzFCOztFQUdBLFNBQVMsTUFBbUI7QUFFMUIsVUFBTSxjQUFjLEtBQUssYUFBWTtBQUNyQyxVQUFNLFVBQVUsZ0JBQWdCO0FBR2hDLFFBQUksV0FBVyxDQUFDLEtBQUssUUFBTztBQUFJO0FBQ2hDLFFBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQUk7QUFHbkMsUUFBSSxLQUFLLE9BQU07QUFBSTtBQUduQixVQUFNLFFBQVEsS0FBSyxNQUFNLEtBQUksRUFBRyxZQUFXO0FBRzNDLFFBQUksS0FBSyxNQUFNLGlCQUFpQixPQUFPLGFBQWEsRUFBRSxHQUFHO0FBQ3ZELFdBQUssZUFBZSxJQUFJO1FBQ3RCLFVBQVU7UUFDVixTQUFTO1FBQ1QsUUFBUTtPQUNUO0FBQ0Q7SUFDRjtBQUdBLFNBQUssTUFBTSxTQUFTLE1BQU07TUFDeEIsV0FBVyxDQUFDLGNBQWE7QUFDdkIsYUFBSyxlQUFlLElBQUk7VUFDdEIsVUFBVTtVQUNWLFNBQVMsWUFBWSx3QkFBd0I7VUFDN0MsUUFBUTtTQUNUO01BQ0g7TUFDQSxTQUFTLENBQUMsVUFBUztBQUNqQixhQUFLLFVBQVUsT0FBTyxnQ0FBZ0M7TUFDeEQ7S0FDRDtFQUNIOztFQUdBLGNBQWMsTUFBVTtBQUN0QixRQUFJLENBQUMsS0FBSyxVQUFTO0FBQUk7QUFDdkIsUUFBSSxLQUFLLFNBQVEsTUFBTyxRQUFRLEtBQUssT0FBTTtBQUFJO0FBRS9DLFNBQUssb0JBQW9CLFFBQVE7TUFDL0IsUUFBUTtNQUNSLFNBQVMseUJBQXNCLEtBQUssSUFBSTtNQUN4QyxNQUFNO01BQ04sYUFBYTtNQUNiLGFBQWE7TUFDYixtQkFBbUIsRUFBRSxVQUFVLFNBQVE7TUFDdkMsbUJBQW1CLEVBQUUsVUFBVSxhQUFhLFVBQVUsS0FBSTtNQUMxRCxRQUFRLE1BQU0sS0FBSyxXQUFXLEtBQUssRUFBRTtLQUN0QztFQUNIOztFQUdRLFdBQVcsSUFBVTtBQUMzQixRQUFJLENBQUMsS0FBSyxVQUFTO0FBQUk7QUFDdkIsUUFBSSxLQUFLLFNBQVEsTUFBTyxRQUFRLEtBQUssT0FBTTtBQUFJO0FBRS9DLFNBQUssTUFBTSxXQUFXLElBQUk7TUFDeEIsV0FBVyxNQUFLO0FBQ2QsYUFBSyxlQUFlLElBQUk7VUFDdEIsVUFBVTtVQUNWLFNBQVM7VUFDVCxRQUFRO1NBQ1Q7TUFDSDtNQUNBLFNBQVMsQ0FBQyxVQUFVLEtBQUssVUFBVSxPQUFPLGlDQUFpQztLQUM1RTtFQUNIOztFQUdRLFVBQVUsT0FBMEIsVUFBZ0I7QUFDMUQsWUFBUSxNQUFNLGVBQWUsS0FBSztBQUNsQyxRQUFJLFNBQVM7QUFDYixRQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLGVBQVM7SUFDWCxXQUFXLE1BQU0sV0FBVyxLQUFLO0FBQy9CLGVBQVM7SUFDWCxXQUFXLE1BQU0sV0FBVyxLQUFLO0FBQy9CLGVBQVM7SUFDWCxXQUFXLE1BQU0sVUFBVSxLQUFLO0FBQzlCLGVBQVM7SUFDWDtBQUNBLFNBQUssZUFBZSxJQUFJLEVBQUUsVUFBVSxTQUFTLFNBQVMsU0FBUyxPQUFNLENBQUU7RUFDekU7O3FDQWhKVyxRQUFLO0VBQUE7NkVBQUwsUUFBSyxXQUFBLENBQUEsQ0FBQSxXQUFBLENBQUEsR0FBQSxVQUFBLENBQUEsaUNBSkwsQ0FBQyxxQkFBcUIsY0FBYyxDQUFDLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLFdBQUEsRUFBQSxHQUFBLENBQUEsVUFBQSxFQUFBLEdBQUEsQ0FBQSxRQUFBLEVBQUEsR0FBQSxDQUFBLGdCQUFBLEVBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxlQUFBLG1CQUFBLFNBQUEsaUJBQUEsUUFBQSxjQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxlQUFBLGVBQUEsR0FBQSxTQUFBLFdBQUEsYUFBQSxRQUFBLHNCQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsUUFBQSxXQUFBLE1BQUEsR0FBQSxDQUFBLGVBQUEsbUJBQUEsU0FBQSxpQkFBQSxRQUFBLGNBQUEsR0FBQSxXQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsT0FBQSxjQUFBLEdBQUEsQ0FBQSxNQUFBLGdCQUFBLGNBQUEsSUFBQSxRQUFBLFVBQUEsZUFBQSxxQkFBQSxHQUFBLGlCQUFBLFNBQUEsR0FBQSxDQUFBLG1CQUFBLE1BQUEsR0FBQSxDQUFBLFNBQUEsTUFBQSxHQUFBLENBQUEsbUJBQUEsT0FBQSxHQUFBLENBQUEsU0FBQSxPQUFBLEdBQUEsQ0FBQSxtQkFBQSxNQUFBLEdBQUEsQ0FBQSxTQUFBLE1BQUEsR0FBQSxDQUFBLG1CQUFBLFFBQUEsR0FBQSxDQUFBLFNBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxlQUFBLFFBQUEsR0FBQSxNQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLFFBQUEsZ0JBQUEsWUFBQSxRQUFBLGVBQUEsb0JBQUEsYUFBQSxrQkFBQSxHQUFBLFFBQUEsU0FBQSxHQUFBLENBQUEsZUFBQSxzQkFBQSxRQUFBLGVBQUEsWUFBQSxVQUFBLGFBQUEsb0JBQUEsR0FBQSxRQUFBLFdBQUEsWUFBQSxTQUFBLEdBQUEsQ0FBQSxRQUFBLGdCQUFBLFlBQUEsUUFBQSxlQUFBLG9CQUFBLGFBQUEsa0JBQUEsR0FBQSxXQUFBLFFBQUEsU0FBQSxHQUFBLENBQUEsZUFBQSxzQkFBQSxRQUFBLGVBQUEsWUFBQSxVQUFBLGFBQUEsb0JBQUEsR0FBQSxXQUFBLFFBQUEsV0FBQSxZQUFBLFNBQUEsR0FBQSxDQUFBLFdBQUEsS0FBQSxHQUFBLGVBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxlQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO0FDL0JsRCxNQUFBLDZCQUFBLEdBQUEsV0FBQSxDQUFBLEVBQTRCLEdBQUEsT0FBQSxDQUFBLEVBRUQsR0FBQSxLQUFBLEVBQ2xCLEdBQUEsSUFBQTtBQUNDLE1BQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFtQixNQUFBLDJCQUFBO0FBQ3ZCLE1BQUEsNkJBQUEsR0FBQSxHQUFBO0FBQUcsTUFBQSxxQkFBQSxHQUFBLG1EQUFBO0FBQWlELE1BQUEsMkJBQUEsRUFBSTtBQUUxRCxNQUFBLGtDQUFBLEdBQUEsOEJBQUEsR0FBQSxHQUFBLFlBQUEsQ0FBQTtBQVNGLE1BQUEsMkJBQUE7QUFHQSxNQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQXdCLEdBQUEsV0FBQSxDQUFBO0FBV3BCLE1BQUEseUJBQUEsSUFBQSwrQkFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUEsRUFBc0IsSUFBQSwrQkFBQSxJQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUEsRUFpQkQsSUFBQSwrQkFBQSxJQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUEsRUF1Qk8sSUFBQSwrQkFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUE7QUFrRTlCLE1BQUEsMkJBQUEsRUFBVSxFQUNOO0FBSVIsTUFBQSw2QkFBQSxJQUFBLGlCQUFBLENBQUE7QUFHRSxNQUFBLHlCQUFBLGlCQUFBLFNBQUEsdURBQUEsUUFBQTtBQUFBLGVBQWlCLElBQUEsaUJBQUEsTUFBQTtNQUF3QixDQUFBLEVBQUMsUUFBQSxTQUFBLDhDQUFBLFFBQUE7QUFBQSxlQUNsQyxJQUFBLFNBQUEsTUFBQTtNQUFnQixDQUFBO0FBSjFCLE1BQUEsMkJBQUE7QUFRQSxNQUFBLHdCQUFBLElBQUEsaUJBQUEsRUFBbUIsSUFBQSxTQUFBOzs7QUE5SWYsTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBLFVBQUEsSUFBQSxJQUFBLEVBQUE7QUFjRSxNQUFBLHdCQUFBLENBQUE7QUFBQSxNQUFBLHlCQUFBLFNBQUEsSUFBQSxjQUFBLENBQUEsRUFBeUIsV0FBQSxJQUFBLFFBQUEsQ0FBQSxFQUNKLGFBQUEsSUFBQSxFQUNILFFBQUEsRUFBQSxFQUVQLHNCQUFBLDhCQUFBLEdBQUFDLElBQUEsQ0FBQSxFQUN3QixjQUFBLDhCQUFBLElBQUFDLElBQUEsQ0FBQTtBQW9IdkMsTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSx5QkFBQSxXQUFBLElBQUEsY0FBQSxDQUFBLEVBQTJCLFFBQUEsSUFBQSxhQUFBLENBQUE7O29CRHhIekIsYUFBVyx3QkFBQSxvQkFBQSxrQ0FBQSwwQkFBQSx5QkFBQSx3QkFBQSxrQ0FBQSxnQ0FBQSx3Q0FBQSwrQkFBQSxxQkFBQSwwQkFBQSx1QkFBQSx3QkFBQSx3QkFBQSxzQkFBQSwrQkFBQSxvQkFBQSxrQkFBQSxrQkFBQSxhQUFBLGtCQUFBLFlBQ1gsYUFBVyxXQUFBLFlBQUEsWUFBQSxtQkFBQSxvQkFBQSxrQkFBQSxvQkFBQSxtQkFBQSxnQkFBQSxvQkFBQSxxQkFBQSx1QkFBQSxvQkFBQSxnQkFBQSxjQUFBLHNCQUFBLG1CQUFBLHlCQUFBLDBCQUFBLG9CQUFBLDJCQUFBLGlCQUFBLHFCQUFBLHFCQUFBLHVCQUFBLGtCQUFBLDZCQUFBLGNBQ1gsV0FBUyxTQUNUQyxlQUFZLHFCQUFBLFlBQUEsaUJBQUEsZ0JBQ1pDLGtCQUFlLGNBQ2YscUJBQW1CLGtCQUNuQixhQUFXLFVBQ1gsUUFBUSxHQUFBLFFBQUEsQ0FBQSxnK0VBQUEsRUFBQSxDQUFBOzs7Z0ZBTUMsT0FBSyxDQUFBO1VBakJqQkM7dUJBQ1csYUFBVyxZQUNULE1BQUksU0FDUDtNQUNQO01BQ0E7TUFDQTtNQUNBRjtNQUNBQztNQUNBO01BQ0E7TUFDQTtPQUNELFdBQ1UsQ0FBQyxxQkFBcUIsY0FBYyxHQUFDLFVBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQUFBLFFBQUEsQ0FBQSxvK0RBQUEsRUFBQSxDQUFBOzs7O2lGQUlyQyxPQUFLLEVBQUEsV0FBQSxTQUFBLFVBQUEsK0JBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7OytEQUFMLE9BQUssRUFBQSxTQUFBLENBQUFFLEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFDLEtBQUEsSUFBQSxJQUFBLEVBQUEsR0FBQSxDQUFBLHFCQUFBLGdCQUFBLGFBQUEsYUFBQSxXQUFBVCxlQUFBQyxrQkFBQSxxQkFBQSxhQUFBLFVBQUFDLFVBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLGNBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsY0FBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7IiwibmFtZXMiOlsiQ29tcG9uZW50IiwiaW5qZWN0IiwiY29tcHV0ZWQiLCJCdXR0b25Nb2R1bGUiLCJJbnB1dFRleHRNb2R1bGUiLCJpbmplY3QiLCJjb21wdXRlZCIsIl9jMCIsIl9jMSIsIkJ1dHRvbk1vZHVsZSIsIklucHV0VGV4dE1vZHVsZSIsIkNvbXBvbmVudCIsImkwIiwiaTEiLCJpMiIsImkzIiwiaTQiLCJpNSIsImk2Il19