import {
  environment
} from "/chunk-P37EOHI7.js";

// src/app/core/services/auth.ts
import { Injectable, computed, inject, signal } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { HttpClient } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_common_http.js?v=b9a49161";
import { catchError, finalize, map, of, shareReplay, tap } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/rxjs.js?v=b9a49161";
import { Router } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_router.js?v=b9a49161";
import * as i0 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
var AuthService = class _AuthService {
  http = inject(HttpClient);
  apiUrl = `${environment.apiUrl}/auth`;
  _currentUser = signal(null, ...ngDevMode ? [{ debugName: "_currentUser" }] : (
    /* istanbul ignore next */
    []
  ));
  _initialized = signal(false, ...ngDevMode ? [{ debugName: "_initialized" }] : (
    /* istanbul ignore next */
    []
  ));
  _loading = signal(false, ...ngDevMode ? [{ debugName: "_loading" }] : (
    /* istanbul ignore next */
    []
  ));
  initializationRequest$;
  currentUser = this._currentUser.asReadonly();
  initialized = this._initialized.asReadonly();
  loading = this._loading.asReadonly();
  isAuthenticated = computed(() => this._currentUser() !== null, ...ngDevMode ? [{ debugName: "isAuthenticated" }] : (
    /* istanbul ignore next */
    []
  ));
  isAdmin = computed(() => this._currentUser()?.role === "Administrador", ...ngDevMode ? [{ debugName: "isAdmin" }] : (
    /* istanbul ignore next */
    []
  ));
  router = inject(Router);
  // INICIAR SESIÓN
  login(credentials) {
    this._loading.set(true);
    return this.http.post(`${this.apiUrl}/login`, credentials, { withCredentials: true }).pipe(map((response) => response.user), tap((user) => {
      this._currentUser.set(user);
      this._initialized.set(true);
    }), finalize(() => {
      this._loading.set(false);
    }));
  }
  // RECUPERAR SESIÓN AL RECARGAR LA PÁGINA
  initialize() {
    if (this._initialized()) {
      return of(this.isAuthenticated());
    }
    if (this.initializationRequest$) {
      return this.initializationRequest$;
    }
    this.initializationRequest$ = this.http.get(`${this.apiUrl}/me`, { withCredentials: true }).pipe(map((response) => {
      this._currentUser.set(response.user);
      return true;
    }), catchError(() => {
      this._currentUser.set(null);
      return of(false);
    }), tap(() => {
      this._initialized.set(true);
    }), finalize(() => {
      this.initializationRequest$ = void 0;
    }), shareReplay({ bufferSize: 1, refCount: true }));
    return this.initializationRequest$;
  }
  // CERRAR SESIÓN
  logout() {
    return this.http.post(`${this.apiUrl}/logout`, {}, { withCredentials: true }).pipe(tap(() => {
      this.clearLocalSession();
      void this.router.navigate(["/login"], {
        replaceUrl: true
      });
    }));
  }
  // LIMPIAR ESTADO LOCAL
  clearLocalSession() {
    this._currentUser.set(null);
    this._initialized.set(true);
  }
  static \u0275fac = function AuthService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AuthService)();
  };
  static \u0275prov = /* @__PURE__ */ i0.\u0275\u0275defineInjectable({ token: _AuthService, factory: _AuthService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(AuthService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

export {
  AuthService
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29yZS9zZXJ2aWNlcy9hdXRoLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIGNvbXB1dGVkLCBpbmplY3QsIHNpZ25hbCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcblxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgY2F0Y2hFcnJvciwgZmluYWxpemUsIG1hcCwgb2YsIHNoYXJlUmVwbGF5LCB0YXAgfSBmcm9tICdyeGpzJztcblxuaW1wb3J0IHsgZW52aXJvbm1lbnQgfSBmcm9tICcuLi8uLi8uLi9lbnZpcm9ubWVudHMvZW52aXJvbm1lbnQnO1xuaW1wb3J0IHsgQXV0aFJlc3BvbnNlLCBBdXRoVXNlciwgTG9naW5DcmVkZW50aWFscyB9IGZyb20gJy4uL21vZGVscy9hdXRoLm1vZGVsJztcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5cbkBJbmplY3RhYmxlKHtcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxufSlcbmV4cG9ydCBjbGFzcyBBdXRoU2VydmljZSB7XG4gIHByaXZhdGUgcmVhZG9ubHkgaHR0cCA9IGluamVjdChIdHRwQ2xpZW50KTtcblxuICBwcml2YXRlIHJlYWRvbmx5IGFwaVVybCA9IGAke2Vudmlyb25tZW50LmFwaVVybH0vYXV0aGA7XG5cbiAgcHJpdmF0ZSByZWFkb25seSBfY3VycmVudFVzZXIgPSBzaWduYWw8QXV0aFVzZXIgfCBudWxsPihudWxsKTtcbiAgcHJpdmF0ZSByZWFkb25seSBfaW5pdGlhbGl6ZWQgPSBzaWduYWwoZmFsc2UpO1xuICBwcml2YXRlIHJlYWRvbmx5IF9sb2FkaW5nID0gc2lnbmFsKGZhbHNlKTtcblxuICBwcml2YXRlIGluaXRpYWxpemF0aW9uUmVxdWVzdCQ/OiBPYnNlcnZhYmxlPGJvb2xlYW4+O1xuXG4gIHJlYWRvbmx5IGN1cnJlbnRVc2VyID0gdGhpcy5fY3VycmVudFVzZXIuYXNSZWFkb25seSgpO1xuICByZWFkb25seSBpbml0aWFsaXplZCA9IHRoaXMuX2luaXRpYWxpemVkLmFzUmVhZG9ubHkoKTtcbiAgcmVhZG9ubHkgbG9hZGluZyA9IHRoaXMuX2xvYWRpbmcuYXNSZWFkb25seSgpO1xuXG4gIHJlYWRvbmx5IGlzQXV0aGVudGljYXRlZCA9IGNvbXB1dGVkKCgpID0+IHRoaXMuX2N1cnJlbnRVc2VyKCkgIT09IG51bGwpO1xuXG4gIHJlYWRvbmx5IGlzQWRtaW4gPSBjb21wdXRlZCgoKSA9PiB0aGlzLl9jdXJyZW50VXNlcigpPy5yb2xlID09PSAnQWRtaW5pc3RyYWRvcicpO1xuICBwcml2YXRlIHJlYWRvbmx5IHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xuICAvLyBJTklDSUFSIFNFU0nDk05cbiAgbG9naW4oY3JlZGVudGlhbHM6IExvZ2luQ3JlZGVudGlhbHMpOiBPYnNlcnZhYmxlPEF1dGhVc2VyPiB7XG4gICAgdGhpcy5fbG9hZGluZy5zZXQodHJ1ZSk7XG5cbiAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAucG9zdDxBdXRoUmVzcG9uc2U+KGAke3RoaXMuYXBpVXJsfS9sb2dpbmAsIGNyZWRlbnRpYWxzLCB7IHdpdGhDcmVkZW50aWFsczogdHJ1ZSB9KVxuICAgICAgLnBpcGUoXG4gICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLnVzZXIpLFxuXG4gICAgICAgIHRhcCgodXNlcikgPT4ge1xuICAgICAgICAgIHRoaXMuX2N1cnJlbnRVc2VyLnNldCh1c2VyKTtcbiAgICAgICAgICB0aGlzLl9pbml0aWFsaXplZC5zZXQodHJ1ZSk7XG4gICAgICAgIH0pLFxuXG4gICAgICAgIGZpbmFsaXplKCgpID0+IHtcbiAgICAgICAgICB0aGlzLl9sb2FkaW5nLnNldChmYWxzZSk7XG4gICAgICAgIH0pLFxuICAgICAgKTtcbiAgfVxuXG4gIC8vIFJFQ1VQRVJBUiBTRVNJw5NOIEFMIFJFQ0FSR0FSIExBIFDDgUdJTkFcbiAgaW5pdGlhbGl6ZSgpOiBPYnNlcnZhYmxlPGJvb2xlYW4+IHtcbiAgICBpZiAodGhpcy5faW5pdGlhbGl6ZWQoKSkge1xuICAgICAgcmV0dXJuIG9mKHRoaXMuaXNBdXRoZW50aWNhdGVkKCkpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLmluaXRpYWxpemF0aW9uUmVxdWVzdCQpIHtcbiAgICAgIHJldHVybiB0aGlzLmluaXRpYWxpemF0aW9uUmVxdWVzdCQ7XG4gICAgfVxuXG4gICAgdGhpcy5pbml0aWFsaXphdGlvblJlcXVlc3QkID0gdGhpcy5odHRwXG4gICAgICAuZ2V0PEF1dGhSZXNwb25zZT4oYCR7dGhpcy5hcGlVcmx9L21lYCwgeyB3aXRoQ3JlZGVudGlhbHM6IHRydWUgfSlcbiAgICAgIC5waXBlKFxuICAgICAgICBtYXAoKHJlc3BvbnNlKTogYm9vbGVhbiA9PiB7XG4gICAgICAgICAgdGhpcy5fY3VycmVudFVzZXIuc2V0KHJlc3BvbnNlLnVzZXIpO1xuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9KSxcblxuICAgICAgICBjYXRjaEVycm9yKCgpID0+IHtcbiAgICAgICAgICB0aGlzLl9jdXJyZW50VXNlci5zZXQobnVsbCk7XG4gICAgICAgICAgcmV0dXJuIG9mKGZhbHNlKTtcbiAgICAgICAgfSksXG5cbiAgICAgICAgdGFwKCgpID0+IHtcbiAgICAgICAgICB0aGlzLl9pbml0aWFsaXplZC5zZXQodHJ1ZSk7XG4gICAgICAgIH0pLFxuXG4gICAgICAgIGZpbmFsaXplKCgpID0+IHtcbiAgICAgICAgICB0aGlzLmluaXRpYWxpemF0aW9uUmVxdWVzdCQgPSB1bmRlZmluZWQ7XG4gICAgICAgIH0pLFxuXG4gICAgICAgIHNoYXJlUmVwbGF5KHsgYnVmZmVyU2l6ZTogMSwgcmVmQ291bnQ6IHRydWUgfSksXG4gICAgICApO1xuXG4gICAgcmV0dXJuIHRoaXMuaW5pdGlhbGl6YXRpb25SZXF1ZXN0JDtcbiAgfVxuXG4gIC8vIENFUlJBUiBTRVNJw5NOXG4gIGxvZ291dCgpOiBPYnNlcnZhYmxlPHZvaWQ+IHtcbiAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8dm9pZD4oYCR7dGhpcy5hcGlVcmx9L2xvZ291dGAsIHt9LCB7IHdpdGhDcmVkZW50aWFsczogdHJ1ZSB9KS5waXBlKFxuICAgICAgdGFwKCgpID0+IHtcbiAgICAgICAgLy8gMS4gTGltcGlhciB1c3VhcmlvIGF1dGVudGljYWRvXG4gICAgICAgIHRoaXMuY2xlYXJMb2NhbFNlc3Npb24oKTtcblxuICAgICAgICAvLyAyLiBSZWRpcmlnaXIgaW5tZWRpYXRhbWVudGUgYWwgTG9naW5cbiAgICAgICAgdm9pZCB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9sb2dpbiddLCB7XG4gICAgICAgICAgcmVwbGFjZVVybDogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICB9KSxcbiAgICApO1xuICB9XG5cbiAgLy8gTElNUElBUiBFU1RBRE8gTE9DQUxcbiAgY2xlYXJMb2NhbFNlc3Npb24oKTogdm9pZCB7XG4gICAgdGhpcy5fY3VycmVudFVzZXIuc2V0KG51bGwpO1xuICAgIHRoaXMuX2luaXRpYWxpemVkLnNldCh0cnVlKTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7OztBQUFBLFNBQVMsWUFBWSxVQUFVLFFBQVEsY0FBYztBQUNyRCxTQUFTLGtCQUFrQjtBQUUzQixTQUFxQixZQUFZLFVBQVUsS0FBSyxJQUFJLGFBQWEsV0FBVztBQUk1RSxTQUFTLGNBQWM7O0FBS2pCLElBQU8sY0FBUCxNQUFPLGFBQVc7RUFDTCxPQUFPLE9BQU8sVUFBVTtFQUV4QixTQUFTLEdBQUcsWUFBWSxNQUFNO0VBRTlCLGVBQWUsT0FBd0IsTUFBSSxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsZUFBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUMzQyxlQUFlLE9BQU8sT0FBSyxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsZUFBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUMzQixXQUFXLE9BQU8sT0FBSyxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsV0FBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUVoQztFQUVDLGNBQWMsS0FBSyxhQUFhLFdBQVU7RUFDMUMsY0FBYyxLQUFLLGFBQWEsV0FBVTtFQUMxQyxVQUFVLEtBQUssU0FBUyxXQUFVO0VBRWxDLGtCQUFrQixTQUFTLE1BQU0sS0FBSyxhQUFZLE1BQU8sTUFBSSxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsa0JBQUEsQ0FBQTs7SUFBQSxDQUFBO0dBQUE7RUFFN0QsVUFBVSxTQUFTLE1BQU0sS0FBSyxhQUFZLEdBQUksU0FBUyxpQkFBZSxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsVUFBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUM5RCxTQUFTLE9BQU8sTUFBTTs7RUFFdkMsTUFBTSxhQUE2QjtBQUNqQyxTQUFLLFNBQVMsSUFBSSxJQUFJO0FBRXRCLFdBQU8sS0FBSyxLQUNULEtBQW1CLEdBQUcsS0FBSyxNQUFNLFVBQVUsYUFBYSxFQUFFLGlCQUFpQixLQUFJLENBQUUsRUFDakYsS0FDQyxJQUFJLENBQUMsYUFBYSxTQUFTLElBQUksR0FFL0IsSUFBSSxDQUFDLFNBQVE7QUFDWCxXQUFLLGFBQWEsSUFBSSxJQUFJO0FBQzFCLFdBQUssYUFBYSxJQUFJLElBQUk7SUFDNUIsQ0FBQyxHQUVELFNBQVMsTUFBSztBQUNaLFdBQUssU0FBUyxJQUFJLEtBQUs7SUFDekIsQ0FBQyxDQUFDO0VBRVI7O0VBR0EsYUFBVTtBQUNSLFFBQUksS0FBSyxhQUFZLEdBQUk7QUFDdkIsYUFBTyxHQUFHLEtBQUssZ0JBQWUsQ0FBRTtJQUNsQztBQUVBLFFBQUksS0FBSyx3QkFBd0I7QUFDL0IsYUFBTyxLQUFLO0lBQ2Q7QUFFQSxTQUFLLHlCQUF5QixLQUFLLEtBQ2hDLElBQWtCLEdBQUcsS0FBSyxNQUFNLE9BQU8sRUFBRSxpQkFBaUIsS0FBSSxDQUFFLEVBQ2hFLEtBQ0MsSUFBSSxDQUFDLGFBQXFCO0FBQ3hCLFdBQUssYUFBYSxJQUFJLFNBQVMsSUFBSTtBQUNuQyxhQUFPO0lBQ1QsQ0FBQyxHQUVELFdBQVcsTUFBSztBQUNkLFdBQUssYUFBYSxJQUFJLElBQUk7QUFDMUIsYUFBTyxHQUFHLEtBQUs7SUFDakIsQ0FBQyxHQUVELElBQUksTUFBSztBQUNQLFdBQUssYUFBYSxJQUFJLElBQUk7SUFDNUIsQ0FBQyxHQUVELFNBQVMsTUFBSztBQUNaLFdBQUsseUJBQXlCO0lBQ2hDLENBQUMsR0FFRCxZQUFZLEVBQUUsWUFBWSxHQUFHLFVBQVUsS0FBSSxDQUFFLENBQUM7QUFHbEQsV0FBTyxLQUFLO0VBQ2Q7O0VBR0EsU0FBTTtBQUNKLFdBQU8sS0FBSyxLQUFLLEtBQVcsR0FBRyxLQUFLLE1BQU0sV0FBVyxDQUFBLEdBQUksRUFBRSxpQkFBaUIsS0FBSSxDQUFFLEVBQUUsS0FDbEYsSUFBSSxNQUFLO0FBRVAsV0FBSyxrQkFBaUI7QUFHdEIsV0FBSyxLQUFLLE9BQU8sU0FBUyxDQUFDLFFBQVEsR0FBRztRQUNwQyxZQUFZO09BQ2I7SUFDSCxDQUFDLENBQUM7RUFFTjs7RUFHQSxvQkFBaUI7QUFDZixTQUFLLGFBQWEsSUFBSSxJQUFJO0FBQzFCLFNBQUssYUFBYSxJQUFJLElBQUk7RUFDNUI7O3FDQS9GVyxjQUFXO0VBQUE7K0VBQVgsY0FBVyxTQUFYLGFBQVcsV0FBQSxZQUZWLE9BQU0sQ0FBQTs7OytFQUVQLGFBQVcsQ0FBQTtVQUh2QjtXQUFXO01BQ1YsWUFBWTtLQUNiOzs7IiwibmFtZXMiOltdfQ==