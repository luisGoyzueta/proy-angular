import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/chunk-43GWQ3L2.js");import {
  UserStore
} from "/chunk-WOIO7PCB.js";
import "/chunk-P37EOHI7.js";
import "/chunk-VUJOFXKG.js";

// src/app/features/dashboard/dashboard.ts
import { Component, inject } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import { DecimalPipe } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_common.js?v=b9a49161";
import { ChartModule } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_chart.js?v=b9a49161";
import * as i0 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import * as i1 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_chart.js?v=b9a49161";
import * as i2 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/primeng_api.js?v=b9a49161";
var _forTrack0 = ($index, $item) => $item.title;
function Dashboard_For_8_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0);
    i0.\u0275\u0275pipe(1, "number");
  }
  if (rf & 2) {
    const stat_r1 = i0.\u0275\u0275nextContext().$implicit;
    i0.\u0275\u0275textInterpolate1(" S/ ", i0.\u0275\u0275pipeBind1(1, 1, stat_r1.value), " ");
  }
}
function Dashboard_For_8_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0);
    i0.\u0275\u0275pipe(1, "number");
  }
  if (rf & 2) {
    const stat_r1 = i0.\u0275\u0275nextContext().$implicit;
    i0.\u0275\u0275textInterpolate1(" ", i0.\u0275\u0275pipeBind1(1, 1, stat_r1.value), " ");
  }
}
function Dashboard_For_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "article", 3)(1, "div", 8)(2, "span");
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275element(4, "i", 9);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(5, "h2");
    i0.\u0275\u0275conditionalCreate(6, Dashboard_For_8_Conditional_6_Template, 2, 3)(7, Dashboard_For_8_Conditional_7_Template, 2, 3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(8, "span", 10);
    i0.\u0275\u0275text(9);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const stat_r1 = ctx.$implicit;
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(stat_r1.title);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275classMap(stat_r1.icon);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(stat_r1.currency ? 6 : 7);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate1(" ", stat_r1.change, " respecto al mes anterior ");
  }
}
var Dashboard = class _Dashboard {
  ngOnInit() {
    this.userStore.loadUsers();
  }
  stats = [
    {
      title: "Ventas totales",
      value: 45890,
      icon: "pi pi-wallet",
      change: "+12.5%",
      currency: true
    },
    {
      title: "Usuarios",
      value: 1248,
      icon: "pi pi-users",
      change: "+8.2%",
      currency: false
    },
    {
      title: "Pedidos",
      value: 356,
      icon: "pi pi-shopping-cart",
      change: "+5.4%",
      currency: false
    },
    {
      title: "Productos",
      value: 89,
      icon: "pi pi-box",
      change: "+2.1%",
      currency: false
    }
  ];
  chartData = {
    labels: ["Ene", "Feb", "Mar", "Abr", "May", "Jun"],
    datasets: [
      {
        label: "Ventas",
        data: [12e3, 19e3, 15e3, 28e3, 24e3, 35e3],
        borderColor: "#6366f1",
        backgroundColor: "rgba(99, 102, 241, 0.1)",
        fill: true,
        tension: 0.4
      }
    ]
  };
  chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false }
    }
  };
  userStore = inject(UserStore);
  totalUsers = this.userStore.totalUsers;
  activeUsers = this.userStore.activeUsers;
  inactiveUsers = this.userStore.inactiveUsers;
  static \u0275fac = function Dashboard_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Dashboard)();
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _Dashboard, selectors: [["app-dashboard"]], decls: 32, vars: 5, consts: [[1, "dashboard"], [1, "page-heading"], [1, "stats-grid"], [1, "stat-card"], [1, "dashboard-stats"], [1, "chart-card"], [1, "chart-container"], ["type", "line", 3, "data", "options"], [1, "stat-top"], ["aria-hidden", "true"], [1, "positive"]], template: function Dashboard_Template(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275elementStart(0, "section", 0)(1, "div", 1)(2, "h1");
      i0.\u0275\u0275text(3, "Dashboard");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(4, "p");
      i0.\u0275\u0275text(5, "Resumen general de tu negocio");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(6, "div", 2);
      i0.\u0275\u0275repeaterCreate(7, Dashboard_For_8_Template, 10, 5, "article", 3, _forTrack0);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(9, "div", 4)(10, "div", 3)(11, "span");
      i0.\u0275\u0275text(12, "Total de usuarios");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(13, "strong");
      i0.\u0275\u0275text(14);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(15, "div", 3)(16, "span");
      i0.\u0275\u0275text(17, "Usuarios activos");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(18, "strong");
      i0.\u0275\u0275text(19);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(20, "div", 3)(21, "span");
      i0.\u0275\u0275text(22, "Usuarios inactivos");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(23, "strong");
      i0.\u0275\u0275text(24);
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275elementStart(25, "section", 5)(26, "h2");
      i0.\u0275\u0275text(27, "Resumen de ventas");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(28, "p");
      i0.\u0275\u0275text(29, "Evoluci\xF3n de los \xFAltimos seis meses");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(30, "div", 6);
      i0.\u0275\u0275element(31, "p-chart", 7);
      i0.\u0275\u0275elementEnd()()();
    }
    if (rf & 2) {
      i0.\u0275\u0275advance(7);
      i0.\u0275\u0275repeater(ctx.stats);
      i0.\u0275\u0275advance(7);
      i0.\u0275\u0275textInterpolate(ctx.totalUsers());
      i0.\u0275\u0275advance(5);
      i0.\u0275\u0275textInterpolate(ctx.activeUsers());
      i0.\u0275\u0275advance(5);
      i0.\u0275\u0275textInterpolate(ctx.inactiveUsers());
      i0.\u0275\u0275advance(7);
      i0.\u0275\u0275property("data", ctx.chartData)("options", ctx.chartOptions);
    }
  }, dependencies: [ChartModule, i1.UIChart, i2.Header, i2.Footer, i2.PrimeTemplate, DecimalPipe], styles: ["\n.page-heading[_ngcontent-%COMP%] {\n  margin-bottom: 24px;\n}\n.page-heading[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  margin: 0 0 6px;\n  font-size: 28px;\n}\n.page-heading[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  color: #64748b;\n}\n.stats-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(4, minmax(0, 1fr));\n  gap: 20px;\n  margin-bottom: 24px;\n}\n.stat-card[_ngcontent-%COMP%], \n.chart-card[_ngcontent-%COMP%] {\n  background: white;\n  padding: 24px;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n}\n.stat-top[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 12px;\n  color: #64748b;\n}\n.stat-top[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: #6366f1;\n}\n.stat-card[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 20px 0 12px;\n  font-size: 30px;\n}\n.positive[_ngcontent-%COMP%] {\n  color: #16a34a;\n  font-size: 12px;\n}\n.chart-card[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0 0 6px;\n}\n.chart-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: #64748b;\n}\n.chart-container[_ngcontent-%COMP%] {\n  height: 320px;\n  margin-top: 24px;\n}\n@media (max-width: 1100px) {\n  .stats-grid[_ngcontent-%COMP%] {\n    grid-template-columns: repeat(2, minmax(0, 1fr));\n  }\n}\n@media (max-width: 600px) {\n  .stats-grid[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n.dashboard-stats[_ngcontent-%COMP%] {\n  display: flex;\n  flex: 1 1 100%;\n  gap: 24px;\n  margin-bottom: 24px;\n}\n.dashboard-stats[_ngcontent-%COMP%]   .stat-card[_ngcontent-%COMP%] {\n  display: flex;\n  flex: 1 1 auto;\n  flex-direction: row;\n  gap: 12px;\n}\n/*# sourceMappingURL=dashboard.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(Dashboard, [{
    type: Component,
    args: [{ selector: "app-dashboard", imports: [DecimalPipe, ChartModule], template: '<section class="dashboard">\n  <div class="page-heading">\n    <h1>Dashboard</h1>\n    <p>Resumen general de tu negocio</p>\n  </div>\n\n  <div class="stats-grid">\n    @for (stat of stats; track stat.title) {\n      <article class="stat-card">\n        <div class="stat-top">\n          <span>{{ stat.title }}</span>\n          <i [class]="stat.icon" aria-hidden="true"></i>\n        </div>\n\n        <h2>\n          @if (stat.currency) {\n            S/ {{ stat.value | number }}\n          } @else {\n            {{ stat.value | number }}\n          }\n        </h2>\n\n        <span class="positive"> {{ stat.change }} respecto al mes anterior </span>\n      </article>\n    }\n  </div>\n\n  <div class="dashboard-stats">\n    <div class="stat-card">\n      <span>Total de usuarios</span>\n      <strong>{{ totalUsers() }}</strong>\n    </div>\n\n    <div class="stat-card">\n      <span>Usuarios activos</span>\n      <strong>{{ activeUsers() }}</strong>\n    </div>\n\n    <div class="stat-card">\n      <span>Usuarios inactivos</span>\n      <strong>{{ inactiveUsers() }}</strong>\n    </div>\n  </div>\n\n  <section class="chart-card">\n    <h2>Resumen de ventas</h2>\n    <p>Evoluci\xF3n de los \xFAltimos seis meses</p>\n\n    <div class="chart-container">\n      <p-chart type="line" [data]="chartData" [options]="chartOptions" />\n    </div>\n  </section>\n</section>\n', styles: ["/* src/app/features/dashboard/dashboard.scss */\n.page-heading {\n  margin-bottom: 24px;\n}\n.page-heading h1 {\n  margin: 0 0 6px;\n  font-size: 28px;\n}\n.page-heading p {\n  margin: 0;\n  color: #64748b;\n}\n.stats-grid {\n  display: grid;\n  grid-template-columns: repeat(4, minmax(0, 1fr));\n  gap: 20px;\n  margin-bottom: 24px;\n}\n.stat-card,\n.chart-card {\n  background: white;\n  padding: 24px;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n}\n.stat-top {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 12px;\n  color: #64748b;\n}\n.stat-top i {\n  font-size: 24px;\n  color: #6366f1;\n}\n.stat-card h2 {\n  margin: 20px 0 12px;\n  font-size: 30px;\n}\n.positive {\n  color: #16a34a;\n  font-size: 12px;\n}\n.chart-card h2 {\n  margin: 0 0 6px;\n}\n.chart-card p {\n  color: #64748b;\n}\n.chart-container {\n  height: 320px;\n  margin-top: 24px;\n}\n@media (max-width: 1100px) {\n  .stats-grid {\n    grid-template-columns: repeat(2, minmax(0, 1fr));\n  }\n}\n@media (max-width: 600px) {\n  .stats-grid {\n    grid-template-columns: 1fr;\n  }\n}\n.dashboard-stats {\n  display: flex;\n  flex: 1 1 100%;\n  gap: 24px;\n  margin-bottom: 24px;\n}\n.dashboard-stats .stat-card {\n  display: flex;\n  flex: 1 1 auto;\n  flex-direction: row;\n  gap: 12px;\n}\n/*# sourceMappingURL=dashboard.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(Dashboard, { className: "Dashboard", filePath: "app/features/dashboard/dashboard.ts", lineNumber: 12 });
})();
(() => {
  const id = "app%2Ffeatures%2Fdashboard%2Fdashboard.ts%40Dashboard";
  function Dashboard_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i0.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i0.\u0275\u0275replaceMetadata(Dashboard, m.default, [i0, i1, i2], [ChartModule, DecimalPipe, Component], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Dashboard_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Dashboard_HmrLoad(d.timestamp)));
})();
export {
  Dashboard
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZmVhdHVyZXMvZGFzaGJvYXJkL2Rhc2hib2FyZC50cyIsInNyYy9hcHAvZmVhdHVyZXMvZGFzaGJvYXJkL2Rhc2hib2FyZC5odG1sIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEZWNpbWFsUGlwZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBDaGFydE1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvY2hhcnQnO1xuaW1wb3J0IHsgVXNlclN0b3JlIH0gZnJvbSAnLi4vdXNlcnMvc3RvcmUvdXNlci1zdG9yZSc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2FwcC1kYXNoYm9hcmQnLFxuICBpbXBvcnRzOiBbRGVjaW1hbFBpcGUsIENoYXJ0TW9kdWxlXSxcbiAgdGVtcGxhdGVVcmw6ICcuL2Rhc2hib2FyZC5odG1sJyxcbiAgc3R5bGVVcmw6ICcuL2Rhc2hib2FyZC5zY3NzJyxcbn0pXG5leHBvcnQgY2xhc3MgRGFzaGJvYXJkIHtcbiAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy51c2VyU3RvcmUubG9hZFVzZXJzKCk7XG4gIH1cblxuICBzdGF0cyA9IFtcbiAgICB7XG4gICAgICB0aXRsZTogJ1ZlbnRhcyB0b3RhbGVzJyxcbiAgICAgIHZhbHVlOiA0NTg5MCxcbiAgICAgIGljb246ICdwaSBwaS13YWxsZXQnLFxuICAgICAgY2hhbmdlOiAnKzEyLjUlJyxcbiAgICAgIGN1cnJlbmN5OiB0cnVlLFxuICAgIH0sXG4gICAge1xuICAgICAgdGl0bGU6ICdVc3VhcmlvcycsXG4gICAgICB2YWx1ZTogMTI0OCxcbiAgICAgIGljb246ICdwaSBwaS11c2VycycsXG4gICAgICBjaGFuZ2U6ICcrOC4yJScsXG4gICAgICBjdXJyZW5jeTogZmFsc2UsXG4gICAgfSxcbiAgICB7XG4gICAgICB0aXRsZTogJ1BlZGlkb3MnLFxuICAgICAgdmFsdWU6IDM1NixcbiAgICAgIGljb246ICdwaSBwaS1zaG9wcGluZy1jYXJ0JyxcbiAgICAgIGNoYW5nZTogJys1LjQlJyxcbiAgICAgIGN1cnJlbmN5OiBmYWxzZSxcbiAgICB9LFxuICAgIHtcbiAgICAgIHRpdGxlOiAnUHJvZHVjdG9zJyxcbiAgICAgIHZhbHVlOiA4OSxcbiAgICAgIGljb246ICdwaSBwaS1ib3gnLFxuICAgICAgY2hhbmdlOiAnKzIuMSUnLFxuICAgICAgY3VycmVuY3k6IGZhbHNlLFxuICAgIH0sXG4gIF07XG5cbiAgY2hhcnREYXRhID0ge1xuICAgIGxhYmVsczogWydFbmUnLCAnRmViJywgJ01hcicsICdBYnInLCAnTWF5JywgJ0p1biddLFxuICAgIGRhdGFzZXRzOiBbXG4gICAgICB7XG4gICAgICAgIGxhYmVsOiAnVmVudGFzJyxcbiAgICAgICAgZGF0YTogWzEyMDAwLCAxOTAwMCwgMTUwMDAsIDI4MDAwLCAyNDAwMCwgMzUwMDBdLFxuICAgICAgICBib3JkZXJDb2xvcjogJyM2MzY2ZjEnLFxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICdyZ2JhKDk5LCAxMDIsIDI0MSwgMC4xKScsXG4gICAgICAgIGZpbGw6IHRydWUsXG4gICAgICAgIHRlbnNpb246IDAuNCxcbiAgICAgIH0sXG4gICAgXSxcbiAgfTtcblxuICBjaGFydE9wdGlvbnMgPSB7XG4gICAgcmVzcG9uc2l2ZTogdHJ1ZSxcbiAgICBtYWludGFpbkFzcGVjdFJhdGlvOiBmYWxzZSxcbiAgICBwbHVnaW5zOiB7XG4gICAgICBsZWdlbmQ6IHsgZGlzcGxheTogZmFsc2UgfSxcbiAgICB9LFxuICB9O1xuXG4gIHJlYWRvbmx5IHVzZXJTdG9yZSA9IGluamVjdChVc2VyU3RvcmUpO1xuXG4gIHJlYWRvbmx5IHRvdGFsVXNlcnMgPSB0aGlzLnVzZXJTdG9yZS50b3RhbFVzZXJzO1xuICByZWFkb25seSBhY3RpdmVVc2VycyA9IHRoaXMudXNlclN0b3JlLmFjdGl2ZVVzZXJzO1xuICByZWFkb25seSBpbmFjdGl2ZVVzZXJzID0gdGhpcy51c2VyU3RvcmUuaW5hY3RpdmVVc2Vycztcbn1cbiIsIjxzZWN0aW9uIGNsYXNzPVwiZGFzaGJvYXJkXCI+XG4gIDxkaXYgY2xhc3M9XCJwYWdlLWhlYWRpbmdcIj5cbiAgICA8aDE+RGFzaGJvYXJkPC9oMT5cbiAgICA8cD5SZXN1bWVuIGdlbmVyYWwgZGUgdHUgbmVnb2NpbzwvcD5cbiAgPC9kaXY+XG5cbiAgPGRpdiBjbGFzcz1cInN0YXRzLWdyaWRcIj5cbiAgICBAZm9yIChzdGF0IG9mIHN0YXRzOyB0cmFjayBzdGF0LnRpdGxlKSB7XG4gICAgICA8YXJ0aWNsZSBjbGFzcz1cInN0YXQtY2FyZFwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3RhdC10b3BcIj5cbiAgICAgICAgICA8c3Bhbj57eyBzdGF0LnRpdGxlIH19PC9zcGFuPlxuICAgICAgICAgIDxpIFtjbGFzc109XCJzdGF0Lmljb25cIiBhcmlhLWhpZGRlbj1cInRydWVcIj48L2k+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxoMj5cbiAgICAgICAgICBAaWYgKHN0YXQuY3VycmVuY3kpIHtcbiAgICAgICAgICAgIFMvIHt7IHN0YXQudmFsdWUgfCBudW1iZXIgfX1cbiAgICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICAgIHt7IHN0YXQudmFsdWUgfCBudW1iZXIgfX1cbiAgICAgICAgICB9XG4gICAgICAgIDwvaDI+XG5cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJwb3NpdGl2ZVwiPiB7eyBzdGF0LmNoYW5nZSB9fSByZXNwZWN0byBhbCBtZXMgYW50ZXJpb3IgPC9zcGFuPlxuICAgICAgPC9hcnRpY2xlPlxuICAgIH1cbiAgPC9kaXY+XG5cbiAgPGRpdiBjbGFzcz1cImRhc2hib2FyZC1zdGF0c1wiPlxuICAgIDxkaXYgY2xhc3M9XCJzdGF0LWNhcmRcIj5cbiAgICAgIDxzcGFuPlRvdGFsIGRlIHVzdWFyaW9zPC9zcGFuPlxuICAgICAgPHN0cm9uZz57eyB0b3RhbFVzZXJzKCkgfX08L3N0cm9uZz5cbiAgICA8L2Rpdj5cblxuICAgIDxkaXYgY2xhc3M9XCJzdGF0LWNhcmRcIj5cbiAgICAgIDxzcGFuPlVzdWFyaW9zIGFjdGl2b3M8L3NwYW4+XG4gICAgICA8c3Ryb25nPnt7IGFjdGl2ZVVzZXJzKCkgfX08L3N0cm9uZz5cbiAgICA8L2Rpdj5cblxuICAgIDxkaXYgY2xhc3M9XCJzdGF0LWNhcmRcIj5cbiAgICAgIDxzcGFuPlVzdWFyaW9zIGluYWN0aXZvczwvc3Bhbj5cbiAgICAgIDxzdHJvbmc+e3sgaW5hY3RpdmVVc2VycygpIH19PC9zdHJvbmc+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuXG4gIDxzZWN0aW9uIGNsYXNzPVwiY2hhcnQtY2FyZFwiPlxuICAgIDxoMj5SZXN1bWVuIGRlIHZlbnRhczwvaDI+XG4gICAgPHA+RXZvbHVjacOzbiBkZSBsb3Mgw7psdGltb3Mgc2VpcyBtZXNlczwvcD5cblxuICAgIDxkaXYgY2xhc3M9XCJjaGFydC1jb250YWluZXJcIj5cbiAgICAgIDxwLWNoYXJ0IHR5cGU9XCJsaW5lXCIgW2RhdGFdPVwiY2hhcnREYXRhXCIgW29wdGlvbnNdPVwiY2hhcnRPcHRpb25zXCIgLz5cbiAgICA8L2Rpdj5cbiAgPC9zZWN0aW9uPlxuPC9zZWN0aW9uPlxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUEsU0FBUyxXQUFXLGNBQWM7QUFDbEMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxtQkFBbUI7Ozs7Ozs7QUNjaEIsSUFBQSxvQkFBQSxDQUFBOzs7OztBQUFBLElBQUEsZ0NBQUEsUUFBQSx5QkFBQSxHQUFBLEdBQUEsUUFBQSxLQUFBLEdBQUEsR0FBQTs7Ozs7QUFFQSxJQUFBLG9CQUFBLENBQUE7Ozs7O0FBQUEsSUFBQSxnQ0FBQSxLQUFBLHlCQUFBLEdBQUEsR0FBQSxRQUFBLEtBQUEsR0FBQSxHQUFBOzs7OztBQVZOLElBQUEsNEJBQUEsR0FBQSxXQUFBLENBQUEsRUFBMkIsR0FBQSxPQUFBLENBQUEsRUFDSCxHQUFBLE1BQUE7QUFDZCxJQUFBLG9CQUFBLENBQUE7QUFBZ0IsSUFBQSwwQkFBQTtBQUN0QixJQUFBLHVCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQ0YsSUFBQSwwQkFBQTtBQUVBLElBQUEsNEJBQUEsR0FBQSxJQUFBO0FBQ0UsSUFBQSxpQ0FBQSxHQUFBLHdDQUFBLEdBQUEsQ0FBQSxFQUFxQixHQUFBLHdDQUFBLEdBQUEsQ0FBQTtBQUt2QixJQUFBLDBCQUFBO0FBRUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUF3QixJQUFBLG9CQUFBLENBQUE7QUFBMkMsSUFBQSwwQkFBQSxFQUFPOzs7O0FBWmxFLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsUUFBQSxLQUFBO0FBQ0gsSUFBQSx1QkFBQTtBQUFBLElBQUEsd0JBQUEsUUFBQSxJQUFBO0FBSUgsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxRQUFBLFdBQUEsSUFBQSxDQUFBO0FBT3NCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxRQUFBLFFBQUEsNEJBQUE7OztBRFgxQixJQUFPLFlBQVAsTUFBTyxXQUFTO0VBQ3BCLFdBQVE7QUFDTixTQUFLLFVBQVUsVUFBUztFQUMxQjtFQUVBLFFBQVE7SUFDTjtNQUNFLE9BQU87TUFDUCxPQUFPO01BQ1AsTUFBTTtNQUNOLFFBQVE7TUFDUixVQUFVOztJQUVaO01BQ0UsT0FBTztNQUNQLE9BQU87TUFDUCxNQUFNO01BQ04sUUFBUTtNQUNSLFVBQVU7O0lBRVo7TUFDRSxPQUFPO01BQ1AsT0FBTztNQUNQLE1BQU07TUFDTixRQUFRO01BQ1IsVUFBVTs7SUFFWjtNQUNFLE9BQU87TUFDUCxPQUFPO01BQ1AsTUFBTTtNQUNOLFFBQVE7TUFDUixVQUFVOzs7RUFJZCxZQUFZO0lBQ1YsUUFBUSxDQUFDLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxLQUFLO0lBQ2pELFVBQVU7TUFDUjtRQUNFLE9BQU87UUFDUCxNQUFNLENBQUMsTUFBTyxNQUFPLE1BQU8sTUFBTyxNQUFPLElBQUs7UUFDL0MsYUFBYTtRQUNiLGlCQUFpQjtRQUNqQixNQUFNO1FBQ04sU0FBUzs7OztFQUtmLGVBQWU7SUFDYixZQUFZO0lBQ1oscUJBQXFCO0lBQ3JCLFNBQVM7TUFDUCxRQUFRLEVBQUUsU0FBUyxNQUFLOzs7RUFJbkIsWUFBWSxPQUFPLFNBQVM7RUFFNUIsYUFBYSxLQUFLLFVBQVU7RUFDNUIsY0FBYyxLQUFLLFVBQVU7RUFDN0IsZ0JBQWdCLEtBQUssVUFBVTs7cUNBOUQ3QixZQUFTO0VBQUE7NEVBQVQsWUFBUyxXQUFBLENBQUEsQ0FBQSxlQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsR0FBQSxRQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsZUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxtQkFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ1h0QixNQUFBLDRCQUFBLEdBQUEsV0FBQSxDQUFBLEVBQTJCLEdBQUEsT0FBQSxDQUFBLEVBQ0MsR0FBQSxJQUFBO0FBQ3BCLE1BQUEsb0JBQUEsR0FBQSxXQUFBO0FBQVMsTUFBQSwwQkFBQTtBQUNiLE1BQUEsNEJBQUEsR0FBQSxHQUFBO0FBQUcsTUFBQSxvQkFBQSxHQUFBLCtCQUFBO0FBQTZCLE1BQUEsMEJBQUEsRUFBSTtBQUd0QyxNQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0UsTUFBQSw4QkFBQSxHQUFBLDBCQUFBLElBQUEsR0FBQSxXQUFBLEdBQUEsVUFBQTtBQWtCRixNQUFBLDBCQUFBO0FBRUEsTUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUE2QixJQUFBLE9BQUEsQ0FBQSxFQUNKLElBQUEsTUFBQTtBQUNmLE1BQUEsb0JBQUEsSUFBQSxtQkFBQTtBQUFpQixNQUFBLDBCQUFBO0FBQ3ZCLE1BQUEsNEJBQUEsSUFBQSxRQUFBO0FBQVEsTUFBQSxvQkFBQSxFQUFBO0FBQWtCLE1BQUEsMEJBQUEsRUFBUztBQUdyQyxNQUFBLDRCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXVCLElBQUEsTUFBQTtBQUNmLE1BQUEsb0JBQUEsSUFBQSxrQkFBQTtBQUFnQixNQUFBLDBCQUFBO0FBQ3RCLE1BQUEsNEJBQUEsSUFBQSxRQUFBO0FBQVEsTUFBQSxvQkFBQSxFQUFBO0FBQW1CLE1BQUEsMEJBQUEsRUFBUztBQUd0QyxNQUFBLDRCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXVCLElBQUEsTUFBQTtBQUNmLE1BQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFrQixNQUFBLDBCQUFBO0FBQ3hCLE1BQUEsNEJBQUEsSUFBQSxRQUFBO0FBQVEsTUFBQSxvQkFBQSxFQUFBO0FBQXFCLE1BQUEsMEJBQUEsRUFBUyxFQUNsQztBQUdSLE1BQUEsNEJBQUEsSUFBQSxXQUFBLENBQUEsRUFBNEIsSUFBQSxJQUFBO0FBQ3RCLE1BQUEsb0JBQUEsSUFBQSxtQkFBQTtBQUFpQixNQUFBLDBCQUFBO0FBQ3JCLE1BQUEsNEJBQUEsSUFBQSxHQUFBO0FBQUcsTUFBQSxvQkFBQSxJQUFBLDJDQUFBO0FBQW1DLE1BQUEsMEJBQUE7QUFFdEMsTUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNFLE1BQUEsdUJBQUEsSUFBQSxXQUFBLENBQUE7QUFDRixNQUFBLDBCQUFBLEVBQU0sRUFDRTs7O0FBNUNSLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsd0JBQUEsSUFBQSxLQUFBO0FBdUJVLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsK0JBQUEsSUFBQSxXQUFBLENBQUE7QUFLQSxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLCtCQUFBLElBQUEsWUFBQSxDQUFBO0FBS0EsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwrQkFBQSxJQUFBLGNBQUEsQ0FBQTtBQVNhLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsd0JBQUEsUUFBQSxJQUFBLFNBQUEsRUFBa0IsV0FBQSxJQUFBLFlBQUE7O29CRDFDcEIsYUFBVyxZQUFBLFdBQUEsV0FBQSxrQkFBeEIsV0FBVyxHQUFBLFFBQUEsQ0FBQSxrdkRBQUEsRUFBQSxDQUFBOzs7K0VBSVYsV0FBUyxDQUFBO1VBTnJCO3VCQUNXLGlCQUFlLFNBQ2hCLENBQUMsYUFBYSxXQUFXLEdBQUMsVUFBQSwwMkNBQUEsUUFBQSxDQUFBLDQwQ0FBQSxFQUFBLENBQUE7Ozs7Z0ZBSXhCLFdBQVMsRUFBQSxXQUFBLGFBQUEsVUFBQSx1Q0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7OERBQVQsV0FBUyxFQUFBLFNBQUEsQ0FBQSxJQUFBLElBQUEsRUFBQSxHQUFBLENBQUEsYUFBQSxhQUFBLFNBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLGtCQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLGtCQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTsiLCJuYW1lcyI6W119