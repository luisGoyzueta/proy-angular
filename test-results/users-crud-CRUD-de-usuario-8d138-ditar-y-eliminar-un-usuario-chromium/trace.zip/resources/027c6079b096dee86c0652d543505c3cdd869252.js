import {
  UserStore
} from "/chunk-WOIO7PCB.js";

// src/app/core/services/session-cleanup.ts
import { Injectable, inject } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
import * as i0 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
var SessionCleanupService = class _SessionCleanupService {
  userStore = inject(UserStore);
  clear() {
    this.userStore.reset();
  }
  static \u0275fac = function SessionCleanupService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _SessionCleanupService)();
  };
  static \u0275prov = /* @__PURE__ */ i0.\u0275\u0275defineInjectable({ token: _SessionCleanupService, factory: _SessionCleanupService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(SessionCleanupService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

export {
  SessionCleanupService
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29yZS9zZXJ2aWNlcy9zZXNzaW9uLWNsZWFudXAudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFVzZXJTdG9yZSB9IGZyb20gJy4uLy4uL2ZlYXR1cmVzL3VzZXJzL3N0b3JlL3VzZXItc3RvcmUnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gIHByb3ZpZGVkSW46ICdyb290JyxcclxufSlcclxuZXhwb3J0IGNsYXNzIFNlc3Npb25DbGVhbnVwU2VydmljZSB7XHJcbiAgcHJpdmF0ZSByZWFkb25seSB1c2VyU3RvcmUgPSBpbmplY3QoVXNlclN0b3JlKTtcclxuXHJcbiAgY2xlYXIoKTogdm9pZCB7XHJcbiAgICB0aGlzLnVzZXJTdG9yZS5yZXNldCgpO1xyXG4gIH1cclxufVxyXG4iXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsU0FBUyxZQUFZLGNBQWM7O0FBTTdCLElBQU8sd0JBQVAsTUFBTyx1QkFBcUI7RUFDZixZQUFZLE9BQU8sU0FBUztFQUU3QyxRQUFLO0FBQ0gsU0FBSyxVQUFVLE1BQUs7RUFDdEI7O3FDQUxXLHdCQUFxQjtFQUFBOytFQUFyQix3QkFBcUIsU0FBckIsdUJBQXFCLFdBQUEsWUFGcEIsT0FBTSxDQUFBOzs7K0VBRVAsdUJBQXFCLENBQUE7VUFIakM7V0FBVztNQUNWLFlBQVk7S0FDYjs7OyIsIm5hbWVzIjpbXX0=