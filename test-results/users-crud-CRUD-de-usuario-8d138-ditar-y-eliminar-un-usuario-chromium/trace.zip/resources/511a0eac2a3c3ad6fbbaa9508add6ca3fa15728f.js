import {
  AuthService
} from "/chunk-HUEL4CRJ.js";

// src/app/core/services/permission.ts
import { Injectable, computed, inject } from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";

// src/app/core/config/role-permissions.ts
var ROLE_PERMISSIONS = {
  Administrador: [
    "dashboard.view",
    "users.view",
    "users.create",
    "users.edit",
    "users.delete",
    "settings.view"
  ],
  Editor: ["dashboard.view", "users.view", "users.edit"],
  Usuario: ["dashboard.view"]
};

// src/app/core/services/permission.ts
import * as i0 from "/@fs/D:/trabajo/clases angular/proyecto-angular/.angular/cache/21.2.29/proyecto-angular/vite/deps/@angular_core.js?v=b9a49161";
var PermissionService = class _PermissionService {
  authService = inject(AuthService);
  permissions = computed(() => {
    const user = this.authService.currentUser();
    if (!user)
      return [];
    return ROLE_PERMISSIONS[user.role] ?? [];
  }, ...ngDevMode ? [{ debugName: "permissions" }] : (
    /* istanbul ignore next */
    []
  ));
  has(permission) {
    return this.permissions().includes(permission);
  }
  hasAny(permissions) {
    return permissions.some((permission) => this.has(permission));
  }
  hasAll(permissions) {
    return permissions.every((permission) => this.has(permission));
  }
  static \u0275fac = function PermissionService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PermissionService)();
  };
  static \u0275prov = /* @__PURE__ */ i0.\u0275\u0275defineInjectable({ token: _PermissionService, factory: _PermissionService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(PermissionService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

export {
  PermissionService
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29yZS9zZXJ2aWNlcy9wZXJtaXNzaW9uLnRzIiwic3JjL2FwcC9jb3JlL2NvbmZpZy9yb2xlLXBlcm1pc3Npb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIGNvbXB1dGVkLCBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgQXV0aFNlcnZpY2UgfSBmcm9tICcuL2F1dGgnO1xuaW1wb3J0IHsgUGVybWlzc2lvbiB9IGZyb20gJy4uL21vZGVscy9wZXJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IFJPTEVfUEVSTUlTU0lPTlMgfSBmcm9tICcuLi9jb25maWcvcm9sZS1wZXJtaXNzaW9ucyc7XG5cbkBJbmplY3RhYmxlKHtcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxufSlcblxuZXhwb3J0IGNsYXNzIFBlcm1pc3Npb25TZXJ2aWNlIHtcbiAgcHJpdmF0ZSByZWFkb25seSBhdXRoU2VydmljZSA9IGluamVjdChBdXRoU2VydmljZSk7XG4gIHJlYWRvbmx5IHBlcm1pc3Npb25zID0gY29tcHV0ZWQ8cmVhZG9ubHkgUGVybWlzc2lvbltdPigoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IHRoaXMuYXV0aFNlcnZpY2UuY3VycmVudFVzZXIoKTtcblxuICAgIGlmICghdXNlcikgcmV0dXJuIFtdO1xuICAgIHJldHVybiBST0xFX1BFUk1JU1NJT05TW3VzZXIucm9sZV0gPz8gW107XG4gIH0pO1xuXG4gIGhhcyhwZXJtaXNzaW9uOiBQZXJtaXNzaW9uKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMucGVybWlzc2lvbnMoKS5pbmNsdWRlcyhwZXJtaXNzaW9uKTtcbiAgfVxuXG4gIGhhc0FueShwZXJtaXNzaW9uczogUGVybWlzc2lvbltdKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHBlcm1pc3Npb25zLnNvbWUoKHBlcm1pc3Npb24pID0+IHRoaXMuaGFzKHBlcm1pc3Npb24pKTtcbiAgfVxuXG4gIGhhc0FsbChwZXJtaXNzaW9uczogUGVybWlzc2lvbltdKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHBlcm1pc3Npb25zLmV2ZXJ5KChwZXJtaXNzaW9uKSA9PiB0aGlzLmhhcyhwZXJtaXNzaW9uKSk7XG4gIH1cbn1cbiIsImltcG9ydCB0eXBlIHsgQXV0aFJvbGUgfSBmcm9tICcuLi9tb2RlbHMvYXV0aC5tb2RlbCc7XHJcbmltcG9ydCB7IFBlcm1pc3Npb24gfSBmcm9tICcuLi9tb2RlbHMvcGVybWlzc2lvbi5tb2RlbCc7XHJcblxyXG5leHBvcnQgY29uc3QgUk9MRV9QRVJNSVNTSU9OUzogUmVjb3JkPEF1dGhSb2xlLCByZWFkb25seSBQZXJtaXNzaW9uW10+ID0ge1xyXG4gIEFkbWluaXN0cmFkb3I6IFtcclxuICAgICdkYXNoYm9hcmQudmlldycsXHJcbiAgICAndXNlcnMudmlldycsXHJcbiAgICAndXNlcnMuY3JlYXRlJyxcclxuICAgICd1c2Vycy5lZGl0JyxcclxuICAgICd1c2Vycy5kZWxldGUnLFxyXG4gICAgJ3NldHRpbmdzLnZpZXcnLFxyXG4gIF0sXHJcblxyXG4gIEVkaXRvcjogWydkYXNoYm9hcmQudmlldycsICd1c2Vycy52aWV3JywgJ3VzZXJzLmVkaXQnXSxcclxuXHJcbiAgVXN1YXJpbzogWydkYXNoYm9hcmQudmlldyddLFxyXG59O1xyXG4iXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsU0FBUyxZQUFZLFVBQVUsY0FBYzs7O0FDR3RDLElBQU0sbUJBQTREO0VBQ3ZFLGVBQWU7SUFDYjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7O0VBR0YsUUFBUSxDQUFDLGtCQUFrQixjQUFjLFlBQVk7RUFFckQsU0FBUyxDQUFDLGdCQUFnQjs7Ozs7QURMdEIsSUFBTyxvQkFBUCxNQUFPLG1CQUFpQjtFQUNYLGNBQWMsT0FBTyxXQUFXO0VBQ3hDLGNBQWMsU0FBZ0MsTUFBSztBQUMxRCxVQUFNLE9BQU8sS0FBSyxZQUFZLFlBQVc7QUFFekMsUUFBSSxDQUFDO0FBQU0sYUFBTyxDQUFBO0FBQ2xCLFdBQU8saUJBQWlCLEtBQUssSUFBSSxLQUFLLENBQUE7RUFDeEMsR0FBQyxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsY0FBQSxDQUFBOztJQUFBLENBQUE7R0FBQTtFQUVELElBQUksWUFBc0I7QUFDeEIsV0FBTyxLQUFLLFlBQVcsRUFBRyxTQUFTLFVBQVU7RUFDL0M7RUFFQSxPQUFPLGFBQXlCO0FBQzlCLFdBQU8sWUFBWSxLQUFLLENBQUMsZUFBZSxLQUFLLElBQUksVUFBVSxDQUFDO0VBQzlEO0VBRUEsT0FBTyxhQUF5QjtBQUM5QixXQUFPLFlBQVksTUFBTSxDQUFDLGVBQWUsS0FBSyxJQUFJLFVBQVUsQ0FBQztFQUMvRDs7cUNBbkJXLG9CQUFpQjtFQUFBOytFQUFqQixvQkFBaUIsU0FBakIsbUJBQWlCLFdBQUEsWUFIaEIsT0FBTSxDQUFBOzs7K0VBR1AsbUJBQWlCLENBQUE7VUFKN0I7V0FBVztNQUNWLFlBQVk7S0FDYjs7OyIsIm5hbWVzIjpbXX0=