// src/environments/environment.ts
var environment = {
  production: false,
  apiUrl: "http://localhost:3000/api"
};

export {
  environment
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9lbnZpcm9ubWVudHMvZW52aXJvbm1lbnQuZGV2ZWxvcG1lbnQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IGVudmlyb25tZW50ID0ge1xyXG4gIHByb2R1Y3Rpb246IGZhbHNlLFxyXG4gIGFwaVVybDogJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGknLFxyXG59O1xyXG4iXSwibWFwcGluZ3MiOiI7QUFBTyxJQUFNLGNBQWM7RUFDekIsWUFBWTtFQUNaLFFBQVE7OyIsIm5hbWVzIjpbXX0=